# TOMAGI 1.0

**Topological Operator Machine for Analytic Geometric Inference**

TOMAGI is a deterministic, content-addressed operator substrate compiled into a fixed-width log-polar look-up table. Its literal core is:

```text
Pi(Cone(LSYS(Branch(Klein(phi(KIN2(JIT1(LUT[SDF0](K))))))))))
```

The 1-bit parity/jitter result is a route and perturbation primitive. It is not an error-correction flag. `SDF0` is embedded in the LUT itself: every defined cell has relation value zero, and an address outside the finite program domain is undefined.

TOMAGI does not contain learned weights, sampling, embeddings, confidence scores, stochastic state, damping, ECC, restoration forces, safe mode, or a hidden frame loop. A task becomes a TOMAGI task by compiling its literals, relations, branches, topology maps and output tokens into a finite `Cell48` graph. In that compiled domain, execution is a deterministic substitute for learned inference.

## Delivered backends

- dependency-free Python reference runtime and compiler;
- portable C99 runtime and CLI;
- GLSL 4.50 compute shader;
- WebGPU WGSL compute shader;
- OpenCL C kernel;
- one shared 64-byte `State64` record, 48-byte `Cell48` record and `.tmg` binary format.

## Quick start

```bash
make test

# Compile and run the literal polar loop
PYTHONPATH=src/python python -m tomagi compile \
  examples/polar_loop.json examples/polar_loop.tmg
PYTHONPATH=src/python python -m tomagi run \
  examples/polar_loop.tmg --trace

# Run the source-derived 19 -> active bits -> three pulses -> triangle example
PYTHONPATH=src/python python -m tomagi nineteen

# Run the C99 backend on the same binary program
./build/tomagi-c examples/polar_loop.tmg
```

The shipped validation compares the final 16-word state from Python and C byte-semantically. The OpenCL source is syntax-checked when `clang` is available. GLSL and WGSL sources are included against the same ABI; this build environment did not contain their external validators or a physical GPU runtime.

## Canonical key

```text
rho   20 bits  [63:44]
theta 18 bits  [43:26]
tick  14 bits  [25:12]
phi   12 bits  [11:0]
```

```text
K = (q_rho << 44) | (q_theta << 26) | (q_tick << 12) | q_phi
```

The package also supplies the distinct, exact MSB round-robin Morton layout and its complete 64-row schedule.

## Package map

- `report/TOMAGI_1_0_Tom_Klootwijk.pdf` - formal substrate specification.
- `spec/TOMAGI_1_0_FORMAL_DEFINITION.md` - editable normative definition.
- `spec/*.json`, `spec/*.csv` - schema, symbols, operators, opcodes, key and ABI layouts, precedence and 319-row source crosswalk.
- `src/python/tomagi/` - Python oracle, compiler and CLI.
- `src/c/` - C99 evaluator.
- `src/gpu/` - GLSL, WGSL and OpenCL kernels.
- `examples/` - literal polar loop, exact-19 rule and source-derived feature example.
- `tests/` - executable conformance tests.
- `sources/` - source hash register and retained 211-mechanism knowledge catalog.
- `validation/` - machine-readable validation report and console logs.
- `checksums/SHA256SUMS.txt` - package checksums.

## Attribution

Tom Klootwijk; NL200678942; 10-07-1990. This is requester-supplied attribution and was not independently verified.
