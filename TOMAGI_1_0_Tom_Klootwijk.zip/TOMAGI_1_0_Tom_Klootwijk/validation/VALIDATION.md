# TOMAGI 1.0 validation report

Generated: 2026-09-01

Pass: 8; source-checked: 2; failures: 0; not run: 0

## JSON Schema examples
**pass** - Draft 2020-12 validation: polar_loop.json, exact19_rule.json

## Python/C equality: polar_loop
**pass** - All 16 State64 fields match exactly.

## Python/C equality: exact19_rule
**pass** - All 16 State64 fields match exactly.

## 64-bit key reference vectors
**pass** - contiguous=0xe7b77000007800e3; Morton=0x88823bb88099128b

## OpenCL C syntax
**pass** - clang -cl-std=CL1.2 accepted the kernel

## GLSL 4.50 source
**source-checked** - Balanced delimiters, shared ABI symbols and opcode dispatch present; external shader compiler/device execution unavailable in this build environment.

## WGSL source
**source-checked** - Balanced delimiters, shared ABI symbols and opcode dispatch present; external shader compiler/device execution unavailable in this build environment.

## Operator/source condensation
**pass** - 43 operators; 319 crosswalk rows; 7 source artifacts; source labels ['SRC-A', 'SRC-B', 'SRC-C', 'SRC-D', 'SRC-E', 'SRC-F', 'SRC-G']

## Binary ABI sizes
**pass** - header=128; state=64; cell=48; polar_loop bytes=656

## Python conformance suite
**pass** - Ran 24 tests in 1.407s; return code 0

## Scope
Python and C were executed. OpenCL was syntax-checked. GLSL and WGSL were structurally checked but not compiled or dispatched because their external validators and a GPU runtime were not present.
