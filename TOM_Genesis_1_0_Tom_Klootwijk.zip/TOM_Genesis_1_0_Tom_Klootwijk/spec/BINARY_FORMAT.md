# TOMAGI 1.0 `.tmg` binary format

All integers are little-endian 32-bit words. Signed fields use two's-complement `i32`; unsigned fields use `u32`. The format has no pointer-sized values and is identical on 32-bit and 64-bit hosts.

TOM Seeded Compilation Profile 1.0 is additive. It constructs this unchanged format and assigns a materialization meaning to reserved `EMIT` flag bits; it does not change record sizes, opcode numbers, or hot transition equations.

## Header: 128 bytes

| Byte | Size | Field |
|---:|---:|---|
| 0 | 8 | ASCII magic `TOMAGI1\0` |
| 8 | 4 | version word `0x00010000` |
| 12 | 4 | program flags |
| 16 | 4 | cell count |
| 20 | 4 | entry cell index |
| 24 | 4 | deterministic runtime seed |
| 28 | 4 | default tick count |
| 32 | 4 | cell size, exactly 48 |
| 36 | 4 | state size, exactly 64 |
| 40 | 24 | six reserved zero words |
| 64 | 64 | initial `State64` |

The cell table begins at byte 128 and contains exactly `cell_count` consecutive `Cell48` records. File length is:

```text
128 + 48 * cell_count
```

### Seeded source binding

For a seeded source, the compiler calculates:

```text
genome_tag = little_endian_u32(first four bytes of SHA256(seed_bytes))
program.flags = u32(declared_program_flags XOR genome_tag)
```

For the canonical seed, `genome_tag = 0x317a41d1`. TOMAGI ABI 1.0 does not interpret this header flag word in the hot transition algebra.

## State64

The sixteen-word state layout is defined in `state64_layout.json/csv`. Words 0-7 are signed coordinates and first differences; words 8-13 are unsigned topology, cell, lineage and output fields; word 14 is a signed relation residual; word 15 is status.

## Cell48

The twelve-word cell layout is defined in `cell48_layout.json/csv`. A cell contains a canonical key, opcode, flags, four signed arguments, branch-0 and branch-1 successors, a payload and an auxiliary word.

## Canonical ordering

Cells are sorted by unsigned `(key_hi, key_lo)` order and keys are unique. Successors are indices after this canonical sort. The seeded compiler first constructs unresolved cell plans with successor IDs, sorts by canonical key, then resolves both successor indices.

## Generic byte-mode `EMIT`

For opcode 14 (`EMIT`) only:

| Flag bits | Meaning |
|---|---|
| bit 0 | Existing TOMAGI halt bit. |
| bit 8 | Byte-mode marker. When zero, the payload is a legacy symbolic token. |
| bits 10:9 | `byte_count - 1`, encoding one through four payload bytes. |

A byte chunk is packed into `payload` as:

```text
payload = b0 | (b1 << 8) | (b2 << 16) | (b3 << 24)
```

The generic materializer observes executed cells in trace order, selects byte-mode `EMIT` records, decodes one to four low payload bytes in little-endian order, and appends them. It has no artifact-format-specific branch.

Legacy symbolic `EMIT` cells remain unchanged. In strict byte materialization they are rejected; in mixed execution they remain symbolic output records.

## Deterministic arithmetic

- general additions are modulo `2^32`;
- signed interpretation is explicit two's complement;
- `theta`, `tick` and lower-case `phi` are normalized modulo `2^18`, `2^14` and `2^12` respectively;
- integer division in the L-system opcode truncates toward zero;
- topological wrap count uses mathematical floor division;
- no floating-point operation occurs in the hot binary evaluator.

The complete seeded source, evaluation, lowering, limits, materialization, rejection, and replay contract is normative in `TOM_SEEDED_COMPILATION_PROFILE_1_0.md`.
