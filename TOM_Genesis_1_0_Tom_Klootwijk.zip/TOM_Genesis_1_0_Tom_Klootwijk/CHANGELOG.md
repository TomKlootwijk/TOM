# Changelog

## 1.1.0 - 2026-09-01 - TOM Genesis

- Added TOM Seeded Compilation Profile 1.0 over the unchanged TOMAGI ABI 1.0.
- Added exact parsing and SHA-256 verification for the canonical 244-byte TOM seed.
- Added a seed-bound, content-addressed 28-token registry and strict seeded-source schema.
- Made definitions executable through a typed, finite 38-operation algebra.
- Added deterministic dependency evaluation, unique phase/ordinal scheduling, reachability checks, per-definition limits, and definition-to-cell lowering manifests.
- Added explicit `State64`, `Cell48`, graph, program, and ordered byte-emission constructors.
- Added generic one-to-four-byte materialization from executed `EMIT` cells without changing Cell48 or opcode transition semantics.
- Delivered the 32 x 61 TOM Seed Raster whose 244-byte raster payload is the exact canonical seed.
- Added a formal operation-algebra proof artifact.
- Migrated `polar_loop` and `exact19_rule` so their primary sources contain no top-level handwritten executable cells; retained byte-compatible legacy baselines.
- Extended the C99 CLI with complete JSON trace capture, emitted-record capture, state overrides, and generic byte materialization.
- Added 58 conformance tests, 18 validation checks, fourteen deterministic rejection cases, clean source-capsule replay, and full Python/C state/trace/lineage/EMIT/artifact equality.
- Added a TOMAGI-emitted combined validation and provenance certificate.
- Added the normative seeded profile and a rendered PDF report.
- Replaced the original external-source-dependent specification check with a portable integrity check; preserved the historical generator under `tools/legacy/`.
- Made no new GPU-device execution claim.

## 1.0.0 - 2026-09-01

- Named and formalized TOMAGI: Topological Operator Machine for Analytic Geometric Inference.
- Made the one-bit jitter, log-encoded polar LUT and literal `SDF0` membership field the normative core.
- Defined the 20/18/14/12 key, 64-byte state, 48-byte cell, sixteen-opcode instruction set and `.tmg` binary format.
- Added content-addressed literal definitions and deterministic source-to-operator precedence.
- Added Python, C99, GLSL, WGSL and OpenCL implementations.
- Added source-derived polar-loop, exact-19 rule and Dutch-segment/pulse demonstrations.
- Added a 43-operator catalog and 319-row crosswalk over the supplied project documents and retained 211-mechanism catalog.
- Removed guard intervals, ECC, damping, restoration forces, confidence thresholds, safe mode and kill criteria from the normative execution core.
