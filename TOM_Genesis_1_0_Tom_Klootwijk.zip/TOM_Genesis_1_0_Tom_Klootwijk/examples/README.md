# Examples

All primary Genesis examples are rooted in the canonical seed and use executable, content-addressed definitions. The compiler emits a deterministic `.compile_manifest.json` for each source.

## `seed_raster.json`

Six definitions construct an initial `State64`, the PBM header bytes, exact seed bytes, their concatenation, 64 byte-mode `EMIT` cells, and the final program. Generic execution and materialization produce `TOM_seed_raster_32x61.pbm`:

```text
P4
32 61
 || exact canonical seed bytes
```

The 253-byte artifact SHA-256 is `7025712c6da89ed41f2f0ac3dc62c81a043e4ae2bb3da505b0227b8bd255a859`.

## `operation_algebra.json`

Forty-nine definitions exercise profile-1.0 canonical literals, string/byte conversion, JSON canonicalization, bounded sequence operations, indexed mapping, fixed-width integer and bit operations, predicates, binary selection, phase-ordered support/compatibility/guard/event/transition definitions, explicit `State64` and `Cell48` construction, graph sequencing, and ordered byte emission.

The 61-byte artifact is `TOM_operation_algebra.bin` with SHA-256 `320809fa0fcde2f252e691265cf72f9f11de729bfe070e7376799130ff1251f4`.

## `polar_loop.json`

Fourteen executable definitions construct the initial state and eleven-cell TOMAGI chain. It preserves the historical state and complete trace for:

```text
SDF0 -> JIT1 -> KIN2 -> KLEIN -> PHI/HINGE -> LSYS -> CONE -> EMIT
```

The source has no top-level handwritten `cells` array.

## `exact19_rule.json`

Six executable definitions construct the initial state, exact `rho = 19` relation cell, and two symbolic `EMIT` leaves. It emits token 19 for `rho = 19` and token 0 for `rho = 18`. The source has no top-level handwritten `cells` array.

## `legacy/`

`polar_loop_legacy_cells.json` and `exact19_rule_legacy_cells.json` preserve the original handwritten-cell source profile. Their archived `.tmg` programs remain valid and the validator proves complete state/trace equality with the new seeded sources.

## `nineteen_hinge.json`

This retained high-level record keeps the numeric value 19, binary active-bit positions, Dutch profile segments, feature counts, and three-pulse triangle projection as separate typed representations. It is not one of the Genesis byte-emission proof artifacts.
