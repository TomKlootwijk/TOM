#include "tomagi.h"

#include <errno.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct TraceRecord {
    uint32_t step;
    uint32_t cell_before;
    uint32_t opcode;
    uint32_t branch;
    uint32_t cell_after;
    uint32_t key_hi;
    uint32_t key_lo;
    int32_t rho;
    int32_t theta;
    int32_t tick;
    int32_t phi;
    uint32_t orientation;
    uint32_t sheet;
    int32_t residual;
    uint32_t output;
    uint32_t lineage;
    uint32_t status;
} TraceRecord;

typedef struct EmitRecord {
    uint32_t step;
    uint32_t cell_index;
    uint32_t flags;
    uint32_t payload;
    uint32_t lineage;
    uint32_t byte_count;
    unsigned char bytes[4];
    int byte_mode;
} EmitRecord;

typedef struct StateOverride {
    uint32_t index;
    uint32_t word;
} StateOverride;

static void usage(const char *name) {
    fprintf(stderr,
        "usage: %s PROGRAM.tmg [ticks] [--trace]\n"
        "       %s PROGRAM.tmg [--ticks N] [--trace] [--trace-json FILE]\n"
        "          [--materialize FILE] [--allow-symbolic-emits]\n"
        "          [--state-word INDEX=VALUE ...]\n",
        name, name);
}

static int parse_u32(const char *text, uint32_t *out) {
    char *end = NULL;
    unsigned long value;
    errno = 0;
    value = strtoul(text, &end, 0);
    if (errno || !end || *end || value > 0xfffffffful) return 0;
    *out = (uint32_t)value;
    return 1;
}

static int parse_state_override(const char *text, StateOverride *out) {
    const char *eq = strchr(text, '=');
    char left[16];
    char *end = NULL;
    long index;
    long long signed_value;
    size_t left_len;
    if (!eq) return 0;
    left_len = (size_t)(eq - text);
    if (!left_len || left_len >= sizeof(left)) return 0;
    memcpy(left, text, left_len);
    left[left_len] = '\0';
    errno = 0;
    index = strtol(left, &end, 0);
    if (errno || !end || *end || index < 0 || index > 15) return 0;
    errno = 0;
    signed_value = strtoll(eq + 1, &end, 0);
    if (errno || !end || *end || signed_value < INT32_MIN || signed_value > 0xffffffffLL) return 0;
    out->index = (uint32_t)index;
    out->word = (uint32_t)signed_value;
    return 1;
}

static int32_t i32_from_u32(uint32_t word) {
    if (word <= (uint32_t)INT32_MAX) return (int32_t)word;
    return (int32_t)(-1 - (int32_t)(UINT32_MAX - word));
}

static int apply_state_word(TomagiState *s, uint32_t index, uint32_t word) {
    switch (index) {
        case 0: s->rho = i32_from_u32(word); break;
        case 1: s->theta = i32_from_u32(word); break;
        case 2: s->tick = i32_from_u32(word); break;
        case 3: s->phi = i32_from_u32(word); break;
        case 4: s->vrho = i32_from_u32(word); break;
        case 5: s->vtheta = i32_from_u32(word); break;
        case 6: s->vtick = i32_from_u32(word); break;
        case 7: s->vphi = i32_from_u32(word); break;
        case 8: s->orientation = word; break;
        case 9: s->sheet = word; break;
        case 10: s->branch = word; break;
        case 11: s->cell = word; break;
        case 12: s->lineage = word; break;
        case 13: s->output = word; break;
        case 14: s->residual = i32_from_u32(word); break;
        case 15: s->status = word; break;
        default: return 0;
    }
    return 1;
}

static void print_state_object(FILE *stream, const TomagiState *s, unsigned indent) {
    const char *pad = indent ? "    " : "";
    fprintf(stream,
        "{\n"
        "%s\"rho\": %" PRId32 ",\n"
        "%s\"theta\": %" PRId32 ",\n"
        "%s\"tick\": %" PRId32 ",\n"
        "%s\"phi\": %" PRId32 ",\n"
        "%s\"vrho\": %" PRId32 ",\n"
        "%s\"vtheta\": %" PRId32 ",\n"
        "%s\"vtick\": %" PRId32 ",\n"
        "%s\"vphi\": %" PRId32 ",\n"
        "%s\"orientation\": %" PRIu32 ",\n"
        "%s\"sheet\": %" PRIu32 ",\n"
        "%s\"branch\": %" PRIu32 ",\n"
        "%s\"cell\": %" PRIu32 ",\n"
        "%s\"lineage\": %" PRIu32 ",\n"
        "%s\"output\": %" PRIu32 ",\n"
        "%s\"residual\": %" PRId32 ",\n"
        "%s\"status\": %" PRIu32 "\n"
        "%s}",
        pad, s->rho, pad, s->theta, pad, s->tick, pad, s->phi,
        pad, s->vrho, pad, s->vtheta, pad, s->vtick, pad, s->vphi,
        pad, s->orientation, pad, s->sheet, pad, s->branch, pad, s->cell,
        pad, s->lineage, pad, s->output, pad, s->residual, pad, s->status,
        indent ? "  " : "");
}

static int write_trace_json(
    const char *path,
    const TomagiState *state,
    const TraceRecord *trace,
    uint32_t trace_count,
    const EmitRecord *emits,
    uint32_t emit_count,
    uint64_t materialized_bytes
) {
    FILE *f = fopen(path, "wb");
    uint32_t i;
    if (!f) return 0;
    fprintf(f, "{\n  \"emits\": [");
    for (i = 0; i < emit_count; ++i) {
        const EmitRecord *e = &emits[i];
        uint32_t j;
        fprintf(f,
            "%s\n    {\n"
            "      \"step\": %" PRIu32 ",\n"
            "      \"cell_index\": %" PRIu32 ",\n"
            "      \"flags\": %" PRIu32 ",\n"
            "      \"payload\": %" PRIu32 ",\n"
            "      \"lineage\": %" PRIu32 ",\n"
            "      \"mode\": \"%s\",\n"
            "      \"byte_count\": %" PRIu32 ",\n"
            "      \"bytes_hex\": \"",
            i ? "," : "", e->step, e->cell_index, e->flags, e->payload,
            e->lineage, e->byte_mode ? "bytes" : "symbolic", e->byte_count);
        for (j = 0; j < e->byte_count; ++j) fprintf(f, "%02x", e->bytes[j]);
        fprintf(f, "\"\n    }");
    }
    fprintf(f, "\n  ],\n  \"materialized\": {\"bytes\": %" PRIu64 "},\n  \"state\": ", materialized_bytes);
    print_state_object(f, state, 1u);
    fprintf(f, ",\n  \"trace\": [");
    for (i = 0; i < trace_count; ++i) {
        const TraceRecord *r = &trace[i];
        fprintf(f,
            "%s\n    {\n"
            "      \"step\": %" PRIu32 ",\n"
            "      \"cell_before\": %" PRIu32 ",\n"
            "      \"opcode\": %" PRIu32 ",\n"
            "      \"branch\": %" PRIu32 ",\n"
            "      \"cell_after\": %" PRIu32 ",\n"
            "      \"key_hi\": %" PRIu32 ",\n"
            "      \"key_lo\": %" PRIu32 ",\n"
            "      \"rho\": %" PRId32 ",\n"
            "      \"theta\": %" PRId32 ",\n"
            "      \"tick\": %" PRId32 ",\n"
            "      \"phi\": %" PRId32 ",\n"
            "      \"orientation\": %" PRIu32 ",\n"
            "      \"sheet\": %" PRIu32 ",\n"
            "      \"residual\": %" PRId32 ",\n"
            "      \"output\": %" PRIu32 ",\n"
            "      \"lineage\": %" PRIu32 ",\n"
            "      \"status\": %" PRIu32 "\n"
            "    }",
            i ? "," : "", r->step, r->cell_before, r->opcode, r->branch,
            r->cell_after, r->key_hi, r->key_lo, r->rho, r->theta, r->tick,
            r->phi, r->orientation, r->sheet, r->residual, r->output,
            r->lineage, r->status);
    }
    fprintf(f, "\n  ]\n}\n");
    if (fclose(f) != 0) return 0;
    return 1;
}

int main(int argc, char **argv) {
    TomagiProgram program;
    TomagiState state;
    char error[256];
    uint32_t ticks;
    int trace_text = 0;
    int allow_symbolic = 0;
    const char *trace_json_path = NULL;
    const char *materialize_path = NULL;
    int positional_ticks_seen = 0;
    StateOverride overrides[16];
    size_t override_count = 0;
    TraceRecord *trace_records = NULL;
    EmitRecord *emit_records = NULL;
    uint32_t trace_count = 0;
    uint32_t emit_count = 0;
    uint64_t materialized_bytes = 0;
    FILE *materialized = NULL;
    int i;
    int exit_code = 0;

    if (argc < 2) {
        usage(argv[0]);
        return 2;
    }
    if (!tomagi_load_file(argv[1], &program, error, sizeof(error))) {
        fprintf(stderr, "tomagi: %s\n", error);
        return 1;
    }
    ticks = program.default_ticks;

    for (i = 2; i < argc; ++i) {
        if (strcmp(argv[i], "--trace") == 0) {
            trace_text = 1;
        } else if (strcmp(argv[i], "--allow-symbolic-emits") == 0) {
            allow_symbolic = 1;
        } else if (strcmp(argv[i], "--ticks") == 0) {
            if (++i >= argc || !parse_u32(argv[i], &ticks)) {
                fprintf(stderr, "tomagi: invalid --ticks value\n");
                exit_code = 2;
                goto cleanup;
            }
            positional_ticks_seen = 1;
        } else if (strcmp(argv[i], "--trace-json") == 0) {
            if (++i >= argc) {
                fprintf(stderr, "tomagi: --trace-json requires a path\n");
                exit_code = 2;
                goto cleanup;
            }
            trace_json_path = argv[i];
        } else if (strcmp(argv[i], "--materialize") == 0) {
            if (++i >= argc) {
                fprintf(stderr, "tomagi: --materialize requires a path\n");
                exit_code = 2;
                goto cleanup;
            }
            materialize_path = argv[i];
        } else if (strcmp(argv[i], "--state-word") == 0) {
            if (++i >= argc || override_count >= 16 ||
                !parse_state_override(argv[i], &overrides[override_count])) {
                fprintf(stderr, "tomagi: invalid --state-word INDEX=VALUE\n");
                exit_code = 2;
                goto cleanup;
            }
            ++override_count;
        } else if (argv[i][0] != '-' && !positional_ticks_seen) {
            if (!parse_u32(argv[i], &ticks)) {
                fprintf(stderr, "tomagi: invalid tick count\n");
                exit_code = 2;
                goto cleanup;
            }
            positional_ticks_seen = 1;
        } else {
            usage(argv[0]);
            exit_code = 2;
            goto cleanup;
        }
    }

    if (trace_json_path) {
        trace_records = (TraceRecord *)calloc(ticks ? ticks : 1u, sizeof(TraceRecord));
        emit_records = (EmitRecord *)calloc(ticks ? ticks : 1u, sizeof(EmitRecord));
        if (!trace_records || !emit_records) {
            fprintf(stderr, "tomagi: out of memory for trace capture\n");
            exit_code = 1;
            goto cleanup;
        }
    }
    if (materialize_path) {
        materialized = fopen(materialize_path, "wb");
        if (!materialized) {
            fprintf(stderr, "tomagi: cannot create materialized output: %s\n", strerror(errno));
            exit_code = 1;
            goto cleanup;
        }
    }

    state = program.initial_state;
    state.cell = program.entry;
    for (i = 0; i < (int)override_count; ++i) {
        if (!apply_state_word(&state, overrides[i].index, overrides[i].word)) {
            fprintf(stderr, "tomagi: invalid state override\n");
            exit_code = 2;
            goto cleanup;
        }
    }

    for (i = 0; (uint32_t)i < ticks && !(state.status & TOMAGI_STATUS_HALT); ++i) {
        uint32_t before = state.cell;
        uint32_t key_hi, key_lo;
        const TomagiCell *cell = &program.cells[before];
        if (!tomagi_step(&program, &state)) {
            fprintf(stderr, "tomagi: execution error at step %d cell %u\n", i, before);
            exit_code = 1;
            goto cleanup;
        }
        tomagi_pack_key_contiguous(&state, &key_hi, &key_lo);

        if (trace_records) {
            TraceRecord *r = &trace_records[trace_count++];
            r->step = (uint32_t)i;
            r->cell_before = before;
            r->opcode = cell->opcode;
            r->branch = state.branch;
            r->cell_after = state.cell;
            r->key_hi = key_hi;
            r->key_lo = key_lo;
            r->rho = state.rho;
            r->theta = state.theta;
            r->tick = state.tick;
            r->phi = state.phi;
            r->orientation = state.orientation;
            r->sheet = state.sheet;
            r->residual = state.residual;
            r->output = state.output;
            r->lineage = state.lineage;
            r->status = state.status;
        }

        if (cell->opcode == TOMAGI_OP_EMIT) {
            int byte_mode = (cell->flags & TOMAGI_FLAG_EMIT_BYTES) != 0u;
            uint32_t count = byte_mode
                ? (((cell->flags & TOMAGI_FLAG_EMIT_COUNT_MASK) >> TOMAGI_FLAG_EMIT_COUNT_SHIFT) + 1u)
                : 0u;
            unsigned char bytes[4];
            uint32_t j;
            bytes[0] = (unsigned char)(cell->payload & 0xffu);
            bytes[1] = (unsigned char)((cell->payload >> 8) & 0xffu);
            bytes[2] = (unsigned char)((cell->payload >> 16) & 0xffu);
            bytes[3] = (unsigned char)((cell->payload >> 24) & 0xffu);
            if (trace_records) {
                EmitRecord *e = &emit_records[emit_count++];
                e->step = (uint32_t)i;
                e->cell_index = before;
                e->flags = cell->flags;
                e->payload = cell->payload;
                e->lineage = state.lineage;
                e->byte_count = count;
                e->byte_mode = byte_mode;
                for (j = 0; j < count; ++j) e->bytes[j] = bytes[j];
            }
            if (materialized) {
                if (!byte_mode && !allow_symbolic) {
                    fprintf(stderr, "tomagi: symbolic EMIT at cell %u is not byte materialization mode\n", before);
                    exit_code = 1;
                    goto cleanup;
                }
                if (byte_mode) {
                    if (fwrite(bytes, 1, count, materialized) != count) {
                        fprintf(stderr, "tomagi: cannot write materialized output\n");
                        exit_code = 1;
                        goto cleanup;
                    }
                    materialized_bytes += count;
                }
            }
        }

        if (trace_text) {
            fprintf(stderr,
                "step=%d cell=%u op=%s branch=%u next=%u output=%u lineage=%u status=%u\n",
                i, before, tomagi_opcode_name(cell->opcode), state.branch,
                state.cell, state.output, state.lineage, state.status);
        }
    }

    if (materialized && fclose(materialized) != 0) {
        materialized = NULL;
        fprintf(stderr, "tomagi: cannot finalize materialized output\n");
        exit_code = 1;
        goto cleanup;
    }
    materialized = NULL;

    if (trace_json_path && !write_trace_json(
            trace_json_path, &state, trace_records, trace_count,
            emit_records, emit_count, materialized_bytes)) {
        fprintf(stderr, "tomagi: cannot write trace JSON\n");
        exit_code = 1;
        goto cleanup;
    }
    tomagi_print_state_json(stdout, &state);

cleanup:
    if (materialized) fclose(materialized);
    free(trace_records);
    free(emit_records);
    tomagi_free_program(&program);
    return exit_code;
}
