"""Generic TOMAGI EMIT-record capture and byte materialization.

The materializer does not know artifact formats.  In the seeded profile an EMIT
cell marks byte mode in flag bit 8, stores ``byte_count - 1`` in bits 10:9, and
carries one to four little-endian payload bytes.  Records are appended strictly
in observed execution order.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
import hashlib
from typing import Any

from .core import (
    FLAG_EMIT_BYTES,
    FLAG_EMIT_COUNT_MASK,
    FLAG_EMIT_COUNT_SHIFT,
    Opcode,
    Program,
    State,
    run,
)


@dataclass(frozen=True, slots=True)
class MaterializationResult:
    state: State
    trace: list[dict[str, int]]
    emits: list[dict[str, Any]]
    data: bytes

    def summary(self) -> dict[str, Any]:
        return {
            "state": state_dict(self.state),
            "trace": self.trace,
            "emits": self.emits,
            "materialized": {
                "bytes": len(self.data),
                "sha256": hashlib.sha256(self.data).hexdigest(),
            },
        }


def state_dict(state: State) -> dict[str, int]:
    return {name: getattr(state, name) for name in state.__dataclass_fields__}


def emit_byte_count(flags: int) -> int | None:
    """Decode seeded-profile byte count, or return ``None`` for symbolic EMIT."""
    if not (flags & FLAG_EMIT_BYTES):
        return None
    return ((flags & FLAG_EMIT_COUNT_MASK) >> FLAG_EMIT_COUNT_SHIFT) + 1


def payload_bytes(payload: int, count: int) -> bytes:
    if not 1 <= count <= 4:
        raise ValueError("EMIT byte count must be in 1..4")
    return (payload & 0xFFFFFFFF).to_bytes(4, "little")[:count]


def execute_and_materialize(
    program: Program,
    *,
    ticks: int | None = None,
    state: State | None = None,
    strict_bytes: bool = True,
) -> MaterializationResult:
    """Run *program*, capture all EMIT records, and append byte-mode payloads.

    ``strict_bytes`` rejects a symbolic EMIT when a byte artifact is requested.
    Set it to ``False`` to capture mixed symbolic and byte emissions while only
    materializing the byte-mode records.
    """
    final_state, trace = run(program, ticks=ticks, state=state, trace=True)
    emitted: list[dict[str, Any]] = []
    chunks: list[bytes] = []
    for record in trace:
        cell_index = record["cell_before"]
        cell = program.cells[cell_index]
        if cell.opcode != int(Opcode.EMIT):
            continue
        count = emit_byte_count(cell.flags)
        item: dict[str, Any] = {
            "step": record["step"],
            "cell_index": cell_index,
            "flags": cell.flags,
            "payload": cell.payload,
            "lineage": record["lineage"],
        }
        if count is None:
            item.update({"mode": "symbolic", "byte_count": 0, "bytes_hex": ""})
            if strict_bytes:
                raise ValueError(
                    f"executed EMIT cell {cell_index} is symbolic, not seeded byte mode"
                )
        else:
            chunk = payload_bytes(cell.payload, count)
            item.update(
                {
                    "mode": "bytes",
                    "byte_count": count,
                    "bytes_hex": chunk.hex(),
                }
            )
            chunks.append(chunk)
        emitted.append(item)
    return MaterializationResult(
        state=replace(final_state),
        trace=trace,
        emits=emitted,
        data=b"".join(chunks),
    )
