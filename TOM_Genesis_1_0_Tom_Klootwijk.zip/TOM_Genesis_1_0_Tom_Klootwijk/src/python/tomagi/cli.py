from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from .compiler import compile_file_with_manifest
from .format import load
from .knowledge import nineteen_demo
from .core import Opcode, run
from .materialize import execute_and_materialize, state_dict


def _state_dict(state):
    return state_dict(state)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="tomagi", description="TOMAGI ABI 1.0 deterministic operator machine"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_compile = sub.add_parser("compile", help="compile a legacy or seeded JSON program to .tmg")
    p_compile.add_argument("source")
    p_compile.add_argument("destination")
    p_compile.add_argument("--manifest", help="write seeded definition/lowering manifest")

    p_run = sub.add_parser("run", help="execute a .tmg program")
    p_run.add_argument("program")
    p_run.add_argument("--ticks", type=int)
    p_run.add_argument("--trace", action="store_true")
    p_run.add_argument("--output")

    p_materialize = sub.add_parser(
        "materialize", help="execute byte-mode EMIT records and write generic materialized bytes"
    )
    p_materialize.add_argument("program")
    p_materialize.add_argument("destination")
    p_materialize.add_argument("--ticks", type=int)
    p_materialize.add_argument("--trace-output", help="write state, trace, EMIT records and digest JSON")
    p_materialize.add_argument(
        "--allow-symbolic-emits",
        action="store_true",
        help="capture symbolic EMIT records instead of rejecting them",
    )

    p_inspect = sub.add_parser("inspect", help="inspect a .tmg program")
    p_inspect.add_argument("program")

    p_knowledge = sub.add_parser("nineteen", help="run the source-derived 19/three-pulse inference")
    p_knowledge.add_argument("--output")

    args = parser.parse_args(argv)
    if args.command == "compile":
        program, manifest = compile_file_with_manifest(
            args.source, args.destination, manifest_path=args.manifest
        )
        print(
            json.dumps(
                {
                    "cells": len(program.cells),
                    "entry": program.entry,
                    "seed": program.seed,
                    "default_ticks": program.default_ticks,
                    "flags": program.flags,
                    "profile": manifest["profile_id"] if manifest else "legacy-cell-v1",
                },
                indent=2,
                sort_keys=True,
            )
        )
        return 0
    if args.command == "run":
        program = load(args.program)
        state, trace = run(program, ticks=args.ticks, trace=args.trace)
        result = {"state": _state_dict(state), "trace": trace}
        text = json.dumps(result, indent=2, sort_keys=True)
        if args.output:
            Path(args.output).write_text(text + "\n", encoding="utf-8")
        print(text)
        return 0
    if args.command == "materialize":
        program = load(args.program)
        result = execute_and_materialize(
            program,
            ticks=args.ticks,
            strict_bytes=not args.allow_symbolic_emits,
        )
        destination = Path(args.destination)
        destination.write_bytes(result.data)
        summary = result.summary()
        summary["materialized"]["path"] = str(destination)
        # Recompute from the bytes actually written so the CLI reports the file boundary.
        written = destination.read_bytes()
        summary["materialized"]["bytes"] = len(written)
        summary["materialized"]["sha256"] = hashlib.sha256(written).hexdigest()
        text = json.dumps(summary, indent=2, sort_keys=True)
        if args.trace_output:
            Path(args.trace_output).write_text(text + "\n", encoding="utf-8")
        print(
            json.dumps(
                {
                    "bytes": len(written),
                    "emits": len(result.emits),
                    "sha256": summary["materialized"]["sha256"],
                },
                indent=2,
                sort_keys=True,
            )
        )
        return 0
    if args.command == "inspect":
        program = load(args.program)
        result = {
            "cells": len(program.cells),
            "entry": program.entry,
            "seed": program.seed,
            "default_ticks": program.default_ticks,
            "flags": program.flags,
            "initial_state": _state_dict(program.initial_state),
            "opcodes": [Opcode(c.opcode).name for c in program.cells],
            "keys": [f"0x{c.key_u64:016x}" for c in program.cells],
        }
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0
    if args.command == "nineteen":
        result = nineteen_demo()
        data = {"output": result.output, "trace": result.trace}
        text = json.dumps(data, indent=2, ensure_ascii=False)
        if args.output:
            Path(args.output).write_text(text + "\n", encoding="utf-8")
        print(text)
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
