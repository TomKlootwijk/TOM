"""Generic value substitution for literal definition-source templates."""
from __future__ import annotations

import copy
from typing import Any

from .canonical import attach_hash


def _replace(value: Any, values: dict[str, Any]) -> Any:
    if isinstance(value, dict):
        if set(value) == {"$value"}:
            key = value["$value"]
            if not isinstance(key, str) or key not in values:
                raise ValueError(f"unknown template value {key!r}")
            return copy.deepcopy(values[key])
        return {key: _replace(item, values) for key, item in value.items()}
    if isinstance(value, list):
        return [_replace(item, values) for item in value]
    return value


def render_definition_template(template: dict[str, Any], values: dict[str, Any]) -> dict[str, Any]:
    """Replace exact ``{"$value": "name"}`` nodes and hash all definitions.

    The operation is intentionally unaware of the report or artifact domain.  The
    template contains field names, structure, operation choices, and byte semantics;
    the caller supplies only literal values.
    """
    rendered = _replace(template, values)
    definitions = rendered.get("definitions")
    if not isinstance(definitions, list):
        raise ValueError("definition template must contain a definitions array")
    rendered["definitions"] = [
        attach_hash({key: value for key, value in definition.items() if key != "content_hash"})
        for definition in definitions
    ]
    return rendered
