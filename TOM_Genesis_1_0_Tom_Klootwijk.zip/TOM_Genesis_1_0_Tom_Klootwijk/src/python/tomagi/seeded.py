"""Executable definition evaluator and lowering for TOM seeded profile 1.0.

This module is intentionally domain-neutral.  It provides exact seed verification,
content-addressed definition evaluation, generic byte operations, fixed-width
Cell48 construction, ordered EMIT-byte lowering, and Program construction.  PBM,
JSON, geometry, classification, and other artifact semantics remain in literal
source definitions.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable

from .canonical import canonical_bytes, verify_hash
from .core import (
    Cell,
    FLAG_EMIT_BYTES,
    FLAG_EMIT_COUNT_SHIFT,
    FLAG_EMIT_HALT,
    OPCODE_BY_NAME,
    Opcode,
    Program,
    State,
    i32,
    key_as_u64,
    pack_key_contiguous,
    popcount32,
    rotl32,
    u32,
)
from .format import dumps
from .seed import load_token_registry, parse_exact_seed

PROFILE_ID = "TOM-Seeded-Compilation-Profile-1.0"
ABI_VERSION = "1.0.0"

DEFAULT_LIMITS: dict[str, int] = {
    "max_definitions": 4096,
    "max_dependencies_per_definition": 256,
    "max_literal_bytes": 16 * 1024 * 1024,
    "max_output_bytes": 16 * 1024 * 1024,
    "max_cells": 1_048_576,
    "max_operation_steps": 2_000_000,
    "max_ticks": 2_000_000,
    "max_repeat": 1_000_000,
    "max_sequence_items": 1_000_000,
    "max_recursion_depth": 0,
}


@dataclass(frozen=True, slots=True)
class CellPlan:
    id: str
    key_hi: int
    key_lo: int
    opcode: int
    flags: int
    args: tuple[int, int, int, int]
    next_ids: tuple[str, str]
    payload: int
    aux: int
    definition_id: str
    source_offset: int | None = None
    byte_count: int | None = None
    bytes_hex: str | None = None

    @property
    def key_u64(self) -> int:
        return key_as_u64(self.key_hi, self.key_lo)

    def canonical_value(self) -> dict[str, Any]:
        value: dict[str, Any] = {
            "id": self.id,
            "key": f"0x{self.key_u64:016x}",
            "opcode": self.opcode,
            "flags": self.flags,
            "args": list(self.args),
            "next": list(self.next_ids),
            "payload": self.payload,
            "aux": self.aux,
            "definition_id": self.definition_id,
        }
        if self.source_offset is not None:
            value["source_offset"] = self.source_offset
        if self.byte_count is not None:
            value["byte_count"] = self.byte_count
        if self.bytes_hex is not None:
            value["bytes_hex"] = self.bytes_hex
        return value


@dataclass(frozen=True, slots=True)
class ProgramBundle:
    program: Program
    plans_by_index: tuple[CellPlan, ...]
    entry_id: str
    genome_flag_tag: int


@dataclass(frozen=True, slots=True)
class EvalValue:
    type_name: str
    value: Any


@dataclass(frozen=True, slots=True)
class SeededBuildResult:
    program: Program
    manifest: dict[str, Any]


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _int(value: Any, *, name: str = "integer") -> int:
    if isinstance(value, bool):
        raise ValueError(f"{name} must be an integer, not boolean")
    try:
        return int(value, 0) if isinstance(value, str) else int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"invalid {name}: {value!r}") from exc


def _u32(value: Any, *, name: str) -> int:
    number = _int(value, name=name)
    if not 0 <= number <= 0xFFFFFFFF:
        raise ValueError(f"{name} is outside u32 range")
    return number


def _i32(value: Any, *, name: str) -> int:
    number = _int(value, name=name)
    if not -(1 << 31) <= number < (1 << 31):
        raise ValueError(f"{name} is outside i32 range")
    return number


def _u64(value: Any, *, name: str) -> int:
    number = _int(value, name=name)
    if not 0 <= number <= 0xFFFFFFFFFFFFFFFF:
        raise ValueError(f"{name} is outside u64 range")
    return number


def _key_from_json(value: Any) -> tuple[int, int]:
    if isinstance(value, (str, int)):
        word = _u64(value, name="cell key")
        return (word >> 32) & 0xFFFFFFFF, word & 0xFFFFFFFF
    if isinstance(value, dict):
        allowed = {"rho", "theta", "tick", "phi"}
        extra = sorted(set(value) - allowed)
        if extra:
            raise ValueError("unknown key fields: " + ", ".join(extra))
        return pack_key_contiguous(
            _int(value.get("rho", 0), name="key.rho"),
            _int(value.get("theta", 0), name="key.theta"),
            _int(value.get("tick", 0), name="key.tick"),
            _int(value.get("phi", 0), name="key.phi"),
        )
    raise ValueError("cell key must be a u64 value or rho/theta/tick/phi object")


def _state_from_json(value: dict[str, Any]) -> State:
    if not isinstance(value, dict):
        raise ValueError("initial_state must be an object")
    known = set(State.__dataclass_fields__)
    extra = sorted(set(value) - known)
    if extra:
        raise ValueError("unknown initial_state fields: " + ", ".join(extra))
    signed = {"rho", "theta", "tick", "phi", "vrho", "vtheta", "vtick", "vphi", "residual"}
    fields: dict[str, int] = {}
    for name in known:
        raw = value.get(name, 0)
        fields[name] = _i32(raw, name=f"initial_state.{name}") if name in signed else _u32(
            raw, name=f"initial_state.{name}"
        )
    return State(**fields)


def _merge_limits(raw: Any) -> dict[str, int]:
    if raw is None:
        raw = {}
    if not isinstance(raw, dict):
        raise ValueError("limits must be an object")
    extra = sorted(set(raw) - set(DEFAULT_LIMITS))
    if extra:
        raise ValueError("unknown limits: " + ", ".join(extra))
    limits = dict(DEFAULT_LIMITS)
    for key, value in raw.items():
        limits[key] = _int(value, name=f"limits.{key}")
        if limits[key] < 0:
            raise ValueError(f"limits.{key} must be non-negative")
    if limits["max_recursion_depth"] != 0:
        raise ValueError("seeded profile 1.0 supports no recursive definition operation")
    return limits


def _validate_zero_relation(definition: dict[str, Any]) -> None:
    relation = definition.get("zero_relation")
    if not isinstance(relation, dict):
        raise ValueError(f"definition {definition.get('id')} requires zero_relation")
    required = {"interface", "domain", "codomain", "semantics", "lowering"}
    missing = sorted(required - set(relation))
    if missing:
        raise ValueError(
            f"definition {definition.get('id')} zero_relation missing: {', '.join(missing)}"
        )
    if relation["interface"] != "SDF0@Def":
        raise ValueError(f"definition {definition.get('id')} must expose SDF0@Def")
    for field in ("domain", "codomain", "semantics", "lowering"):
        if not isinstance(relation[field], str) or not relation[field]:
            raise ValueError(f"definition {definition.get('id')} zero_relation.{field} must be text")


def _definition_graph(
    definitions: Any, limits: dict[str, int]
) -> tuple[dict[str, dict[str, Any]], list[str]]:
    if not isinstance(definitions, list) or not definitions:
        raise ValueError("seeded program requires a non-empty definitions array")
    if len(definitions) > limits["max_definitions"]:
        raise ValueError("definition budget exceeded")

    by_id: dict[str, dict[str, Any]] = {}
    schedule_slot: dict[tuple[int, int], str] = {}
    for definition in definitions:
        if not isinstance(definition, dict):
            raise ValueError("every definition must be an object")
        ident = definition.get("id")
        if not isinstance(ident, str) or not ident:
            raise ValueError("every definition requires a non-empty id")
        if ident in by_id:
            raise ValueError(f"duplicate definition id {ident}")
        required = {
            "kind",
            "domain",
            "codomain",
            "phase",
            "ordinal",
            "dependencies",
            "inputs",
            "operation",
            "parameters",
            "limits",
            "provenance",
            "zero_relation",
            "content_hash",
        }
        missing = sorted(required - set(definition))
        if missing:
            raise ValueError(f"definition {ident} missing fields: {', '.join(missing)}")
        if not verify_hash(definition):
            raise ValueError(f"definition hash mismatch: {ident}")
        phase = _int(definition["phase"], name=f"{ident}.phase")
        ordinal = _int(definition["ordinal"], name=f"{ident}.ordinal")
        if not 0 <= phase <= 9:
            raise ValueError(f"definition {ident} phase must be in 0..9")
        if ordinal < 0:
            raise ValueError(f"definition {ident} ordinal must be non-negative")
        slot = (phase, ordinal)
        if slot in schedule_slot:
            raise ValueError(
                f"ambiguous definition order: {ident} and {schedule_slot[slot]} share phase/ordinal {slot}"
            )
        schedule_slot[slot] = ident
        if not isinstance(definition["dependencies"], list):
            raise ValueError(f"definition {ident} dependencies must be an array")
        if not isinstance(definition["inputs"], list):
            raise ValueError(f"definition {ident} inputs must be an array")
        deps = [str(item) for item in definition["dependencies"]]
        inputs = [str(item) for item in definition["inputs"]]
        if len(deps) > limits["max_dependencies_per_definition"]:
            raise ValueError(f"dependency budget exceeded at {ident}")
        if len(set(deps)) != len(deps):
            raise ValueError(f"duplicate dependency in {ident}")
        if len(set(inputs)) != len(inputs):
            raise ValueError(f"duplicate input in {ident}")
        if not set(inputs).issubset(deps):
            raise ValueError(f"definition {ident} inputs must be a subset of dependencies")
        if not isinstance(definition["operation"], str):
            raise ValueError(f"definition {ident} operation must be a string")
        if not isinstance(definition["parameters"], dict):
            raise ValueError(f"definition {ident} parameters must be an object")
        if not isinstance(definition["limits"], dict):
            raise ValueError(f"definition {ident} limits must be an object")
        if not isinstance(definition["provenance"], dict):
            raise ValueError(f"definition {ident} provenance must be an object")
        _validate_zero_relation(definition)
        by_id[ident] = definition

    indegree = {ident: 0 for ident in by_id}
    children: dict[str, list[str]] = {ident: [] for ident in by_id}
    for ident, definition in by_id.items():
        for dep in definition["dependencies"]:
            if dep not in by_id:
                raise ValueError(f"unknown dependency {dep} from {ident}")
            indegree[ident] += 1
            children[dep].append(ident)

    ready = sorted(
        (int(by_id[i]["phase"]), int(by_id[i]["ordinal"]), i)
        for i, degree in indegree.items()
        if degree == 0
    )
    order: list[str] = []
    while ready:
        _, _, ident = ready.pop(0)
        order.append(ident)
        for child in children[ident]:
            indegree[child] -= 1
            if indegree[child] == 0:
                ready.append(
                    (int(by_id[child]["phase"]), int(by_id[child]["ordinal"]), child)
                )
                ready.sort()
    if len(order) != len(by_id):
        cyclic = sorted(ident for ident, degree in indegree.items() if degree > 0)
        raise ValueError("definition dependency cycle: " + ", ".join(cyclic))

    # The graph is acyclic; now enforce the explicit non-ambiguous phase schedule.
    for ident, definition in by_id.items():
        position = (_int(definition["phase"]), _int(definition["ordinal"]))
        for dep in definition["dependencies"]:
            dep_def = by_id[dep]
            dep_position = (_int(dep_def["phase"]), _int(dep_def["ordinal"]))
            if dep_position >= position:
                raise ValueError(
                    f"dependency schedule violation: {dep} must precede {ident}"
                )
    return by_id, order


def _reachable(by_id: dict[str, dict[str, Any]], root: str) -> set[str]:
    if root not in by_id:
        raise ValueError(f"root definition {root} does not exist")
    seen: set[str] = set()
    stack = [root]
    while stack:
        ident = stack.pop()
        if ident in seen:
            continue
        seen.add(ident)
        stack.extend(by_id[ident]["dependencies"])
    return seen


def _check_input_types(
    ident: str,
    inputs: list[tuple[str, EvalValue]],
    *,
    count: int | tuple[int, None],
    allowed: set[str] | None = None,
) -> None:
    if isinstance(count, int):
        if len(inputs) != count:
            raise ValueError(f"operation at {ident} requires exactly {count} value inputs")
    else:
        minimum, _ = count
        if len(inputs) < minimum:
            raise ValueError(f"operation at {ident} requires at least {minimum} value inputs")
    if allowed is not None:
        bad = [(input_id, value.type_name) for input_id, value in inputs if value.type_name not in allowed]
        if bad:
            details = ", ".join(f"{input_id}:{type_name}" for input_id, type_name in bad)
            raise ValueError(f"type mismatch at {ident}: {details}")


def _json_clone(value: Any) -> Any:
    """Return an exact JSON-domain clone or reject non-JSON values."""
    try:
        return json.loads(canonical_bytes(value))
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise ValueError("value is outside the canonical JSON domain") from exc


def _int_input(ident: str, input_id: str, value: EvalValue) -> int:
    if value.type_name not in {"int", "bit"}:
        raise ValueError(f"type mismatch at {ident}: {input_id}:{value.type_name}")
    return _int(value.value, name=f"{ident}.{input_id}")


def _sequence_length(value: EvalValue) -> int:
    if value.type_name in {"bytes", "string", "array"}:
        return len(value.value)
    raise ValueError(f"{value.type_name} is not a sequence type")


def _ensure_sequence_budget(value: EvalValue, limits: dict[str, int], ident: str) -> None:
    if value.type_name in {"bytes", "string", "array"}:
        length = _sequence_length(value)
        if length > limits["max_sequence_items"]:
            raise ValueError(f"sequence item budget exceeded at {ident}")


def _sequence_concat(ident: str, inputs: list[tuple[str, EvalValue]]) -> EvalValue:
    _check_input_types(ident, inputs, count=(1, None), allowed={"bytes", "string", "array"})
    types = {value.type_name for _, value in inputs}
    if len(types) != 1:
        details = ", ".join(f"{input_id}:{value.type_name}" for input_id, value in inputs)
        raise ValueError(f"sequence.concat at {ident} requires one common type: {details}")
    type_name = next(iter(types))
    if type_name == "bytes":
        return EvalValue("bytes", b"".join(value.value for _, value in inputs))
    if type_name == "string":
        return EvalValue("string", "".join(value.value for _, value in inputs))
    result: list[Any] = []
    for _, value in inputs:
        result.extend(_json_clone(value.value))
    return EvalValue("array", result)


def _sequence_slice(ident: str, value: EvalValue, parameters: dict[str, Any]) -> EvalValue:
    if value.type_name not in {"bytes", "string", "array"}:
        raise ValueError(f"type mismatch at {ident}: sequence:{value.type_name}")
    start = _int(parameters.get("start", 0), name=f"{ident}.start")
    stop_raw = parameters.get("stop")
    stop = None if stop_raw is None else _int(stop_raw, name=f"{ident}.stop")
    if start < 0 or (stop is not None and stop < 0):
        raise ValueError(f"sequence.slice at {ident} does not accept negative bounds")
    sliced = value.value[start:stop]
    return EvalValue(value.type_name, _json_clone(sliced) if value.type_name == "array" else sliced)


def _sequence_repeat(
    ident: str,
    value: EvalValue,
    parameters: dict[str, Any],
    limits: dict[str, int],
) -> EvalValue:
    if value.type_name not in {"bytes", "string", "array"}:
        raise ValueError(f"type mismatch at {ident}: sequence:{value.type_name}")
    count = _int(parameters.get("count"), name=f"{ident}.count")
    if not 0 <= count <= limits["max_repeat"]:
        raise ValueError("repeat budget exceeded")
    repeated = value.value * count
    result = EvalValue(
        value.type_name,
        _json_clone(repeated) if value.type_name == "array" else repeated,
    )
    _ensure_sequence_budget(result, limits, ident)
    return result


def _indexed_map(
    ident: str,
    value: EvalValue,
    parameters: dict[str, Any],
    limits: dict[str, int],
) -> EvalValue:
    if value.type_name != "array":
        raise ValueError(f"type mismatch at {ident}: sequence:{value.type_name}")
    items = _json_clone(value.value)
    if len(items) > limits["max_sequence_items"]:
        raise ValueError(f"sequence item budget exceeded at {ident}")
    operator = parameters.get("operator")
    if operator == "identity":
        mapped = items
    elif operator == "index":
        mapped = list(range(len(items)))
    elif operator == "pair":
        mapped = [[index, item] for index, item in enumerate(items)]
    elif operator in {"u32.add_index", "u32.xor_index"}:
        mapped = []
        for index, item in enumerate(items):
            number = _int(item, name=f"{ident}[{index}]")
            if operator == "u32.add_index":
                mapped.append(u32(number + index))
            else:
                mapped.append(u32(number) ^ u32(index))
    else:
        raise ValueError(
            f"sequence.indexed_map at {ident} requires operator identity, index, pair, "
            "u32.add_index, or u32.xor_index"
        )
    result = EvalValue("array", mapped)
    _ensure_sequence_budget(result, limits, ident)
    return result


def _enforce_definition_limits(definition: dict[str, Any], value: EvalValue) -> None:
    """Enforce recognized per-definition limits against the evaluated value.

    These limits are part of the hashed definition, not comments.  Profile 1.0
    rejects unknown keys so that a purported limit cannot be silently ignored.
    """
    ident = definition["id"]
    declared = definition["limits"]
    allowed_by_type: dict[str, set[str]] = {
        "bytes": {"bytes", "min_bytes", "max_bytes"},
        "string": {"characters", "min_characters", "max_characters"},
        "array": {"items", "min_items", "max_items"},
        "record": {"fields", "min_fields", "max_fields"},
        "json": {"canonical_bytes", "max_canonical_bytes"},
        "int": {"min_value", "max_value"},
        "bit": {"value"},
        "state": {"words"},
        "cell": {"cells"},
        "cells": {"cells", "min_cells", "max_cells", "bytes_per_cell"},
        "program": {"cells", "min_cells", "max_cells"},
    }
    allowed = allowed_by_type.get(value.type_name)
    if allowed is None:
        raise AssertionError(f"unhandled limit type {value.type_name}")
    unknown = sorted(set(declared) - allowed)
    if unknown:
        raise ValueError(f"unknown definition limits at {ident}: {', '.join(unknown)}")

    def check_exact(name: str, actual: int) -> None:
        if name in declared and actual != _int(declared[name], name=f"{ident}.limits.{name}"):
            raise ValueError(
                f"definition limit mismatch at {ident}: {name} expected {declared[name]}, got {actual}"
            )

    def check_range(prefix: str, actual: int) -> None:
        minimum = f"min_{prefix}"
        maximum = f"max_{prefix}"
        if minimum in declared and actual < _int(declared[minimum], name=f"{ident}.limits.{minimum}"):
            raise ValueError(f"definition limit underflow at {ident}: {minimum}")
        if maximum in declared and actual > _int(declared[maximum], name=f"{ident}.limits.{maximum}"):
            raise ValueError(f"definition limit overflow at {ident}: {maximum}")

    if value.type_name == "bytes":
        check_exact("bytes", len(value.value))
        check_range("bytes", len(value.value))
    elif value.type_name == "string":
        check_exact("characters", len(value.value))
        check_range("characters", len(value.value))
    elif value.type_name == "array":
        check_exact("items", len(value.value))
        check_range("items", len(value.value))
    elif value.type_name == "record":
        check_exact("fields", len(value.value))
        check_range("fields", len(value.value))
    elif value.type_name == "json":
        length = len(canonical_bytes(value.value))
        check_exact("canonical_bytes", length)
        if "max_canonical_bytes" in declared and length > _int(
            declared["max_canonical_bytes"], name=f"{ident}.limits.max_canonical_bytes"
        ):
            raise ValueError(f"definition limit overflow at {ident}: max_canonical_bytes")
    elif value.type_name == "int":
        number = _int(value.value)
        if "min_value" in declared and number < _int(declared["min_value"]):
            raise ValueError(f"definition limit underflow at {ident}: min_value")
        if "max_value" in declared and number > _int(declared["max_value"]):
            raise ValueError(f"definition limit overflow at {ident}: max_value")
    elif value.type_name == "bit":
        check_exact("value", _int(value.value))
    elif value.type_name == "state":
        check_exact("words", 16)
    elif value.type_name == "cell":
        check_exact("cells", 1)
    elif value.type_name in {"cells", "program"}:
        count = len(value.value) if value.type_name == "cells" else len(value.value.program.cells)
        check_exact("cells", count)
        check_range("cells", count)
        if value.type_name == "cells" and "bytes_per_cell" in declared:
            bounds = declared["bytes_per_cell"]
            if not isinstance(bounds, list) or len(bounds) != 2:
                raise ValueError(f"{ident}.limits.bytes_per_cell must be [minimum, maximum]")
            minimum = _int(bounds[0], name=f"{ident}.limits.bytes_per_cell[0]")
            maximum = _int(bounds[1], name=f"{ident}.limits.bytes_per_cell[1]")
            if not 1 <= minimum <= maximum <= 4:
                raise ValueError(f"{ident}.limits.bytes_per_cell must be within 1..4")
            for plan in value.value:
                if plan.byte_count is None or not minimum <= plan.byte_count <= maximum:
                    raise ValueError(f"definition byte-per-cell limit mismatch at {ident}")


def _cell_plan(definition: dict[str, Any]) -> CellPlan:
    ident = definition["id"]
    p = definition["parameters"]
    cell_id = str(p.get("cell_id", ident))
    hi, lo = _key_from_json(p.get("key"))
    raw_op = p.get("op")
    if isinstance(raw_op, str):
        try:
            opcode = int(OPCODE_BY_NAME[raw_op.upper()])
        except KeyError as exc:
            raise ValueError(f"unknown opcode {raw_op} at {ident}") from exc
    else:
        try:
            opcode = int(Opcode(_int(raw_op, name=f"{ident}.op")))
        except (ValueError, TypeError) as exc:
            raise ValueError(f"invalid opcode at {ident}") from exc
    args = p.get("args", [0, 0, 0, 0])
    if not isinstance(args, list) or len(args) != 4:
        raise ValueError(f"cell definition {ident} requires four args")
    next_ids = p.get("next")
    if not isinstance(next_ids, list) or len(next_ids) != 2:
        raise ValueError(f"cell definition {ident} requires two successor IDs")
    flags = _u32(p.get("flags", 0), name=f"{ident}.flags")
    plan = CellPlan(
        id=cell_id,
        key_hi=hi,
        key_lo=lo,
        opcode=opcode,
        flags=flags,
        args=tuple(_i32(v, name=f"{ident}.arg{index}") for index, v in enumerate(args)),  # type: ignore[arg-type]
        next_ids=(str(next_ids[0]), str(next_ids[1])),
        payload=_u32(p.get("payload", 0), name=f"{ident}.payload"),
        aux=_u32(p.get("aux", 0), name=f"{ident}.aux"),
        definition_id=ident,
    )
    lowering = definition["zero_relation"]["lowering"]
    if opcode == Opcode.SDF0 and lowering != "SDF0":
        raise ValueError(f"SDF0 cell definition {ident} must declare zero_relation lowering SDF0")
    if opcode == Opcode.CONE and lowering != "CONE":
        raise ValueError(f"CONE cell definition {ident} must declare zero_relation lowering CONE")
    if opcode == Opcode.SPHERE and lowering != "SPHERE":
        raise ValueError(f"SPHERE cell definition {ident} must declare zero_relation lowering SPHERE")
    return plan


def _emit_byte_cells(definition: dict[str, Any], data: bytes, limits: dict[str, int]) -> list[CellPlan]:
    ident = definition["id"]
    p = definition["parameters"]
    if not data:
        raise ValueError(f"tomagi.emit_bytes at {ident} cannot emit an empty byte sequence")
    if len(data) > limits["max_output_bytes"]:
        raise ValueError("output byte budget exceeded")
    key_start = _u64(p.get("key_start", 0), name=f"{ident}.key_start")
    prefix = str(p.get("cell_id_prefix", ident + "#emit"))
    halt = p.get("halt", True)
    if not isinstance(halt, bool):
        raise ValueError(f"{ident}.halt must be boolean")
    count_cells = (len(data) + 3) // 4
    if count_cells > limits["max_cells"]:
        raise ValueError("cell budget exceeded")
    if key_start + count_cells - 1 > 0xFFFFFFFFFFFFFFFF:
        raise ValueError("EMIT key range exceeds u64")

    plans: list[CellPlan] = []
    ids = [f"{prefix}:{index:06d}" for index in range(count_cells)]
    for index in range(count_cells):
        offset = index * 4
        chunk = data[offset : offset + 4]
        count = len(chunk)
        payload = int.from_bytes(chunk.ljust(4, b"\0"), "little")
        final = index == count_cells - 1
        flags = FLAG_EMIT_BYTES | ((count - 1) << FLAG_EMIT_COUNT_SHIFT)
        if final and halt:
            flags |= FLAG_EMIT_HALT
        word = key_start + index
        next_id = ids[index] if final else ids[index + 1]
        plans.append(
            CellPlan(
                id=ids[index],
                key_hi=(word >> 32) & 0xFFFFFFFF,
                key_lo=word & 0xFFFFFFFF,
                opcode=int(Opcode.EMIT),
                flags=flags,
                args=(0, 0, 0, 0),
                next_ids=(next_id, next_id),
                payload=payload,
                aux=offset,
                definition_id=ident,
                source_offset=offset,
                byte_count=count,
                bytes_hex=chunk.hex(),
            )
        )
    return plans


def _flatten_cells(inputs: Iterable[tuple[str, EvalValue]], ident: str) -> list[CellPlan]:
    cells: list[CellPlan] = []
    for input_id, value in inputs:
        if value.type_name == "cell":
            cells.append(value.value)
        elif value.type_name == "cells":
            cells.extend(value.value)
        else:
            raise ValueError(f"type mismatch at {ident}: {input_id}:{value.type_name}")
    return cells


def _program_bundle(
    definition: dict[str, Any],
    inputs: list[tuple[str, EvalValue]],
    *,
    seed_bytes: bytes,
    seed_sha256: str,
    limits: dict[str, int],
) -> ProgramBundle:
    ident = definition["id"]
    p = definition["parameters"]
    seed_input = p.get("seed_input")
    if not isinstance(seed_input, str):
        raise ValueError(f"tomagi.program at {ident} requires parameters.seed_input")
    input_map = dict(inputs)
    if seed_input not in input_map or input_map[seed_input].type_name != "bytes":
        raise ValueError(f"tomagi.program at {ident} seed_input must name a bytes input")
    if input_map[seed_input].value != seed_bytes:
        raise ValueError(f"tomagi.program at {ident} is not bound to canonical seed bytes")

    state_input = p.get("state_input")
    if state_input is not None and not isinstance(state_input, str):
        raise ValueError(f"tomagi.program at {ident} state_input must be text")
    if state_input is not None:
        if state_input not in input_map or input_map[state_input].type_name != "state":
            raise ValueError(f"tomagi.program at {ident} state_input must name a state input")
        if "initial_state" in p:
            raise ValueError(f"tomagi.program at {ident} cannot declare both state_input and initial_state")

    excluded_inputs = {seed_input}
    if state_input is not None:
        excluded_inputs.add(state_input)
    cell_inputs = [(name, value) for name, value in inputs if name not in excluded_inputs]
    if not cell_inputs:
        raise ValueError(f"tomagi.program at {ident} requires at least one cell input")
    plans = _flatten_cells(cell_inputs, ident)
    if not plans:
        raise ValueError(f"tomagi.program at {ident} produced no cells")
    if len(plans) > limits["max_cells"]:
        raise ValueError("cell budget exceeded")

    ids = [plan.id for plan in plans]
    if len(set(ids)) != len(ids):
        duplicates = sorted({item for item in ids if ids.count(item) > 1})
        raise ValueError("duplicate cell id: " + ", ".join(duplicates))
    keys = [plan.key_u64 for plan in plans]
    if len(set(keys)) != len(keys):
        duplicates = sorted({value for value in keys if keys.count(value) > 1})
        raise ValueError(
            "duplicate canonical cell key: " + ", ".join(f"0x{value:016x}" for value in duplicates)
        )

    sorted_plans = sorted(plans, key=lambda plan: plan.key_u64)
    index_by_id = {plan.id: index for index, plan in enumerate(sorted_plans)}
    for plan in sorted_plans:
        for target in plan.next_ids:
            if target not in index_by_id:
                raise ValueError(f"cell {plan.id} references unknown successor {target}")

    entry_id = str(p.get("entry", sorted_plans[0].id))
    if entry_id not in index_by_id:
        raise ValueError(f"entry cell {entry_id} does not exist")
    runtime_seed = _u32(p.get("runtime_seed", 0), name=f"{ident}.runtime_seed")
    default_ticks = _int(p.get("default_ticks", len(sorted_plans)), name=f"{ident}.default_ticks")
    if not 0 <= default_ticks <= limits["max_ticks"]:
        raise ValueError("tick budget exceeded")
    base_flags = _u32(p.get("program_flags", 0), name=f"{ident}.program_flags")
    if p.get("bind_genome_hash_to_flags") is not True:
        raise ValueError("seeded conformance mode requires bind_genome_hash_to_flags=true")
    genome_tag = int.from_bytes(bytes.fromhex(seed_sha256)[:4], "little")
    program_flags = u32(base_flags ^ genome_tag)

    initial_state = (
        replace(input_map[state_input].value)
        if state_input is not None
        else _state_from_json(p.get("initial_state", {}))
    )
    initial_state.cell = index_by_id[entry_id]
    cells = [
        Cell(
            plan.key_hi,
            plan.key_lo,
            plan.opcode,
            plan.flags,
            plan.args[0],
            plan.args[1],
            plan.args[2],
            plan.args[3],
            index_by_id[plan.next_ids[0]],
            index_by_id[plan.next_ids[1]],
            plan.payload,
            plan.aux,
        )
        for plan in sorted_plans
    ]
    program = Program(
        cells=cells,
        entry=index_by_id[entry_id],
        seed=runtime_seed,
        default_ticks=default_ticks,
        initial_state=initial_state,
        flags=program_flags,
    )
    return ProgramBundle(
        program=program,
        plans_by_index=tuple(sorted_plans),
        entry_id=entry_id,
        genome_flag_tag=genome_tag,
    )


def _evaluate(
    definition: dict[str, Any],
    inputs: list[tuple[str, EvalValue]],
    *,
    seed_bytes: bytes,
    seed_sha256: str,
    limits: dict[str, int],
) -> EvalValue:
    ident = definition["id"]
    op = definition["operation"]
    codomain = definition["codomain"]
    p = definition["parameters"]
    if not isinstance(codomain, str) or not codomain:
        raise ValueError(f"definition {ident} codomain must be a non-empty string")

    if op == "seed.bytes":
        _check_input_types(ident, inputs, count=0)
        result = EvalValue("bytes", seed_bytes)
    elif op == "literal.utf8":
        _check_input_types(ident, inputs, count=0)
        text = p.get("text")
        if not isinstance(text, str):
            raise ValueError(f"literal.utf8 at {ident} requires parameters.text")
        result = EvalValue("bytes", text.encode("utf-8"))
    elif op == "literal.hex":
        _check_input_types(ident, inputs, count=0)
        value = p.get("hex")
        if not isinstance(value, str):
            raise ValueError(f"literal.hex at {ident} requires parameters.hex")
        try:
            result = EvalValue("bytes", bytes.fromhex(value))
        except ValueError as exc:
            raise ValueError(f"invalid hex literal at {ident}") from exc
    elif op == "literal.json":
        _check_input_types(ident, inputs, count=0)
        if "value" not in p:
            raise ValueError(f"literal.json at {ident} requires parameters.value")
        # Round-trip through canonical JSON to forbid non-JSON Python values.
        result = EvalValue("json", json.loads(canonical_bytes(p["value"])))
    elif op == "literal.int":
        _check_input_types(ident, inputs, count=0)
        result = EvalValue("int", _int(p.get("value"), name=f"{ident}.value"))
    elif op == "literal.string":
        _check_input_types(ident, inputs, count=0)
        value = p.get("value")
        if not isinstance(value, str):
            raise ValueError(f"literal.string at {ident} requires parameters.value text")
        result = EvalValue("string", value)
    elif op == "literal.array":
        _check_input_types(ident, inputs, count=0)
        value = p.get("value")
        if not isinstance(value, list):
            raise ValueError(f"literal.array at {ident} requires parameters.value array")
        result = EvalValue("array", _json_clone(value))
    elif op == "literal.record":
        _check_input_types(ident, inputs, count=0)
        value = p.get("value")
        if not isinstance(value, dict):
            raise ValueError(f"literal.record at {ident} requires parameters.value object")
        result = EvalValue("record", _json_clone(value))
    elif op == "string.utf8":
        _check_input_types(ident, inputs, count=1, allowed={"string"})
        result = EvalValue("bytes", inputs[0][1].value.encode("utf-8"))
    elif op == "bytes.concat":
        _check_input_types(ident, inputs, count=(1, None), allowed={"bytes"})
        result = EvalValue("bytes", b"".join(value.value for _, value in inputs))
    elif op == "bytes.slice":
        _check_input_types(ident, inputs, count=1, allowed={"bytes"})
        start = _int(p.get("start", 0), name=f"{ident}.start")
        stop_raw = p.get("stop")
        stop = None if stop_raw is None else _int(stop_raw, name=f"{ident}.stop")
        if start < 0 or (stop is not None and stop < 0):
            raise ValueError(f"bytes.slice at {ident} does not accept negative bounds")
        result = EvalValue("bytes", inputs[0][1].value[start:stop])
    elif op == "bytes.repeat":
        _check_input_types(ident, inputs, count=1, allowed={"bytes"})
        count = _int(p.get("count"), name=f"{ident}.count")
        if not 0 <= count <= limits["max_repeat"]:
            raise ValueError("repeat budget exceeded")
        result = EvalValue("bytes", inputs[0][1].value * count)
    elif op == "sequence.concat":
        result = _sequence_concat(ident, inputs)
    elif op == "sequence.slice":
        _check_input_types(ident, inputs, count=1)
        result = _sequence_slice(ident, inputs[0][1], p)
    elif op == "sequence.repeat":
        _check_input_types(ident, inputs, count=1)
        result = _sequence_repeat(ident, inputs[0][1], p, limits)
    elif op == "sequence.indexed_map":
        _check_input_types(ident, inputs, count=1)
        result = _indexed_map(ident, inputs[0][1], p, limits)
    elif op in {
        "u32.normalize",
        "i32.normalize",
        "u32.popcount",
        "bit.parity",
        "predicate.zero",
    }:
        _check_input_types(ident, inputs, count=1)
        number = _int_input(ident, inputs[0][0], inputs[0][1])
        if op == "u32.normalize":
            result = EvalValue("int", u32(number))
        elif op == "i32.normalize":
            result = EvalValue("int", i32(number))
        elif op == "u32.popcount":
            result = EvalValue("int", popcount32(number))
        elif op == "bit.parity":
            result = EvalValue("bit", popcount32(number) & 1)
        else:
            result = EvalValue("bit", 1 if number == 0 else 0)
    elif op in {
        "u32.add",
        "u32.xor",
        "u32.and",
        "u32.or",
        "u32.shl",
        "u32.shr",
        "u32.rotl",
        "predicate.le",
    }:
        _check_input_types(ident, inputs, count=2)
        left = _int_input(ident, inputs[0][0], inputs[0][1])
        right = _int_input(ident, inputs[1][0], inputs[1][1])
        if op == "u32.add":
            result = EvalValue("int", u32(left + right))
        elif op == "u32.xor":
            result = EvalValue("int", u32(left) ^ u32(right))
        elif op == "u32.and":
            result = EvalValue("int", u32(left) & u32(right))
        elif op == "u32.or":
            result = EvalValue("int", u32(left) | u32(right))
        elif op == "u32.shl":
            result = EvalValue("int", u32(u32(left) << (right & 31)))
        elif op == "u32.shr":
            result = EvalValue("int", u32(left) >> (right & 31))
        elif op == "u32.rotl":
            result = EvalValue("int", rotl32(left, right))
        else:
            result = EvalValue("bit", 1 if left <= right else 0)
    elif op == "predicate.eq":
        _check_input_types(ident, inputs, count=2)
        if inputs[0][1].type_name != inputs[1][1].type_name:
            raise ValueError(
                f"predicate.eq at {ident} requires equal input types, got "
                f"{inputs[0][1].type_name} and {inputs[1][1].type_name}"
            )
        result = EvalValue("bit", 1 if inputs[0][1].value == inputs[1][1].value else 0)
    elif op == "select.binary":
        _check_input_types(ident, inputs, count=3)
        selector = _int_input(ident, inputs[0][0], inputs[0][1])
        if selector not in {0, 1}:
            raise ValueError(f"select.binary at {ident} selector must be 0 or 1")
        false_value = inputs[1][1]
        true_value = inputs[2][1]
        if false_value.type_name != true_value.type_name:
            raise ValueError(
                f"select.binary at {ident} route types differ: "
                f"{false_value.type_name} and {true_value.type_name}"
            )
        selected = true_value if selector else false_value
        if selected.type_name in {"array", "record", "json"}:
            selected_value = _json_clone(selected.value)
        elif selected.type_name == "state":
            selected_value = replace(selected.value)
        else:
            selected_value = selected.value
        result = EvalValue(selected.type_name, selected_value)
    elif op == "json.canonical_bytes":
        _check_input_types(
            ident,
            inputs,
            count=1,
            allowed={"json", "string", "array", "record", "int", "bit"},
        )
        data = canonical_bytes(inputs[0][1].value)
        terminal_newline = p.get("terminal_newline", False)
        if not isinstance(terminal_newline, bool):
            raise ValueError(f"{ident}.terminal_newline must be boolean")
        if terminal_newline:
            data += b"\n"
        result = EvalValue("bytes", data)
    elif op == "tomagi.cell":
        _check_input_types(ident, inputs, count=0)
        result = EvalValue("cell", _cell_plan(definition))
    elif op == "tomagi.state64":
        _check_input_types(ident, inputs, count=0)
        fields = p.get("fields", p)
        if not isinstance(fields, dict):
            raise ValueError(f"tomagi.state64 at {ident} requires parameters.fields")
        result = EvalValue("state", _state_from_json(fields))
    elif op in {"tomagi.cells.concat", "tomagi.graph.sequence"}:
        _check_input_types(ident, inputs, count=(1, None), allowed={"cell", "cells"})
        result = EvalValue("cells", _flatten_cells(inputs, ident))
    elif op == "tomagi.emit_bytes":
        _check_input_types(ident, inputs, count=1, allowed={"bytes"})
        result = EvalValue("cells", _emit_byte_cells(definition, inputs[0][1].value, limits))
    elif op == "tomagi.program":
        _check_input_types(
            ident,
            inputs,
            count=(2, None),
            allowed={"bytes", "state", "cell", "cells"},
        )
        result = EvalValue(
            "program",
            _program_bundle(
                definition,
                inputs,
                seed_bytes=seed_bytes,
                seed_sha256=seed_sha256,
                limits=limits,
            ),
        )
    else:
        raise ValueError(f"unknown formal operation {op} at {ident}")

    if result.type_name != codomain:
        raise ValueError(
            f"codomain mismatch at {ident}: declared {codomain}, operation produced {result.type_name}"
        )
    _ensure_sequence_budget(result, limits, ident)
    _enforce_definition_limits(definition, result)
    return result


def _value_manifest(value: EvalValue) -> dict[str, Any]:
    if value.type_name == "bytes":
        data: bytes = value.value
        return {"type": "bytes", "bytes": len(data), "sha256": _sha256(data)}
    if value.type_name == "int":
        data = canonical_bytes(value.value)
        return {"type": "int", "sha256": _sha256(data), "value": value.value}
    if value.type_name == "bit":
        data = canonical_bytes(value.value)
        return {"type": "bit", "sha256": _sha256(data), "value": value.value}
    if value.type_name == "string":
        data = value.value.encode("utf-8")
        return {
            "type": "string",
            "characters": len(value.value),
            "utf8_bytes": len(data),
            "sha256": _sha256(data),
        }
    if value.type_name in {"array", "record"}:
        data = canonical_bytes(value.value)
        return {
            "type": value.type_name,
            "items" if value.type_name == "array" else "fields": len(value.value),
            "canonical_bytes": len(data),
            "sha256": _sha256(data),
        }
    if value.type_name == "json":
        data = canonical_bytes(value.value)
        return {"type": "json", "bytes": len(data), "sha256": _sha256(data)}
    if value.type_name == "state":
        words = value.value.words()
        data = canonical_bytes(words)
        return {"type": "state", "words": words, "sha256": _sha256(data)}
    if value.type_name == "cell":
        data = canonical_bytes(value.value.canonical_value())
        return {"type": "cell", "sha256": _sha256(data), "cell_count": 1}
    if value.type_name == "cells":
        canonical = [plan.canonical_value() for plan in value.value]
        data = canonical_bytes(canonical)
        return {"type": "cells", "sha256": _sha256(data), "cell_count": len(canonical)}
    if value.type_name == "program":
        bundle: ProgramBundle = value.value
        data = dumps(bundle.program)
        return {"type": "program", "bytes": len(data), "sha256": _sha256(data)}
    raise AssertionError(f"unhandled value type {value.type_name}")


def compile_seeded_document(
    document: dict[str, Any],
    *,
    base_dir: str | Path,
) -> SeededBuildResult:
    """Compile a seeded-profile document into a TOMAGI ABI 1.0 program and manifest."""
    if document.get("tomagi_version") != ABI_VERSION:
        raise ValueError("tomagi_version must be 1.0.0")
    if "cells" in document:
        raise ValueError("seeded conformance mode rejects handwritten top-level cells")
    if document.get("compilation_profile") != PROFILE_ID:
        raise ValueError(f"compilation_profile must be {PROFILE_ID}")
    base = Path(base_dir)
    limits = _merge_limits(document.get("limits"))

    seed_decl = document.get("seed_genome")
    if not isinstance(seed_decl, dict):
        raise ValueError("seed_genome must be an object")
    seed_rel = seed_decl.get("file")
    if not isinstance(seed_rel, str) or not seed_rel:
        raise ValueError("seed_genome.file must be a relative path")
    if Path(seed_rel).is_absolute():
        raise ValueError("seed_genome.file must be relative")
    expected_seed_hash = seed_decl.get("sha256")
    expected_seed_length = seed_decl.get("bytes")
    if not isinstance(expected_seed_hash, str):
        raise ValueError("seed_genome.sha256 must be text")
    seed_bytes = (base / seed_rel).read_bytes()
    parsed_seed = parse_exact_seed(
        seed_bytes,
        expected_length=_int(expected_seed_length, name="seed_genome.bytes"),
        expected_sha256=expected_seed_hash,
    )

    registry_decl = document.get("token_registry")
    if not isinstance(registry_decl, dict):
        raise ValueError("token_registry must be an object")
    registry_rel = registry_decl.get("file")
    if not isinstance(registry_rel, str) or not registry_rel:
        raise ValueError("token_registry.file must be a relative path")
    if Path(registry_rel).is_absolute():
        raise ValueError("token_registry.file must be relative")
    registry = load_token_registry(base / registry_rel, parsed_seed)
    expected_registry_hash = registry_decl.get("content_hash")
    if registry.get("content_hash") != expected_registry_hash:
        raise ValueError("token registry declared content_hash mismatch")

    by_id, order = _definition_graph(document.get("definitions"), limits)
    root = document.get("root_definition")
    if not isinstance(root, str):
        raise ValueError("root_definition must be a string")
    reachable = _reachable(by_id, root)
    unreachable = sorted(set(by_id) - reachable)
    if unreachable:
        raise ValueError("unreachable definitions are not executable inputs: " + ", ".join(unreachable))
    if order[-1] != root:
        # This follows from the strict phase/ordinal schedule and all definitions being
        # reachable, but keep an explicit conformance diagnostic.
        raise ValueError("root definition must be the final scheduled definition")

    values: dict[str, EvalValue] = {}
    definition_manifest: list[dict[str, Any]] = []
    literal_bytes = 0
    operation_steps = 0
    for ident in order:
        definition = by_id[ident]
        inputs = [(input_id, values[input_id]) for input_id in definition["inputs"]]
        value = _evaluate(
            definition,
            inputs,
            seed_bytes=seed_bytes,
            seed_sha256=parsed_seed.sha256,
            limits=limits,
        )
        values[ident] = value
        output = _value_manifest(value)
        if definition["operation"] in {
            "literal.utf8",
            "literal.hex",
            "literal.json",
            "literal.int",
            "literal.string",
            "literal.array",
            "literal.record",
        }:
            if value.type_name == "bytes":
                literal_bytes += len(value.value)
            elif value.type_name == "string":
                literal_bytes += len(value.value.encode("utf-8"))
            else:
                literal_bytes += len(canonical_bytes(value.value))
            if literal_bytes > limits["max_literal_bytes"]:
                raise ValueError("literal byte budget exceeded")
        operation_steps += 1
        if value.type_name == "cells":
            operation_steps += len(value.value)
        elif value.type_name in {"bytes", "string", "array"}:
            operation_steps += len(value.value)
        if operation_steps > limits["max_operation_steps"]:
            raise ValueError("operation step budget exceeded")
        definition_manifest.append(
            {
                "id": ident,
                "content_hash": definition["content_hash"],
                "kind": definition["kind"],
                "operation": definition["operation"],
                "phase": int(definition["phase"]),
                "ordinal": int(definition["ordinal"]),
                "dependencies": list(definition["dependencies"]),
                "inputs": list(definition["inputs"]),
                "domain": definition["domain"],
                "codomain": definition["codomain"],
                "zero_relation": definition["zero_relation"],
                "output": output,
            }
        )

    root_value = values[root]
    if root_value.type_name != "program":
        raise ValueError("root_definition must evaluate to codomain program")
    bundle: ProgramBundle = root_value.value
    program_blob = dumps(bundle.program)

    cells_manifest: list[dict[str, Any]] = []
    for index, (plan, cell) in enumerate(zip(bundle.plans_by_index, bundle.program.cells, strict=True)):
        item = {
            "index": index,
            "cell_id": plan.id,
            "definition_id": plan.definition_id,
            "key": f"0x{plan.key_u64:016x}",
            "opcode": Opcode(cell.opcode).name,
            "flags": cell.flags,
            "args": [cell.arg0, cell.arg1, cell.arg2, cell.arg3],
            "next0": cell.next0,
            "next1": cell.next1,
            "next_ids": list(plan.next_ids),
            "payload": cell.payload,
            "aux": cell.aux,
        }
        if plan.source_offset is not None:
            item["source_offset"] = plan.source_offset
            item["byte_count"] = plan.byte_count
            item["bytes_hex"] = plan.bytes_hex
        cells_manifest.append(item)

    manifest: dict[str, Any] = {
        "schema": "TOM-SEEDED-COMPILATION-MANIFEST-1.0",
        "profile_id": PROFILE_ID,
        "tomagi_abi": ABI_VERSION,
        "source_document": {
            "canonical_bytes": len(canonical_bytes(document)),
            "sha256": _sha256(canonical_bytes(document)),
        },
        "seed": {
            "declared_file": seed_rel,
            **parsed_seed.as_dict(),
        },
        "token_registry": {
            "declared_file": registry_rel,
            "profile_id": registry["profile_id"],
            "content_hash": registry["content_hash"],
            "resolved_token_count": len(parsed_seed.tokens),
        },
        "limits": limits,
        "definition_order": order,
        "definitions": definition_manifest,
        "lowering": {
            "entry_id": bundle.entry_id,
            "entry_index": bundle.program.entry,
            "cell_count": len(bundle.program.cells),
            "cells": cells_manifest,
        },
        "program": {
            "bytes": len(program_blob),
            "sha256": _sha256(program_blob),
            "runtime_seed": bundle.program.seed,
            "default_ticks": bundle.program.default_ticks,
            "program_flags": bundle.program.flags,
            "genome_flag_tag": bundle.genome_flag_tag,
            "initial_state_words": bundle.program.initial_state.words(),
        },
        "determinism": {
            "canonical_json": "UTF-8; sorted object keys; compact separators; no Unicode escaping",
            "definition_schedule": "strict unique (phase, ordinal), dependencies before dependents",
            "cell_order": "ascending unsigned canonical 64-bit key",
            "binary_format": "TOMAGI ABI 1.0 little-endian header 128 + Cell48 records",
        },
    }
    return SeededBuildResult(program=bundle.program, manifest=manifest)
