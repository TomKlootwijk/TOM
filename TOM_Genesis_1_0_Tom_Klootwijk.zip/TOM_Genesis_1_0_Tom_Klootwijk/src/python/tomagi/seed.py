"""Canonical TOM seed verification, parsing, and token-registry resolution.

The canonical seed file is the authoritative root input for the seeded compilation
profile.  This module deliberately implements an exact grammar for profile 1.0;
it does not apply natural-language interpretation or permissive normalization.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
from typing import Any

from .canonical import canonical_bytes, verify_hash

CANONICAL_SEED_LENGTH = 244
CANONICAL_SEED_SHA256 = "d1417a3136772c0cf3eddcd4962ce07d42cbf87616f7b5bae09fc652d9b807b5"
CANONICAL_HEADER = (
    "TOM1[TopologicalOpenModular]",
    "TomKlootwijk",
    "1990-07-10",
    "NL200678942",
    "2026-09-01",
)
CANONICAL_PIPELINE = (
    "LUTlogp^{Klein,SDF0@Def}(rho,theta,t->;phi,dt,d2,J,v,a,j1)"
    ">P1>L2_BST^b>ASweepCone(T,apex)>Pi[pyrSide,circle,sphere]"
    ">support>compatibility>guard>event>transition>lineage"
)

# Ordered lexical tokens produced by the exact profile-1.0 grammar.  Punctuation
# remains significant in the seed; this list is the registry lookup sequence.
CANONICAL_TOKEN_SEQUENCE = (
    "LUTlogp",
    "Klein",
    "SDF0@Def",
    "rho",
    "theta",
    "t->",
    "phi",
    "dt",
    "d2",
    "J",
    "v",
    "a",
    "j1",
    "P1",
    "L2_BST^b",
    "ASweepCone",
    "T",
    "apex",
    "Pi",
    "pyrSide",
    "circle",
    "sphere",
    "support",
    "compatibility",
    "guard",
    "event",
    "transition",
    "lineage",
)


@dataclass(frozen=True, slots=True)
class ParsedSeed:
    version_token: str
    substrate_name: str
    attribution: str
    birth_date: str
    identifier: str
    generated_date: str
    pipeline: str
    tokens: tuple[str, ...]
    byte_length: int
    sha256: str

    def as_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["tokens"] = list(self.tokens)
        return value


def _digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parse_exact_seed(
    seed_bytes: bytes,
    *,
    expected_length: int = CANONICAL_SEED_LENGTH,
    expected_sha256: str = CANONICAL_SEED_SHA256,
) -> ParsedSeed:
    """Verify and parse the canonical profile-1.0 TOM seed.

    Rejection is deterministic.  No whitespace is stripped, Unicode is not
    normalized, and a terminal line feed is invalid.
    """
    if len(seed_bytes) != expected_length:
        raise ValueError(
            f"seed length mismatch: expected {expected_length} bytes, got {len(seed_bytes)}"
        )
    actual_hash = _digest(seed_bytes)
    expected = expected_sha256.removeprefix("sha256:").lower()
    if actual_hash != expected:
        raise ValueError(
            f"seed hash mismatch: expected {expected}, got {actual_hash}"
        )
    if seed_bytes.endswith((b"\n", b"\r")):
        raise ValueError("canonical seed must not have a terminal line ending")
    try:
        text = seed_bytes.decode("ascii")
    except UnicodeDecodeError as exc:
        raise ValueError("canonical seed must contain ASCII bytes only") from exc

    parts = text.split("|")
    if len(parts) != 6:
        raise ValueError("seed grammar requires five header fields and one pipeline")
    if tuple(parts[:5]) != CANONICAL_HEADER:
        raise ValueError("seed header does not match TOM seeded profile 1.0")
    if parts[5] != CANONICAL_PIPELINE:
        raise ValueError("seed pipeline does not match TOM seeded profile 1.0 grammar")

    version_token = parts[0].split("[", 1)[0]
    substrate_name = parts[0][parts[0].find("[") + 1 : -1]
    return ParsedSeed(
        version_token=version_token,
        substrate_name=substrate_name,
        attribution=parts[1],
        birth_date=parts[2],
        identifier=parts[3],
        generated_date=parts[4],
        pipeline=parts[5],
        tokens=CANONICAL_TOKEN_SEQUENCE,
        byte_length=len(seed_bytes),
        sha256=actual_hash,
    )


def load_token_registry(path: str | Path, parsed_seed: ParsedSeed) -> dict[str, Any]:
    """Load and validate a content-addressed token registry against *parsed_seed*."""
    registry_path = Path(path)
    try:
        registry = json.loads(registry_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot load token registry {registry_path}: {exc}") from exc
    if not isinstance(registry, dict):
        raise ValueError("token registry must be a JSON object")
    if registry.get("profile_id") != "TOM-Seeded-Compilation-Profile-1.0":
        raise ValueError("unsupported token registry profile_id")
    if not verify_hash(registry):
        raise ValueError("token registry content_hash mismatch")
    if registry.get("seed_sha256", "").removeprefix("sha256:") != parsed_seed.sha256:
        raise ValueError("token registry is not bound to the canonical seed hash")
    sequence = registry.get("pipeline_tokens")
    if sequence != list(parsed_seed.tokens):
        raise ValueError("token registry pipeline token sequence does not match parsed seed")

    entries = registry.get("tokens")
    if not isinstance(entries, list):
        raise ValueError("token registry tokens must be an array")
    by_literal: dict[str, dict[str, Any]] = {}
    for entry in entries:
        if not isinstance(entry, dict) or not isinstance(entry.get("literal"), str):
            raise ValueError("each token registry entry requires a literal string")
        literal = entry["literal"]
        if literal in by_literal:
            raise ValueError(f"duplicate token registry literal {literal}")
        by_literal[literal] = entry
    missing = [literal for literal in parsed_seed.tokens if literal not in by_literal]
    if missing:
        raise ValueError("unresolved seed tokens: " + ", ".join(missing))

    phases = registry.get("phase_order")
    expected_phases = [
        "parse",
        "normalize",
        "resolve",
        "construct",
        "transform",
        "support",
        "compatibility",
        "guard/root",
        "transition",
        "lineage/log",
    ]
    if phases != expected_phases:
        raise ValueError("token registry phase_order does not match profile 1.0")
    return registry


def token_registry_digest(registry: dict[str, Any]) -> str:
    """Return the canonical content digest (without the ``sha256:`` prefix)."""
    body = {k: v for k, v in registry.items() if k != "content_hash"}
    return hashlib.sha256(canonical_bytes(body)).hexdigest()
