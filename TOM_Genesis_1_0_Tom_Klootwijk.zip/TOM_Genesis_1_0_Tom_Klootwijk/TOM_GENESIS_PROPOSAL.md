# Proposal: **TOM Genesis - Seed-to-Bytes Causal Closure**

I propose that we **do not add more operators, diagrams, GPU claims, or conceptual exposition yet**. The next milestone should prove one complete causal chain:

```text
canonical TOM seed bytes
-> exact seed parse
-> typed, content-addressed definitions
-> deterministic definition evaluation
-> Cell48 lowering
-> compiled .tmg
-> TOMAGI execution
-> ordered EMIT records
-> generic byte materialization
-> byte-identical artifact
```

That is precisely the standard imposed by the repository instructions: definitions must be executable rather than decorative metadata, host code must remain domain-neutral, and every artifact must be reproducible from literal source through `.tmg` and `EMIT`.

The page-one expansion diagram in TOM-SRS already describes the upstream half - seed, parsing, definitions, query evaluation, trace, phenotype - while TOMAGI supplies the fixed-width downstream machine: `State64`, `Cell48`, sixteen opcodes, Python/C execution, and GPU mappings. The missing piece is the **executable bridge between those two halves**.

## Why this should come first

My quick inspection of the current archive found a solid runtime foundation but also one decisive gap:

- The direct Python conformance suite passes all 24 tests, including Python/C agreement.
- The compiler verifies definition hashes and dependency references.
- However, those definitions do not currently produce the cells. The actual `Cell48` instructions, arguments, branches, payloads, and keys are still supplied separately in handwritten `cells` arrays.
- Consequently, the definitions presently establish identity and ordering but are not yet the causal source of the executable program.
- A clean extracted archive also cannot currently complete `make validate`, because the specification generator expects several original source files outside the shipped tree.

So the package currently demonstrates **deterministic execution of manually authored Cell48 graphs**. The next release should demonstrate **deterministic compilation of executable literal definitions rooted in the canonical seed**.

## 1. Introduce a seeded compilation profile without breaking TOMAGI 1.0

I would preserve the existing `.tmg` binary ABI and all sixteen opcode transition semantics. Existing programs should continue to execute byte-for-byte as before.

Over that ABI, I propose a versioned profile:

> **TOM Seeded Compilation Profile 1.0 over TOMAGI ABI 1.0**

It would distinguish two modes:

| Mode | Meaning |
|---|---|
| Legacy cell mode | Existing handwritten `cells` documents remain valid and backward-compatible. |
| Seeded conformance mode | All cells must be derived from a selected executable definition graph rooted in the canonical TOM seed. Handwritten cell semantics are rejected. |

The exact root is already fixed: 244 ASCII bytes, no terminal newline, SHA-256 `d1417a3136772c0cf3eddcd4962ce07d42cbf87616f7b5bae09fc652d9b807b5`.

## 2. Resolve the `SDF0` distinction explicitly

The two supplied specifications use related but non-identical formulations:

- TOMAGI 1.0 defines its hot `SDF0` opcode as literal zero for a **defined LUT cell**, with undefined outside the compiled cell domain.
- TOM-SRS defines `SDF0@Def` as a **typed zero-relation interface exposed by eligible definitions**, explicitly not as a claim that every stored scalar or address is numerically zero.

I would not silently collapse these into one meaning. The seeded profile should formalize them as two layers:

```text
SDF0       = unchanged TOMAGI opcode 6:
             defined-cell membership relation, residual zero

SDF0@Def   = compiler/query meta-operator:
             each eligible definition declares a typed relation
             and the meaning of its zero locus
```

A cone definition, for example, lowers its meaningful residual test to `CONE`; a spherical definition lowers to `SPHERE`; definition membership can still lower to `SDF0`.

Likewise, the seed tail

```text
support > compatibility > guard > event > transition > lineage
```

should become declared definition phases and branch operations. A guard would be an explicit relation predicate authored in the graph - not an injected safety system, confidence layer, restoration force, or hidden runtime policy. That preserves TOMAGI's no-failsafe execution profile while respecting the canonical seed schedule.

## 3. Make definitions genuinely executable

Each definition should contain a typed formal operation, not merely descriptive parameters. A minimal definition record could retain the existing identity fields while adding an executable expression:

```text
id
kind
domain
codomain
dependencies
phase
operation
parameters
limits
provenance
content_hash
```

The initial operation algebra should be deliberately small and generic:

- canonical literals: bytes, integers, strings, arrays and records;
- bounded sequence operations: concatenate, slice, repeat and indexed map;
- fixed-width integer and bit operations;
- predicates and binary selection;
- bounded graph construction;
- `State64` and `Cell48` constructors;
- ordered byte-emission declarations.

Compilation would then:

1. Verify the exact seed bytes and seed hash.
2. Parse them using the supplied deterministic grammar.
3. Resolve the versioned token registry.
4. Verify every definition hash and dependency.
5. Topologically evaluate the selected root graph.
6. Reject undeclared recursion, excessive budgets, type mismatches and ambiguous order.
7. Lower the resulting formal graph into sorted `Cell48` records.
8. Serialize the unchanged TOMAGI 1.0 `.tmg` format.

The compiler may implement those generic mechanics. It must not contain special cases such as "draw a logo," "write a PBM," "construct a cone scene," or "generate this report." Those semantics belong in definitions.

## 4. Add a generic emitted-byte protocol

The existing `EMIT` opcode can remain unchanged at the state-transition level. A versioned materialization profile can interpret each executed `EMIT` cell as carrying one to four bytes in its 32-bit payload, with a declared byte count in otherwise profile-reserved flag bits.

The generic materializer would only:

```text
observe executed EMIT cells
-> read declared payload byte count
-> pack payload in the specified byte order
-> append records in execution order
-> return the resulting byte stream
```

It would not know whether the bytes form text, JSON, PBM, SVG, a mesh, audio, or another format.

This gives arbitrary finite artifacts without adding a domain-specific renderer or changing `Cell48`.

## 5. First proof artifact: the **TOM Seed Raster**

The canonical seed has 244 bytes, or exactly 1,952 bits.

That permits a particularly clean first phenotype:

```text
width  = 32 bits
height = 61 rows
32 x 61 = 1,952 bits = 244 bytes
```

The artifact definition would emit:

```text
P4\n32 61\n
```

followed by the **exact canonical seed bytes as the binary PBM pixel payload**.

The resulting canonical artifact would therefore be:

- format: binary PBM;
- dimensions: 32 x 61;
- header: 9 bytes;
- raster: 244 bytes;
- total: 253 bytes;
- target SHA-256: `7025712c6da89ed41f2f0ac3dc62c81a043e4ae2bb3da505b0227b8bd255a859`.

That hash is the proposed target specification, not a claim that the present archive already emits it.

This is an unusually strong first demonstration because the phenotype is not merely inspired by the seed: **its raster payload is literally the seed**. The PBM header and 32-by-61 interpretation would be declared in the artifact definition, compiled to EMIT cells, and reconstructed by the generic materializer.

## 6. Required validation capsule

The release should prove equality at every boundary:

| Boundary | Required evidence |
|---|---|
| Root seed | Exactly 244 bytes, no newline, declared SHA-256 |
| Definitions | Canonical JSON bytes and validated content hashes |
| Dependency graph | Deterministic topological order and selected root |
| Lowering | Stable definition-to-cell crosswalk for every emitted cell |
| Program | Reproducible `.tmg` bytes and SHA-256 |
| Execution | Python and C produce the same cell path, branches, lineage and EMIT sequence |
| Artifact | Both backends materialize the same 253 bytes and target hash |
| Replay | Rebuild from a clean extraction produces identical hashes |
| Rejection | One-byte seed mutation, bad definition hash, unresolved dependency, cycle, duplicate key, invalid successor or budget overflow must fail deterministically |

The validation report and provenance certificate should themselves be produced through literal TOMAGI definitions or through a second TOMAGI emission target fed only generic computed hash values - not through a bespoke report writer.

## What comes immediately after Genesis

Once this causal spine is established, I would migrate the two existing examples:

1. `exact19_rule` should derive all three cells from its relation and emission definitions.
2. `polar_loop` should derive its complete SDF0 -> JIT1 -> KIN2 -> KLEIN -> HINGE -> LSYS -> CONE -> EMIT graph from the ordered definition chain.

Only after both examples have no handwritten executable cell semantics would I move on to GPU dispatch validation or a richer visual domain.

**My recommendation is therefore to make TOM Genesis - the seeded compiler, emitted-byte protocol, and 32x61 seed raster - the next repository milestone.** It converts TOM from a documented seed plus a deterministic machine into a demonstrably closed **seed -> definition -> program -> execution -> artifact** system.
