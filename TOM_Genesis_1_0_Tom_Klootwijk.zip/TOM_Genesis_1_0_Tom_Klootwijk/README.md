# TOM Genesis 1.0

**Seed-to-Bytes Causal Closure over TOMAGI ABI 1.0**

TOM Genesis is the implemented bridge from the canonical TOM seed to the fixed-width TOMAGI machine. The authoritative path is:

```text
canonical seed bytes
-> exact parse and token resolution
-> typed, content-addressed executable definitions
-> deterministic definition evaluation
-> State64 and Cell48 construction
-> canonical Cell48 lowering
-> unchanged TOMAGI 1.0 .tmg serialization
-> ordered TOMAGI execution and EMIT records
-> domain-neutral byte materialization
-> byte-identical artifact and replay certificate
```

The release follows the repository rule that definitions are executable inputs rather than ignored metadata. Host code provides only generic parsing, hashing, validation, typed evaluation, lowering, TOMAGI execution, trace capture, and byte materialization. Artifact meaning and bytes remain in literal definitions.

## Version matrix

| Component | Version | Status |
|---|---|---|
| Distribution | 1.1.0 | TOMAGI 1.0 plus the Genesis compiler profile |
| Seeded source profile | TOM Seeded Compilation Profile 1.0 | Normative in `spec/TOM_SEEDED_COMPILATION_PROFILE_1_0.md` |
| Binary execution ABI | TOMAGI 1.0 | Unchanged 128-byte header, 64-byte `State64`, 48-byte `Cell48` |
| Legacy JSON cell profile | TOMAGI 1.0 | Preserved and byte-compatible |

## Canonical root

`TOM_seed_genome_2026-09-01.txt` is exactly 244 ASCII bytes, has no terminal line ending, and has SHA-256:

```text
d1417a3136772c0cf3eddcd4962ce07d42cbf87616f7b5bae09fc652d9b807b5
```

The profile rejects whitespace repair, Unicode normalization, case folding, punctuation repair, permissive tokenization, an altered byte, or a terminal newline.

## Delivered proof artifacts

### TOM Seed Raster

`examples/seed_raster.json` evaluates six executable definitions into 64 byte-mode `EMIT` cells. The generic materializer reconstructs:

```text
P4
32 61
 || exact 244 canonical seed bytes
```

| Boundary | Exact value |
|---|---|
| Program | `examples/seed_raster.tmg` |
| Program bytes | 3,200 |
| Program SHA-256 | `2144b904d12420865f77cff4ebccaf4cd41f39603eaabad691c0c697fe7f482d` |
| Artifact | `examples/TOM_seed_raster_32x61.pbm` |
| Artifact bytes | 253 |
| Artifact SHA-256 | `7025712c6da89ed41f2f0ac3dc62c81a043e4ae2bb3da505b0227b8bd255a859` |

The PBM raster payload is literally the canonical seed. The compiler and materializer contain no PBM-specific branch.

### Formal operation-algebra artifact

`examples/operation_algebra.json` exercises the generic literal, sequence, fixed-width integer/bit, predicate, selection, state, cell, graph, and byte-emission operations. Its exact 61-byte output has SHA-256:

```text
320809fa0fcde2f252e691265cf72f9f11de729bfe070e7376799130ff1251f4
```

### Migrated programs

The primary `polar_loop.json` and `exact19_rule.json` sources contain no top-level handwritten `cells` arrays. Their executable definitions construct all `State64` and `Cell48` values. Archived legacy sources remain under `examples/legacy/` and produce the same states and complete traces.

## Validation result

The authoritative machine-emitted record is `validation/genesis_certificate.json`. The recorded run proves:

- 58 Python conformance tests passed;
- 18 validation checks passed and 0 failed;
- Python/C equality for every state word, trace row, branch, lineage value, `EMIT` record, and materialized byte sequence used by the demonstrations;
- exact seed-raster and operation-algebra artifact hashes;
- clean rebuild from a minimal literal source capsule;
- fourteen deterministic source-rejection cases;
- a 20,372-byte combined validation/provenance certificate emitted by TOMAGI itself.

The certificate SHA-256 is:

```text
81e05da7c42328bb749139078baa1d6aa79bf0d39476a11f7891b68e1550daa3
```

No new physical-GPU dispatch result is claimed. The original GLSL, WGSL, and OpenCL mappings remain included against TOMAGI ABI 1.0.

## Rebuild and validate

A C99 compiler and Python 3.10 or later are sufficient for the demonstrated CPU validation. The JSON Schema check uses the installed `jsonschema` package when available; the shipped tests and compiler have no runtime package dependencies.

```bash
make validate
```

Equivalent primary commands:

```bash
PYTHONPATH=src/python python3 -m tomagi compile \
  examples/seed_raster.json examples/seed_raster.tmg \
  --manifest examples/seed_raster.compile_manifest.json

PYTHONPATH=src/python python3 -m tomagi materialize \
  examples/seed_raster.tmg examples/TOM_seed_raster_32x61.pbm \
  --trace-output examples/seed_raster.python_trace.json

cc -std=c99 -O2 -Wall -Wextra -Wpedantic -Isrc/c \
  src/c/tomagi.c src/c/tomagi_cli.c -o build/tomagi-c

./build/tomagi-c examples/seed_raster.tmg \
  --trace-json validation/seed_raster.c_trace.json \
  --materialize validation/TOM_seed_raster_32x61.c.pbm
```

Build the profile PDF with:

```bash
make genesis-pdf
```

Build the validated archive with:

```bash
make package
```

## Source profiles

A source with:

```json
"compilation_profile": "TOM-Seeded-Compilation-Profile-1.0"
```

must use exact seed binding, a hash-valid token registry, executable reachable definitions, unique phase/ordinal scheduling, finite limits, and a program-valued root. Handwritten top-level `cells` are rejected.

A source without that profile declaration enters legacy cell mode. The existing TOMAGI 1.0 compiler behavior remains available.

## Package map

- `AGENTS.md` - repository causal-source requirements.
- `TOM_GENESIS_PROPOSAL_ORIGINAL.md` - verbatim proposal that defined this milestone.
- `TOM_GENESIS_PROPOSAL_AND_COMPLETION.md` - proposal followed by the implementation record.
- `spec/TOM_SEEDED_COMPILATION_PROFILE_1_0.md` - normative grammar, hashing, operations, lowering, byte protocol, limits, rejection set, provenance, and replay theorem.
- `spec/tom_seeded_program.schema.json` - strict seeded-source schema.
- `spec/seeded/token_registry_1_0.json` - seed-bound content-addressed token registry.
- `src/python/tomagi/seed.py` - exact seed parser and token-registry validation.
- `src/python/tomagi/seeded.py` - typed definition evaluator and deterministic lowering.
- `src/python/tomagi/materialize.py` - generic ordered `EMIT` byte materialization.
- `src/python/tomagi/template.py` - exact generic value binding for emitted certificates.
- `src/c/` - portable C99 evaluator and trace/materialization CLI.
- `examples/` - seed raster, operation algebra, migrated programs, and legacy baselines.
- `validation/` - emitted certificate, proof, traces, replay evidence, and summary.
- `report/TOM_Genesis_Seeded_Compilation_Profile_1_0.pdf` - rendered normative profile.
- `checksums/SHA256SUMS.txt` - full package checksum list.

The original TOMAGI 1.0 report, 43-operator catalog, 319-row source crosswalk, ABI tables, and GPU source mappings remain included for continuity.

## Evidence boundary

This package demonstrates a finite deterministic source-to-bytes chain on the shipped Python and C runtimes. It does not establish patentability, worldwide novelty, universal performance, learned generalization, a new physical law, or a physical-device result. Requester attribution and identifiers are preserved but were not independently verified.
