from __future__ import annotations

import copy
from dataclasses import replace
import hashlib
import json
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / "examples"

from tomagi.canonical import attach_hash
from tomagi.compiler import compile_document, compile_file_with_manifest
from tomagi.core import FLAG_EMIT_BYTES, FLAG_EMIT_HALT, Opcode, run
from tomagi.format import dumps, load
from tomagi.materialize import emit_byte_count, execute_and_materialize
from tomagi.seed import (
    CANONICAL_SEED_SHA256,
    load_token_registry,
    parse_exact_seed,
)
from tomagi.seeded import compile_seeded_document


def document(name: str) -> dict:
    return json.loads((EXAMPLES / name).read_text(encoding="utf-8"))


def rehash(definition: dict) -> None:
    definition.pop("content_hash", None)
    definition.update(attach_hash(definition))


def definition(doc: dict, ident: str) -> dict:
    return next(item for item in doc["definitions"] if item["id"] == ident)


class SeedRootTests(unittest.TestCase):
    def test_canonical_seed_exact_bytes_and_hash(self):
        data = (ROOT / "TOM_seed_genome_2026-09-01.txt").read_bytes()
        parsed = parse_exact_seed(data)
        self.assertEqual(parsed.byte_length, 244)
        self.assertEqual(parsed.sha256, CANONICAL_SEED_SHA256)
        self.assertFalse(data.endswith(b"\n"))
        self.assertEqual(parsed.tokens[-6:], ("support", "compatibility", "guard", "event", "transition", "lineage"))

    def test_terminal_line_feed_is_rejected_even_with_matching_mutated_digest(self):
        data = (ROOT / "TOM_seed_genome_2026-09-01.txt").read_bytes() + b"\n"
        with self.assertRaisesRegex(ValueError, "terminal line ending"):
            parse_exact_seed(data, expected_length=len(data), expected_sha256=hashlib.sha256(data).hexdigest())

    def test_token_registry_is_content_addressed_and_complete(self):
        seed = parse_exact_seed((ROOT / "TOM_seed_genome_2026-09-01.txt").read_bytes())
        registry = load_token_registry(ROOT / "spec/seeded/token_registry_1_0.json", seed)
        self.assertEqual(len(registry["pipeline_tokens"]), 28)
        self.assertEqual(registry["pipeline_tokens"], list(seed.tokens))
        self.assertEqual(registry["phase_order"][7], "guard/root")


class ExecutableDefinitionTests(unittest.TestCase):
    def test_primary_examples_have_no_handwritten_cell_array(self):
        for name in (
            "polar_loop.json",
            "exact19_rule.json",
            "seed_raster.json",
            "operation_algebra.json",
        ):
            doc = document(name)
            self.assertNotIn("cells", doc)
            self.assertEqual(doc["compilation_profile"], "TOM-Seeded-Compilation-Profile-1.0")
            self.assertTrue(all("operation" in item for item in doc["definitions"]))
            root = definition(doc, "program:root")
            self.assertEqual(root["parameters"]["state_input"], "state:initial")
            self.assertNotIn("initial_state", root["parameters"])

    def test_every_definition_is_evaluated_and_manifested(self):
        doc = document("seed_raster.json")
        result = compile_seeded_document(doc, base_dir=EXAMPLES)
        manifest_ids = [item["id"] for item in result.manifest["definitions"]]
        self.assertEqual(len(manifest_ids), len(doc["definitions"]))
        self.assertEqual(set(manifest_ids), {item["id"] for item in doc["definitions"]})
        self.assertEqual(manifest_ids[-1], doc["root_definition"])

    def test_sdf0_and_sdf0_at_def_are_distinct_and_recorded(self):
        result = compile_seeded_document(document("polar_loop.json"), base_dir=EXAMPLES)
        defs = {item["id"]: item for item in result.manifest["definitions"]}
        self.assertEqual(defs["cell:sdf0"]["zero_relation"]["interface"], "SDF0@Def")
        self.assertEqual(defs["cell:sdf0"]["zero_relation"]["lowering"], "SDF0")
        self.assertEqual(defs["cell:cone"]["zero_relation"]["lowering"], "CONE")
        sdf_cell = next(item for item in result.manifest["lowering"]["cells"] if item["cell_id"] == "cell:sdf0")
        self.assertEqual(sdf_cell["opcode"], "SDF0")

    def test_program_header_flags_are_bound_to_seed_hash(self):
        result = compile_seeded_document(document("seed_raster.json"), base_dir=EXAMPLES)
        expected = int.from_bytes(bytes.fromhex(CANONICAL_SEED_SHA256)[:4], "little")
        self.assertEqual(result.program.flags, expected)
        self.assertEqual(result.manifest["program"]["genome_flag_tag"], expected)

    def test_definition_to_cell_crosswalk_covers_all_cells(self):
        result = compile_seeded_document(document("seed_raster.json"), base_dir=EXAMPLES)
        cells = result.manifest["lowering"]["cells"]
        self.assertEqual(len(cells), 64)
        self.assertTrue(all(item["definition_id"] == "program:emit-seed-raster" for item in cells))
        self.assertEqual([item["source_offset"] for item in cells], list(range(0, 253, 4)))


class SeedRasterTests(unittest.TestCase):
    TARGET = "7025712c6da89ed41f2f0ac3dc62c81a043e4ae2bb3da505b0227b8bd255a859"

    def test_seed_raster_materializes_exact_target(self):
        program = compile_document(document("seed_raster.json"), base_dir=EXAMPLES)
        result = execute_and_materialize(program)
        seed = (ROOT / "TOM_seed_genome_2026-09-01.txt").read_bytes()
        self.assertEqual(result.data, b"P4\n32 61\n" + seed)
        self.assertEqual(len(result.data), 253)
        self.assertEqual(hashlib.sha256(result.data).hexdigest(), self.TARGET)
        self.assertEqual(len(result.emits), 64)

    def test_emit_byte_profile_uses_one_to_four_little_endian_bytes(self):
        program = compile_document(document("seed_raster.json"), base_dir=EXAMPLES)
        first = program.cells[0]
        last = program.cells[-1]
        self.assertTrue(first.flags & FLAG_EMIT_BYTES)
        self.assertEqual(emit_byte_count(first.flags), 4)
        self.assertEqual(first.payload.to_bytes(4, "little"), b"P4\n3")
        self.assertEqual(emit_byte_count(last.flags), 1)
        self.assertTrue(last.flags & FLAG_EMIT_HALT)

    def test_repeated_compilation_and_materialization_are_byte_identical(self):
        doc = document("seed_raster.json")
        a = compile_seeded_document(copy.deepcopy(doc), base_dir=EXAMPLES)
        b = compile_seeded_document(copy.deepcopy(doc), base_dir=EXAMPLES)
        self.assertEqual(dumps(a.program), dumps(b.program))
        self.assertEqual(execute_and_materialize(a.program).data, execute_and_materialize(b.program).data)
        self.assertEqual(a.manifest, b.manifest)

    def test_shipped_program_and_artifact_match_fresh_rebuild(self):
        result = compile_seeded_document(document("seed_raster.json"), base_dir=EXAMPLES)
        self.assertEqual(dumps(result.program), (EXAMPLES / "seed_raster.tmg").read_bytes())
        self.assertEqual(
            execute_and_materialize(result.program).data,
            (EXAMPLES / "TOM_seed_raster_32x61.pbm").read_bytes(),
        )

    def test_python_and_c_match_full_trace_emit_sequence_and_bytes(self):
        exe = ROOT / "build/tomagi-c"
        if not exe.exists():
            self.skipTest("C backend not built")
        program = load(EXAMPLES / "seed_raster.tmg")
        py = execute_and_materialize(program).summary()
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            c_trace = tmp_path / "trace.json"
            c_artifact = tmp_path / "artifact.pbm"
            subprocess.run(
                [str(exe), str(EXAMPLES / "seed_raster.tmg"), "--trace-json", str(c_trace), "--materialize", str(c_artifact)],
                check=True,
                stdout=subprocess.DEVNULL,
            )
            c = json.loads(c_trace.read_text(encoding="utf-8"))
            self.assertEqual(py["state"], c["state"])
            self.assertEqual(py["trace"], c["trace"])
            self.assertEqual(py["emits"], c["emits"])
            self.assertEqual(execute_and_materialize(program).data, c_artifact.read_bytes())


class FormalOperationAlgebraTests(unittest.TestCase):
    TARGET = "320809fa0fcde2f252e691265cf72f9f11de729bfe070e7376799130ff1251f4"
    EXPECTED = (
        b'TOM1TOM{"profile":"A1","version":1}'
        b'[[0,10],[1,20],[2,30]]\nOK\n'
    )

    def test_operation_algebra_example_exercises_promised_generic_operations(self):
        result = compile_seeded_document(document("operation_algebra.json"), base_dir=EXAMPLES)
        operations = {item["operation"] for item in result.manifest["definitions"]}
        required = {
            "seed.bytes",
            "literal.int",
            "literal.string",
            "literal.array",
            "literal.record",
            "string.utf8",
            "sequence.concat",
            "sequence.slice",
            "sequence.repeat",
            "sequence.indexed_map",
            "u32.normalize",
            "i32.normalize",
            "u32.add",
            "u32.xor",
            "u32.or",
            "u32.shl",
            "u32.shr",
            "u32.rotl",
            "u32.popcount",
            "u32.and",
            "bit.parity",
            "predicate.eq",
            "predicate.le",
            "predicate.zero",
            "select.binary",
            "tomagi.state64",
            "tomagi.cell",
            "tomagi.graph.sequence",
            "tomagi.emit_bytes",
            "tomagi.program",
        }
        self.assertTrue(required.issubset(operations))

    def test_operation_algebra_artifact_is_exact(self):
        program = compile_document(document("operation_algebra.json"), base_dir=EXAMPLES)
        result = execute_and_materialize(program)
        self.assertEqual(result.data, self.EXPECTED)
        self.assertEqual(hashlib.sha256(result.data).hexdigest(), self.TARGET)
        self.assertEqual(len(program.initial_state.words()), 16)
        self.assertEqual(program.cells[0].opcode, int(Opcode.NOP))

    def test_seed_tail_roles_are_declared_in_executable_phases(self):
        result = compile_seeded_document(document("operation_algebra.json"), base_dir=EXAMPLES)
        defs = {item["id"]: item for item in result.manifest["definitions"]}
        self.assertEqual(defs["support:popcount-eight"]["phase"], 5)
        self.assertEqual(defs["compatibility:wrapped-zero"]["phase"], 6)
        self.assertEqual(defs["guard:primary"]["phase"], 7)
        self.assertEqual(defs["event:guard-bit"]["phase"], 7)
        self.assertEqual(defs["transition:selected-bytes"]["phase"], 8)
        self.assertEqual(defs["program:root"]["phase"], 9)

    def test_per_definition_limits_are_executable_not_comments(self):
        doc = document("operation_algebra.json")
        item = definition(doc, "literal:string")
        item["limits"]["characters"] = 4
        rehash(item)
        with self.assertRaisesRegex(ValueError, "definition limit mismatch"):
            compile_seeded_document(doc, base_dir=EXAMPLES)

    def test_python_and_c_match_operation_algebra_bytes(self):
        exe = ROOT / "build/tomagi-c"
        if not exe.exists():
            self.skipTest("C backend not built")
        program = load(EXAMPLES / "operation_algebra.tmg")
        py = execute_and_materialize(program).summary()
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            c_trace = tmp_path / "trace.json"
            c_artifact = tmp_path / "artifact.bin"
            subprocess.run(
                [
                    str(exe),
                    str(EXAMPLES / "operation_algebra.tmg"),
                    "--trace-json",
                    str(c_trace),
                    "--materialize",
                    str(c_artifact),
                ],
                check=True,
                stdout=subprocess.DEVNULL,
            )
            c = json.loads(c_trace.read_text(encoding="utf-8"))
            self.assertEqual(py["state"], c["state"])
            self.assertEqual(py["trace"], c["trace"])
            self.assertEqual(py["emits"], c["emits"])
            self.assertEqual(self.EXPECTED, c_artifact.read_bytes())


class MigrationAndCompatibilityTests(unittest.TestCase):
    def test_seeded_polar_loop_preserves_legacy_execution_result(self):
        seeded = compile_document(document("polar_loop.json"), base_dir=EXAMPLES)
        legacy_doc = json.loads((EXAMPLES / "legacy/polar_loop_legacy_cells.json").read_text())
        legacy = compile_document(legacy_doc)
        self.assertEqual(run(seeded, trace=True), run(legacy, trace=True))
        self.assertNotEqual(dumps(seeded)[:16], dumps(legacy)[:16])  # profile flags bind the new program to the genome

    def test_seeded_exact19_preserves_accept_and_reject_behavior(self):
        program = compile_document(document("exact19_rule.json"), base_dir=EXAMPLES)
        accepted, _ = run(program)
        rejected, _ = run(program, state=replace(program.initial_state, rho=18, cell=program.entry))
        self.assertEqual(accepted.output, 19)
        self.assertEqual(rejected.output, 0)

    def test_legacy_sources_still_compile_byte_for_byte(self):
        for stem in ("polar_loop", "exact19_rule"):
            source = EXAMPLES / "legacy" / f"{stem}_legacy_cells.json"
            expected = EXAMPLES / "legacy" / f"{stem}_legacy_cells.tmg"
            with tempfile.TemporaryDirectory() as tmp:
                out = Path(tmp) / "out.tmg"
                compile_file_with_manifest(source, out)
                self.assertEqual(out.read_bytes(), expected.read_bytes())

    def test_c_exact19_reject_override_is_generic_state_word(self):
        exe = ROOT / "build/tomagi-c"
        if not exe.exists():
            self.skipTest("C backend not built")
        output = subprocess.check_output(
            [str(exe), str(EXAMPLES / "exact19_rule.tmg"), "--state-word", "0=18"], text=True
        )
        self.assertEqual(json.loads(output)["output"], 0)


class DeterministicRejectionTests(unittest.TestCase):
    def test_one_byte_seed_mutation_rejected(self):
        doc = document("seed_raster.json")
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            seed = bytearray((ROOT / "TOM_seed_genome_2026-09-01.txt").read_bytes())
            seed[0] ^= 1
            (base / "seed.txt").write_bytes(seed)
            (base / "registry.json").write_bytes((ROOT / "spec/seeded/token_registry_1_0.json").read_bytes())
            doc["seed_genome"]["file"] = "seed.txt"
            doc["token_registry"]["file"] = "registry.json"
            with self.assertRaisesRegex(ValueError, "seed hash mismatch"):
                compile_seeded_document(doc, base_dir=base)

    def test_bad_definition_hash_rejected(self):
        doc = document("seed_raster.json")
        definition(doc, "artifact:pbm-header")["parameters"]["text"] = "changed"
        with self.assertRaisesRegex(ValueError, "definition hash mismatch"):
            compile_seeded_document(doc, base_dir=EXAMPLES)

    def test_unresolved_dependency_rejected(self):
        doc = document("seed_raster.json")
        item = definition(doc, "artifact:pbm-header")
        item["dependencies"].append("missing:definition")
        rehash(item)
        with self.assertRaisesRegex(ValueError, "unknown dependency"):
            compile_seeded_document(doc, base_dir=EXAMPLES)

    def test_dependency_cycle_rejected(self):
        doc = document("seed_raster.json")
        seed = definition(doc, "seed:genome")
        header = definition(doc, "artifact:pbm-header")
        seed["dependencies"] = ["artifact:pbm-header"]
        header["dependencies"] = ["seed:genome"]
        rehash(seed)
        rehash(header)
        with self.assertRaisesRegex(ValueError, "dependency cycle"):
            compile_seeded_document(doc, base_dir=EXAMPLES)

    def test_ambiguous_phase_ordinal_rejected(self):
        doc = document("seed_raster.json")
        header = definition(doc, "artifact:pbm-header")
        header["phase"] = 0
        header["ordinal"] = 0
        rehash(header)
        with self.assertRaisesRegex(ValueError, "ambiguous definition order"):
            compile_seeded_document(doc, base_dir=EXAMPLES)

    def test_duplicate_key_rejected(self):
        doc = document("polar_loop.json")
        first = definition(doc, "cell:sdf0")
        second = definition(doc, "cell:jitter")
        second["parameters"]["key"] = copy.deepcopy(first["parameters"]["key"])
        rehash(second)
        with self.assertRaisesRegex(ValueError, "duplicate canonical cell key"):
            compile_seeded_document(doc, base_dir=EXAMPLES)

    def test_invalid_successor_rejected(self):
        doc = document("polar_loop.json")
        first = definition(doc, "cell:sdf0")
        first["parameters"]["next"][0] = "cell:missing"
        rehash(first)
        with self.assertRaisesRegex(ValueError, "unknown successor"):
            compile_seeded_document(doc, base_dir=EXAMPLES)

    def test_budget_overflow_rejected(self):
        doc = document("seed_raster.json")
        doc["limits"]["max_cells"] = 10
        with self.assertRaisesRegex(ValueError, "cell budget exceeded"):
            compile_seeded_document(doc, base_dir=EXAMPLES)

    def test_type_or_codomain_mismatch_rejected(self):
        doc = document("seed_raster.json")
        header = definition(doc, "artifact:pbm-header")
        header["codomain"] = "int"
        rehash(header)
        with self.assertRaisesRegex(ValueError, "codomain mismatch"):
            compile_seeded_document(doc, base_dir=EXAMPLES)

    def test_unreachable_definition_rejected(self):
        doc = document("seed_raster.json")
        extra = attach_hash({
            "id": "unused:literal",
            "kind": "literal",
            "domain": "unit",
            "codomain": "int",
            "phase": 3,
            "ordinal": 99,
            "dependencies": [],
            "inputs": [],
            "operation": "literal.int",
            "parameters": {"value": 1},
            "limits": {},
            "provenance": {"purpose": "rejection test"},
            "zero_relation": {
                "interface": "SDF0@Def",
                "domain": "literal",
                "codomain": "integer discrepancy",
                "semantics": "zero on exact literal equality",
                "lowering": "compile:literal-integrity"
            }
        })
        doc["definitions"].append(extra)
        with self.assertRaisesRegex(ValueError, "unreachable definitions"):
            compile_seeded_document(doc, base_dir=EXAMPLES)

    def test_handwritten_top_level_cells_rejected(self):
        doc = document("seed_raster.json")
        doc["cells"] = []
        with self.assertRaisesRegex(ValueError, "rejects handwritten"):
            compile_seeded_document(doc, base_dir=EXAMPLES)

    def test_undeclared_recursion_profile_rejected(self):
        doc = document("seed_raster.json")
        doc["limits"]["max_recursion_depth"] = 1
        with self.assertRaisesRegex(ValueError, "no recursive"):
            compile_seeded_document(doc, base_dir=EXAMPLES)


if __name__ == "__main__":
    unittest.main()
