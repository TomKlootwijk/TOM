# Notice

TOM Genesis 1.0 is an additive seeded source-compilation and byte-materialization profile over TOMAGI ABI 1.0.

Requester-supplied attribution: Tom Klootwijk; NL200678942; 10-07-1990. The attribution and identifiers are retained from the supplied project corpus and were not independently verified.

The normative implementation claim is finite: exact canonical seed bytes and hash-valid executable definitions compile deterministically to an unchanged fixed-width TOMAGI `.tmg`; conforming Python and C evaluators produce the recorded ordered trace and `EMIT` sequence; the generic materializer reconstructs the recorded bytes.

This package is not a patent grant, proof of priority, independent prior-art search, proof of worldwide novelty, universal performance result, learned general model, validation of a physical device, or statement of a new physical law.

The original TOMAGI 1.0 GPU sources are included against the shared ABI. Genesis adds no claim that GLSL, WGSL, OpenCL, FPGA, or physical GPU execution was newly validated.
