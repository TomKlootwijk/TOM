"""Create the deterministic TOM Genesis release manifest, checksum list, and ZIP."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import stat
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACKAGE_NAME = ROOT.name
OUT_DIR = ROOT.parent
PROFILE_PDF = ROOT / "report/TOM_Genesis_Seeded_Compilation_Profile_1_0.pdf"
ZIP_PATH = OUT_DIR / f"{PACKAGE_NAME}.zip"
PDF_COPY = OUT_DIR / "TOM_Genesis_Seeded_Compilation_Profile_1_0.pdf"
DIGEST_PATH = OUT_DIR / f"{PACKAGE_NAME}_SHA256.txt"
FIXED_DATE = "2026-09-01"
FIXED_ZIP_TIME = (2026, 9, 1, 0, 0, 0)

EXCLUDED_PARTS = {".git", ".pytest_cache", "__pycache__", "dist"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".aux", ".fdb_latexmk", ".fls", ".log", ".out", ".toc", ".lof", ".lot", ".synctex.gz"}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def is_excluded(path: Path) -> bool:
    relative = path.relative_to(ROOT)
    if any(part in EXCLUDED_PARTS for part in relative.parts):
        return True
    name = path.name
    if name.endswith(".synctex.gz"):
        return True
    return path.suffix in EXCLUDED_SUFFIXES


def clean_intermediates() -> None:
    for directory in sorted(ROOT.rglob("__pycache__"), reverse=True):
        if directory.is_dir():
            shutil.rmtree(directory)
    for path in list(ROOT.rglob("*")):
        if path.is_file() and is_excluded(path):
            path.unlink(missing_ok=True)
    for relative in (
        "examples/TOM_seed_raster_32x61.c.pbm",
        "examples/seed_raster.c_trace.json",
    ):
        (ROOT / relative).unlink(missing_ok=True)


def iter_files(*, include_control: bool = True) -> list[Path]:
    control = {
        ROOT / "checksums/SHA256SUMS.txt",
        ROOT / "validation/package_manifest.json",
    }
    files: list[Path] = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or is_excluded(path):
            continue
        if not include_control and path in control:
            continue
        files.append(path)
    return sorted(files, key=lambda item: item.relative_to(ROOT).as_posix())


def write_package_manifest() -> None:
    files = iter_files(include_control=False)
    manifest = {
        "schema": "TOM-GENESIS-PACKAGE-MANIFEST-1.0",
        "package": PACKAGE_NAME,
        "distribution_version": (ROOT / "VERSION").read_text(encoding="utf-8").strip(),
        "seeded_profile": "TOM-Seeded-Compilation-Profile-1.0",
        "tomagi_abi": "1.0.0",
        "generated": FIXED_DATE,
        "file_count_excluding_manifest_and_checksum": len(files),
        "files": [
            {
                "path": path.relative_to(ROOT).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
            for path in files
        ],
    }
    destination = ROOT / "validation/package_manifest.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def write_checksums() -> None:
    destination = ROOT / "checksums/SHA256SUMS.txt"
    destination.parent.mkdir(parents=True, exist_ok=True)
    files = [path for path in iter_files(include_control=True) if path != destination]
    destination.write_text(
        "".join(
            f"{sha256_file(path)}  {path.relative_to(ROOT).as_posix()}\n" for path in files
        ),
        encoding="utf-8",
    )


def zip_mode(path: Path) -> int:
    executable = bool(path.stat().st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH))
    return 0o755 if executable else 0o644


def write_deterministic_zip() -> None:
    ZIP_PATH.unlink(missing_ok=True)
    with zipfile.ZipFile(
        ZIP_PATH,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
        strict_timestamps=True,
    ) as archive:
        for path in iter_files(include_control=True):
            relative = path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(f"{PACKAGE_NAME}/{relative}", date_time=FIXED_ZIP_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (zip_mode(path) & 0xFFFF) << 16
            info.flag_bits |= 0x800
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def main() -> None:
    if not PROFILE_PDF.is_file() or PROFILE_PDF.stat().st_size == 0:
        raise SystemExit(f"missing final profile PDF: {PROFILE_PDF}")
    summary = ROOT / "validation/validation_summary.json"
    if not summary.is_file():
        raise SystemExit("run `make validate` before packaging")
    validation = json.loads(summary.read_text(encoding="utf-8"))
    if validation.get("summary", {}).get("fail") != 0:
        raise SystemExit("validation contains failures")

    clean_intermediates()
    write_package_manifest()
    write_checksums()
    shutil.copyfile(PROFILE_PDF, PDF_COPY)
    os.utime(PDF_COPY, (1788220800, 1788220800))
    write_deterministic_zip()

    records = {
        "schema": "TOM-GENESIS-RELEASE-DIGESTS-1.0",
        "generated": FIXED_DATE,
        "files": [
            {
                "path": ZIP_PATH.name,
                "bytes": ZIP_PATH.stat().st_size,
                "sha256": sha256_file(ZIP_PATH),
            },
            {
                "path": PDF_COPY.name,
                "bytes": PDF_COPY.stat().st_size,
                "sha256": sha256_file(PDF_COPY),
            },
        ],
    }
    DIGEST_PATH.write_text(
        "".join(f"{item['sha256']}  {item['path']}\n" for item in records["files"]),
        encoding="utf-8",
    )
    print(json.dumps(records, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
