from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src" / "python"))

from tomagi.template import render_definition_template


def main(argv: list[str]) -> int:
    if len(argv) != 4:
        print("usage: render_definition_template.py TEMPLATE.json VALUES.json OUTPUT.json", file=sys.stderr)
        return 2
    template = json.loads(Path(argv[1]).read_text(encoding="utf-8"))
    values = json.loads(Path(argv[2]).read_text(encoding="utf-8"))
    output = render_definition_template(template, values)
    Path(argv[3]).write_text(json.dumps(output, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
