-- Allow long hexadecimal digests inside Pandoc-generated LaTeX table cells to wrap.
function Code(element)
  local text = element.text
  if (#text >= 40 and text:match('^%x+$')) or
     (#text >= 47 and text:match('^sha256:%x+$')) then
    return pandoc.RawInline('latex', '\\texttt{\\seqsplit{' .. text .. '}}')
  end
  return element
end
