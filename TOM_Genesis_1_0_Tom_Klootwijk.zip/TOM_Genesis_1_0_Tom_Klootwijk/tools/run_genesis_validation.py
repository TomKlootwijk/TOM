"""Rebuild and validate the complete TOM Genesis seed-to-bytes chain."""
from __future__ import annotations

import copy
from dataclasses import replace
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from typing import Any, Callable

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / "examples"
VALIDATION = ROOT / "validation"
VALIDATION.mkdir(exist_ok=True)
sys.path.insert(0, str(ROOT / "src" / "python"))

from tomagi.canonical import attach_hash, canonical_bytes
from tomagi.compiler import compile_file_with_manifest
from tomagi.core import State
from tomagi.format import dumps, load
from tomagi.materialize import execute_and_materialize
from tomagi.seed import CANONICAL_SEED_SHA256, load_token_registry, parse_exact_seed
from tomagi.seeded import compile_seeded_document
from tomagi.template import render_definition_template

TARGET_ARTIFACT_SHA256 = "7025712c6da89ed41f2f0ac3dc62c81a043e4ae2bb3da505b0227b8bd255a859"
OPERATION_ARTIFACT_SHA256 = "320809fa0fcde2f252e691265cf72f9f11de729bfe070e7376799130ff1251f4"
SOURCE_NAMES = ("seed_raster", "operation_algebra", "polar_loop", "exact19_rule")
BYTE_ARTIFACTS = {
    "seed_raster": "TOM_seed_raster_32x61.pbm",
    "operation_algebra": "TOM_operation_algebra.bin",
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def canonical_sha(value: Any) -> str:
    return sha256_bytes(canonical_bytes(value))


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def run(
    args: list[str],
    *,
    cwd: Path = ROOT,
    env: dict[str, str] | None = None,
    check: bool = True,
) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(args, cwd=cwd, env=env, text=True, capture_output=True)
    if check and result.returncode:
        raise RuntimeError(
            f"command failed ({result.returncode}): {' '.join(args)}\n"
            f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )
    return result


def state_dict(state: State) -> dict[str, int]:
    return {name: getattr(state, name) for name in state.__dataclass_fields__}


def load_source(stem: str) -> dict[str, Any]:
    return json.loads((EXAMPLES / f"{stem}.json").read_text(encoding="utf-8"))


def rehash(definition: dict[str, Any]) -> None:
    definition.pop("content_hash", None)
    definition.update(attach_hash(definition))


def find_definition(document: dict[str, Any], ident: str) -> dict[str, Any]:
    return next(item for item in document["definitions"] if item["id"] == ident)


def build_c(root: Path = ROOT) -> Path:
    cc = shutil.which("cc")
    if not cc:
        raise RuntimeError("C compiler 'cc' is required for Genesis validation")
    destination = root / "build" / "tomagi-c"
    destination.parent.mkdir(parents=True, exist_ok=True)
    run(
        [
            cc,
            "-std=c99",
            "-O2",
            "-Wall",
            "-Wextra",
            "-Wpedantic",
            "-Isrc/c",
            "src/c/tomagi.c",
            "src/c/tomagi_cli.c",
            "-o",
            str(destination),
        ],
        cwd=root,
    )
    return destination


def compile_examples() -> dict[str, dict[str, Any]]:
    manifests: dict[str, dict[str, Any]] = {}
    for stem in SOURCE_NAMES:
        program, manifest = compile_file_with_manifest(
            EXAMPLES / f"{stem}.json",
            EXAMPLES / f"{stem}.tmg",
            manifest_path=EXAMPLES / f"{stem}.compile_manifest.json",
        )
        assert manifest is not None
        manifests[stem] = manifest
        if stem in BYTE_ARTIFACTS:
            result = execute_and_materialize(program)
            (EXAMPLES / BYTE_ARTIFACTS[stem]).write_bytes(result.data)
            write_json(EXAMPLES / f"{stem}.python_trace.json", result.summary())
        else:
            state, trace = __import__("tomagi.core", fromlist=["run"]).run(program, trace=True)
            write_json(EXAMPLES / f"{stem}.expected.json", {"state": state_dict(state), "trace": trace})
            capture = execute_and_materialize(program, strict_bytes=False)
            write_json(EXAMPLES / f"{stem}.python_trace.json", capture.summary())
    return manifests


def c_capture(
    exe: Path,
    stem: str,
    *,
    trace_path: Path,
    materialize_path: Path | None = None,
    overrides: list[str] | None = None,
) -> dict[str, Any]:
    command = [str(exe), str(EXAMPLES / f"{stem}.tmg"), "--trace-json", str(trace_path)]
    if materialize_path is not None:
        command += ["--materialize", str(materialize_path)]
    for override in overrides or []:
        command += ["--state-word", override]
    run(command)
    return json.loads(trace_path.read_text(encoding="utf-8"))


def compare_python_c(exe: Path) -> dict[str, Any]:
    results: dict[str, Any] = {}
    for stem in SOURCE_NAMES:
        program = load(EXAMPLES / f"{stem}.tmg")
        py = execute_and_materialize(program, strict_bytes=(stem in BYTE_ARTIFACTS)).summary()
        c_trace_path = VALIDATION / f"{stem}.c_trace.json"
        c_artifact = (
            VALIDATION / (
                "TOM_seed_raster_32x61.c.pbm"
                if stem == "seed_raster"
                else "TOM_operation_algebra.c.bin"
            )
            if stem in BYTE_ARTIFACTS
            else None
        )
        c = c_capture(exe, stem, trace_path=c_trace_path, materialize_path=c_artifact)
        state_equal = py["state"] == c["state"]
        trace_equal = py["trace"] == c["trace"]
        emits_equal = py["emits"] == c["emits"]
        artifact_equal = True
        if c_artifact is not None:
            artifact_equal = c_artifact.read_bytes() == (EXAMPLES / BYTE_ARTIFACTS[stem]).read_bytes()
        results[stem] = {
            "state_equal": state_equal,
            "trace_equal": trace_equal,
            "emits_equal": emits_equal,
            "artifact_equal": artifact_equal,
            "trace_steps": len(py["trace"]),
            "emit_records": len(py["emits"]),
            "canonical_trace_sha256": canonical_sha(
                {"state": py["state"], "trace": py["trace"], "emits": py["emits"]}
            ),
        }

    program = load(EXAMPLES / "exact19_rule.tmg")
    reject_state = replace(program.initial_state, rho=18, cell=program.entry)
    py_reject = execute_and_materialize(program, state=reject_state, strict_bytes=False).summary()
    c_reject_path = VALIDATION / "exact19_rule_reject.c_trace.json"
    c_reject = c_capture(
        exe,
        "exact19_rule",
        trace_path=c_reject_path,
        overrides=["0=18"],
    )
    results["exact19_rule_reject"] = {
        "state_equal": py_reject["state"] == c_reject["state"],
        "trace_equal": py_reject["trace"] == c_reject["trace"],
        "emits_equal": py_reject["emits"] == c_reject["emits"],
        "output": py_reject["state"]["output"],
        "canonical_trace_sha256": canonical_sha(
            {"state": py_reject["state"], "trace": py_reject["trace"], "emits": py_reject["emits"]}
        ),
    }
    return results


def run_rejection_suite() -> dict[str, dict[str, Any]]:
    results: dict[str, dict[str, Any]] = {}

    def expect(name: str, document: dict[str, Any], phrase: str, *, base: Path = EXAMPLES) -> None:
        try:
            compile_seeded_document(document, base_dir=base)
        except Exception as exc:  # the recorded text is part of deterministic rejection evidence
            message = str(exc)
            results[name] = {"rejected": phrase in message, "diagnostic": message}
        else:
            results[name] = {"rejected": False, "diagnostic": "accepted unexpectedly"}

    # One-byte canonical seed mutation.
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        doc = load_source("seed_raster")
        seed = bytearray((ROOT / "TOM_seed_genome_2026-09-01.txt").read_bytes())
        seed[17] ^= 1
        (base / "seed.txt").write_bytes(seed)
        (base / "registry.json").write_bytes((ROOT / "spec/seeded/token_registry_1_0.json").read_bytes())
        doc["seed_genome"]["file"] = "seed.txt"
        doc["token_registry"]["file"] = "registry.json"
        expect("one_byte_seed_mutation", doc, "seed hash mismatch", base=base)

    doc = load_source("seed_raster")
    find_definition(doc, "artifact:pbm-header")["kind"] = "tampered"
    expect("bad_definition_hash", doc, "definition hash mismatch")

    doc = load_source("seed_raster")
    item = find_definition(doc, "artifact:pbm-header")
    item["dependencies"].append("missing:definition")
    rehash(item)
    expect("unresolved_dependency", doc, "unknown dependency")

    doc = load_source("seed_raster")
    seed_def = find_definition(doc, "seed:genome")
    header = find_definition(doc, "artifact:pbm-header")
    seed_def["dependencies"] = ["artifact:pbm-header"]
    header["dependencies"] = ["seed:genome"]
    rehash(seed_def)
    rehash(header)
    expect("dependency_cycle", doc, "dependency cycle")

    doc = load_source("polar_loop")
    a = find_definition(doc, "cell:sdf0")
    b = find_definition(doc, "cell:jitter")
    b["parameters"]["key"] = copy.deepcopy(a["parameters"]["key"])
    rehash(b)
    expect("duplicate_key", doc, "duplicate canonical cell key")

    doc = load_source("polar_loop")
    item = find_definition(doc, "cell:sdf0")
    item["parameters"]["next"][0] = "cell:missing"
    rehash(item)
    expect("invalid_successor", doc, "unknown successor")

    doc = load_source("seed_raster")
    doc["limits"]["max_cells"] = 10
    expect("budget_overflow", doc, "cell budget exceeded")

    doc = load_source("seed_raster")
    item = find_definition(doc, "artifact:pbm-header")
    item["phase"] = 0
    item["ordinal"] = 0
    rehash(item)
    expect("ambiguous_order", doc, "ambiguous definition order")

    doc = load_source("seed_raster")
    doc["cells"] = []
    expect("handwritten_seeded_cells", doc, "rejects handwritten")

    doc = load_source("seed_raster")
    item = find_definition(doc, "artifact:pbm-header")
    item["codomain"] = "int"
    rehash(item)
    expect("codomain_mismatch", doc, "codomain mismatch")

    doc = load_source("seed_raster")
    item = find_definition(doc, "artifact:pbm-header")
    item["operation"] = "unknown.operation"
    rehash(item)
    expect("unknown_operation", doc, "unknown formal operation")

    doc = load_source("seed_raster")
    item = find_definition(doc, "artifact:pbm-header")
    item["limits"]["bytes"] = 8
    rehash(item)
    expect("per_definition_limit_mismatch", doc, "definition limit mismatch")

    doc = load_source("seed_raster")
    doc["limits"]["max_recursion_depth"] = 1
    expect("undeclared_recursion", doc, "no recursive definition operation")

    doc = load_source("seed_raster")
    extra = attach_hash(
        {
            "id": "unused:literal",
            "kind": "literal",
            "domain": "unit",
            "codomain": "int",
            "phase": 3,
            "ordinal": 99,
            "dependencies": [],
            "inputs": [],
            "operation": "literal.int",
            "parameters": {"value": 1},
            "limits": {},
            "provenance": {"purpose": "deterministic rejection capsule"},
            "zero_relation": {
                "interface": "SDF0@Def",
                "domain": "literal",
                "codomain": "integer discrepancy",
                "semantics": "zero on exact literal equality",
                "lowering": "compile:literal-integrity",
            },
        }
    )
    doc["definitions"].append(extra)
    expect("unreachable_definition", doc, "unreachable definitions")

    return results


def clean_replay(primary_hashes: dict[str, str]) -> dict[str, Any]:
    with tempfile.TemporaryDirectory() as tmp:
        clean = Path(tmp) / "TOM_Genesis_1_0_Tom_Klootwijk"
        (clean / "src").mkdir(parents=True)
        shutil.copytree(ROOT / "src/python", clean / "src/python")
        shutil.copytree(ROOT / "src/c", clean / "src/c")
        (clean / "examples").mkdir()
        for stem in SOURCE_NAMES:
            shutil.copy2(EXAMPLES / f"{stem}.json", clean / "examples" / f"{stem}.json")
        (clean / "spec/seeded").mkdir(parents=True)
        shutil.copy2(ROOT / "spec/seeded/token_registry_1_0.json", clean / "spec/seeded/token_registry_1_0.json")
        shutil.copy2(ROOT / "TOM_seed_genome_2026-09-01.txt", clean / "TOM_seed_genome_2026-09-01.txt")

        env = os.environ.copy()
        env["PYTHONPATH"] = str(clean / "src/python")
        for stem in SOURCE_NAMES:
            run(
                [
                    sys.executable,
                    "-m",
                    "tomagi",
                    "compile",
                    f"examples/{stem}.json",
                    f"examples/{stem}.tmg",
                    "--manifest",
                    f"examples/{stem}.compile_manifest.json",
                ],
                cwd=clean,
                env=env,
            )
        for stem, artifact_name in BYTE_ARTIFACTS.items():
            run(
                [
                    sys.executable,
                    "-m",
                    "tomagi",
                    "materialize",
                    f"examples/{stem}.tmg",
                    f"examples/{artifact_name}",
                ],
                cwd=clean,
                env=env,
            )
        clean_exe = build_c(clean)
        for stem, artifact_name in BYTE_ARTIFACTS.items():
            suffix = ".c.pbm" if stem == "seed_raster" else ".c.bin"
            c_name = "TOM_seed_raster_32x61" + suffix if stem == "seed_raster" else "TOM_operation_algebra" + suffix
            run(
                [
                    str(clean_exe),
                    f"examples/{stem}.tmg",
                    "--materialize",
                    f"examples/{c_name}",
                ],
                cwd=clean,
            )

        observed = {
            f"{stem}.tmg": sha256_file(clean / "examples" / f"{stem}.tmg")
            for stem in SOURCE_NAMES
        }
        observed["seed_raster.pbm"] = sha256_file(clean / "examples/TOM_seed_raster_32x61.pbm")
        observed["seed_raster.c.pbm"] = sha256_file(clean / "examples/TOM_seed_raster_32x61.c.pbm")
        observed["operation_algebra.bin"] = sha256_file(clean / "examples/TOM_operation_algebra.bin")
        observed["operation_algebra.c.bin"] = sha256_file(clean / "examples/TOM_operation_algebra.c.bin")
        return {
            "all_equal": all(observed[name] == expected for name, expected in primary_hashes.items()),
            "expected": primary_hashes,
            "observed": observed,
            "source_capsule": [
                "TOM_seed_genome_2026-09-01.txt",
                "spec/seeded/token_registry_1_0.json",
                "examples/{seed_raster,operation_algebra,polar_loop,exact19_rule}.json",
                "src/python/tomagi/*",
                "src/c/tomagi.{h,c}",
                "src/c/tomagi_cli.c",
            ],
        }


def main() -> None:
    # Remove stale generated validation files while preserving the literal template.
    for path in VALIDATION.iterdir():
        if path.name == "genesis_certificate.template.json":
            continue
        if path.is_file():
            path.unlink()
        elif path.is_dir():
            shutil.rmtree(path)

    checks: list[dict[str, Any]] = []

    def add(name: str, passed: bool, evidence: Any) -> None:
        checks.append({"name": name, "status": "pass" if passed else "fail", "evidence": evidence})

    parsed_seed = parse_exact_seed((ROOT / "TOM_seed_genome_2026-09-01.txt").read_bytes())
    add(
        "canonical seed boundary",
        parsed_seed.byte_length == 244 and parsed_seed.sha256 == CANONICAL_SEED_SHA256,
        {"bytes": parsed_seed.byte_length, "sha256": parsed_seed.sha256, "terminal_newline": False},
    )

    registry_path = ROOT / "spec/seeded/token_registry_1_0.json"
    registry = load_token_registry(registry_path, parsed_seed)
    add(
        "versioned token registry boundary",
        registry["content_hash"]
        == "sha256:b14140cf9800e186701557ed982d692931966ea957e5790c1e6b4989e854c609"
        and len(registry["pipeline_tokens"]) == 28,
        {
            "profile_id": registry["profile_id"],
            "content_hash": registry["content_hash"],
            "tokens": len(registry["pipeline_tokens"]),
            "phase_order": registry["phase_order"],
        },
    )

    # Draft 2020-12 source validation is part of the source boundary.
    try:
        import jsonschema

        schema = json.loads((ROOT / "spec/tom_seeded_program.schema.json").read_text(encoding="utf-8"))
        for stem in SOURCE_NAMES:
            jsonschema.Draft202012Validator(schema).validate(load_source(stem))
        add("seeded source schemas", True, {"draft": "2020-12", "documents": list(SOURCE_NAMES)})
    except Exception as exc:
        add("seeded source schemas", False, str(exc))

    exe = build_c()
    manifests = compile_examples()

    # Unit and integration tests.
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT / "src/python")
    test_run = run(
        [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
        env=env,
        check=False,
    )
    (VALIDATION / "tests.txt").write_text(test_run.stdout + test_run.stderr, encoding="utf-8")
    match = re.search(r"Ran (\d+) tests", test_run.stdout + test_run.stderr)
    test_count = int(match.group(1)) if match else 0
    add("Python conformance suite", test_run.returncode == 0, {"tests": test_count, "return_code": test_run.returncode})

    source_evidence: dict[str, Any] = {}
    program_hashes: dict[str, str] = {}
    for stem, manifest in manifests.items():
        definition_hashes = [item["content_hash"] for item in manifest["definitions"]]
        program_hash = sha256_file(EXAMPLES / f"{stem}.tmg")
        program_hashes[f"{stem}.tmg"] = program_hash
        source_evidence[stem] = {
            "source_file_sha256": sha256_file(EXAMPLES / f"{stem}.json"),
            "source_document_sha256": manifest["source_document"]["sha256"],
            "definition_count": len(manifest["definitions"]),
            "definition_graph_sha256": canonical_sha(definition_hashes),
            "definition_order_sha256": canonical_sha(manifest["definition_order"]),
            "cell_count": manifest["lowering"]["cell_count"],
            "lowering_crosswalk_sha256": canonical_sha(manifest["lowering"]["cells"]),
            "tmg_bytes": (EXAMPLES / f"{stem}.tmg").stat().st_size,
            "tmg_sha256": program_hash,
        }
        all_hashes = all(item.startswith("sha256:") and len(item) == 71 for item in definition_hashes)
        add(
            f"{stem} executable definitions and lowering",
            all_hashes and manifest["lowering"]["cell_count"] > 0,
            source_evidence[stem],
        )

    artifact = (EXAMPLES / "TOM_seed_raster_32x61.pbm").read_bytes()
    artifact_hash = sha256_bytes(artifact)
    program_hashes["seed_raster.pbm"] = artifact_hash
    program_hashes["seed_raster.c.pbm"] = artifact_hash
    add(
        "TOM Seed Raster artifact boundary",
        len(artifact) == 253
        and artifact_hash == TARGET_ARTIFACT_SHA256
        and artifact == b"P4\n32 61\n" + (ROOT / "TOM_seed_genome_2026-09-01.txt").read_bytes(),
        {"format": "PBM P4", "width": 32, "height": 61, "bytes": len(artifact), "sha256": artifact_hash},
    )

    operation_artifact = (EXAMPLES / "TOM_operation_algebra.bin").read_bytes()
    operation_artifact_hash = sha256_bytes(operation_artifact)
    program_hashes["operation_algebra.bin"] = operation_artifact_hash
    program_hashes["operation_algebra.c.bin"] = operation_artifact_hash
    operation_expected = (
        b'TOM1TOM{"profile":"A1","version":1}'
        b'[[0,10],[1,20],[2,30]]\nOK\n'
    )
    add(
        "formal operation algebra artifact boundary",
        operation_artifact == operation_expected
        and operation_artifact_hash == OPERATION_ARTIFACT_SHA256,
        {
            "bytes": len(operation_artifact),
            "sha256": operation_artifact_hash,
            "operations_exercised": [
                "canonical literals",
                "fixed-width integer/bit operations",
                "bounded sequence slice/repeat/indexed map/concatenation",
                "predicates and binary selection",
                "State64 and Cell48 construction",
                "bounded cell graph construction",
                "ordered byte emission",
            ],
        },
    )

    backend = compare_python_c(exe)
    for name, result in backend.items():
        passed = all(
            result.get(field, True)
            for field in ("state_equal", "trace_equal", "emits_equal", "artifact_equal")
        )
        add(f"Python/C execution equality: {name}", passed, result)

    rejection = run_rejection_suite()
    add(
        "deterministic rejection capsule",
        all(item["rejected"] for item in rejection.values()),
        rejection,
    )

    # Primary examples are definition-only; legacy documents remain compilable.
    migration = {}
    for stem in ("polar_loop", "exact19_rule"):
        seeded_doc = load_source(stem)
        legacy_path = EXAMPLES / "legacy" / f"{stem}_legacy_cells.json"
        legacy_doc = json.loads(legacy_path.read_text(encoding="utf-8"))
        legacy_program = __import__("tomagi.compiler", fromlist=["compile_document"]).compile_document(legacy_doc)
        seeded_program = load(EXAMPLES / f"{stem}.tmg")
        legacy_state, legacy_trace = __import__("tomagi.core", fromlist=["run"]).run(legacy_program, trace=True)
        seeded_state, seeded_trace = __import__("tomagi.core", fromlist=["run"]).run(seeded_program, trace=True)
        migration[stem] = {
            "seeded_has_top_level_cells": "cells" in seeded_doc,
            "legacy_state_equal": state_dict(legacy_state) == state_dict(seeded_state),
            "legacy_trace_equal": legacy_trace == seeded_trace,
        }
    add(
        "polar_loop and exact19 definition migration",
        all(
            not item["seeded_has_top_level_cells"]
            and item["legacy_state_equal"]
            and item["legacy_trace_equal"]
            for item in migration.values()
        ),
        migration,
    )

    replay = clean_replay(program_hashes)
    add("clean source-capsule replay", replay["all_equal"], replay)

    summary = {
        "pass": sum(item["status"] == "pass" for item in checks),
        "fail": sum(item["status"] == "fail" for item in checks),
        "total": len(checks),
    }

    provenance_paths = [
        "TOM_seed_genome_2026-09-01.txt",
        "spec/seeded/token_registry_1_0.json",
        "spec/tom_seeded_program.schema.json",
        "src/python/tomagi/canonical.py",
        "src/python/tomagi/seed.py",
        "src/python/tomagi/seeded.py",
        "src/python/tomagi/compiler.py",
        "src/python/tomagi/core.py",
        "src/python/tomagi/format.py",
        "src/python/tomagi/materialize.py",
        "src/python/tomagi/template.py",
        "src/c/tomagi.h",
        "src/c/tomagi.c",
        "src/c/tomagi_cli.c",
        "tools/run_genesis_validation.py",
        "validation/genesis_certificate.template.json",
        *[f"examples/{stem}.json" for stem in SOURCE_NAMES],
    ]
    provenance_hashes = {rel: sha256_file(ROOT / rel) for rel in provenance_paths}

    certificate_record = {
        "schema": "TOM-GENESIS-VALIDATION-CERTIFICATE-1.0",
        "profile_id": "TOM-Seeded-Compilation-Profile-1.0",
        "tomagi_abi": "1.0.0",
        "project_date": "2026-09-01",
        "status": "pass" if summary["fail"] == 0 else "fail",
        "summary": summary,
        "canonical_seed": {
            "bytes": parsed_seed.byte_length,
            "sha256": parsed_seed.sha256,
            "token_count": len(parsed_seed.tokens),
        },
        "source_and_lowering_boundaries": source_evidence,
        "execution_boundaries": backend,
        "artifact": {
            "name": "TOM Seed Raster",
            "format": "PBM P4",
            "dimensions": [32, 61],
            "bytes": len(artifact),
            "sha256": artifact_hash,
            "raster_payload_is_exact_seed": artifact[9:] == (ROOT / "TOM_seed_genome_2026-09-01.txt").read_bytes(),
        },
        "operation_algebra_artifact": {
            "name": "TOM formal operation algebra proof",
            "bytes": len(operation_artifact),
            "sha256": operation_artifact_hash,
        },
        "rejections": rejection,
        "migration": migration,
        "clean_replay": replay,
        "checks": checks,
        "provenance": {
            "root_seed_file": "TOM_seed_genome_2026-09-01.txt",
            "token_registry": "spec/seeded/token_registry_1_0.json",
            "definition_sources": [f"examples/{stem}.json" for stem in SOURCE_NAMES],
            "compiler": "src/python/tomagi/seeded.py",
            "python_runtime": "src/python/tomagi/core.py",
            "c_runtime": ["src/c/tomagi.c", "src/c/tomagi_cli.c"],
            "materializer": "src/python/tomagi/materialize.py",
            "certificate_template": "validation/genesis_certificate.template.json",
            "file_sha256": provenance_hashes,
        },
        "scope": {
            "demonstrated": "deterministic seed parsing, executable formal-operation evaluation, State64/Cell48 construction, Cell48 lowering, TOMAGI Python/C execution equality, ordered EMIT materialization, and clean replay",
            "not_claimed": "new GPU dispatch evidence, universal performance, learned generalization, physical-device validation, or independent priority/patentability",
        },
    }

    certificate_ticks = (len(canonical_bytes(certificate_record)) + 1 + 3) // 4
    template = json.loads((VALIDATION / "genesis_certificate.template.json").read_text(encoding="utf-8"))
    values = {"certificate_record": certificate_record, "certificate_ticks": certificate_ticks}
    write_json(VALIDATION / "genesis_certificate.values.json", values)
    rendered = render_definition_template(template, values)
    source_path = VALIDATION / "genesis_certificate.source.json"
    source_path.write_text(json.dumps(rendered, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    certificate_program, certificate_manifest = compile_file_with_manifest(
        source_path,
        VALIDATION / "genesis_certificate.tmg",
        manifest_path=VALIDATION / "genesis_certificate.compile_manifest.json",
    )
    assert certificate_manifest is not None
    cert_py = execute_and_materialize(certificate_program)
    (VALIDATION / "genesis_certificate.json").write_bytes(cert_py.data)
    write_json(VALIDATION / "genesis_certificate.python_trace.json", cert_py.summary())
    cert_c_trace_path = VALIDATION / "genesis_certificate.c_trace.json"
    cert_c_artifact = VALIDATION / "genesis_certificate.c.json"
    run(
        [
            str(exe),
            str(VALIDATION / "genesis_certificate.tmg"),
            "--trace-json",
            str(cert_c_trace_path),
            "--materialize",
            str(cert_c_artifact),
        ]
    )
    cert_c = json.loads(cert_c_trace_path.read_text(encoding="utf-8"))
    certificate_proof = {
        "schema": "TOM-GENESIS-CERTIFICATE-PROOF-1.0",
        "source_sha256": sha256_file(source_path),
        "source_definition_count": len(rendered["definitions"]),
        "compile_manifest_sha256": sha256_file(VALIDATION / "genesis_certificate.compile_manifest.json"),
        "tmg_bytes": (VALIDATION / "genesis_certificate.tmg").stat().st_size,
        "tmg_sha256": sha256_file(VALIDATION / "genesis_certificate.tmg"),
        "artifact_bytes": len(cert_py.data),
        "artifact_sha256": sha256_bytes(cert_py.data),
        "python_c_state_equal": cert_py.summary()["state"] == cert_c["state"],
        "python_c_trace_equal": cert_py.trace == cert_c["trace"],
        "python_c_emits_equal": cert_py.emits == cert_c["emits"],
        "python_c_artifact_equal": cert_py.data == cert_c_artifact.read_bytes(),
        "emitted_record_status": certificate_record["status"],
    }
    write_json(VALIDATION / "genesis_certificate.proof.json", certificate_proof)

    final_failures = summary["fail"] + sum(
        not certificate_proof[field]
        for field in (
            "python_c_state_equal",
            "python_c_trace_equal",
            "python_c_emits_equal",
            "python_c_artifact_equal",
        )
    )
    markdown = [
        "# TOM Genesis validation",
        "",
        "Authoritative machine-emitted record: `genesis_certificate.json`.",
        "",
        f"Checks: {summary['pass']} passed, {summary['fail']} failed.",
        f"Conformance tests: {test_count}.",
        f"Seed raster: 253 bytes, SHA-256 `{artifact_hash}`.",
        f"Operation algebra artifact: {len(operation_artifact)} bytes, SHA-256 `{operation_artifact_hash}`.",
        f"Certificate: {len(cert_py.data)} bytes, SHA-256 `{sha256_bytes(cert_py.data)}`.",
        "",
        "The certificate bytes were produced by literal TOM seeded definitions, compiled to `.tmg`, executed by both Python and C, and reconstructed from ordered byte-mode `EMIT` records.",
        "",
    ]
    (VALIDATION / "VALIDATION.md").write_text("\n".join(markdown), encoding="utf-8")
    write_json(
        VALIDATION / "validation_summary.json",
        {
            "schema": "TOM-GENESIS-VALIDATION-SUMMARY-1.0",
            "summary": summary,
            "certificate_proof": certificate_proof,
        },
    )

    print(json.dumps({"summary": summary, "certificate_proof": certificate_proof}, indent=2, sort_keys=True))
    if final_failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
