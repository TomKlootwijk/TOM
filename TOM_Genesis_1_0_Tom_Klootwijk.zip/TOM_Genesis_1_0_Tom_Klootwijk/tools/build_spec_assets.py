"""Portable integrity check for shipped TOMAGI and TOM Genesis specification assets.

The original TOMAGI 1.0 asset-construction script depended on requester source files
outside the archive.  It is retained under tools/legacy for provenance.  Clean
replay uses this script, which verifies the already shipped source register,
catalogs, schemas, canonical seed, and token registry without undeclared inputs.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src" / "python"))

from tomagi.canonical import verify_hash
from tomagi.seed import load_token_registry, parse_exact_seed

REQUIRED_JSON = [
    "spec/operator_catalog.json",
    "spec/source_crosswalk.json",
    "spec/symbol_table.json",
    "spec/opcode_table.json",
    "spec/state64_layout.json",
    "spec/cell48_layout.json",
    "spec/status_flags.json",
    "spec/key_layout.json",
    "spec/morton_schedule_64.json",
    "spec/tomagi.schema.json",
    "spec/tom_seeded_program.schema.json",
    "sources/source_register.json",
]


def main() -> None:
    loaded = {}
    for rel in REQUIRED_JSON:
        path = ROOT / rel
        if not path.is_file():
            raise SystemExit(f"missing specification asset: {rel}")
        loaded[rel] = json.loads(path.read_text(encoding="utf-8"))

    if loaded["spec/operator_catalog.json"].get("count") != 43:
        raise SystemExit("operator catalog count is not 43")
    if loaded["spec/source_crosswalk.json"].get("count") != 319:
        raise SystemExit("source crosswalk count is not 319")
    if len(loaded["sources/source_register.json"].get("sources", [])) != 7:
        raise SystemExit("source register count is not 7")

    seed = (ROOT / "TOM_seed_genome_2026-09-01.txt").read_bytes()
    parsed = parse_exact_seed(seed)
    registry_path = ROOT / "spec/seeded/token_registry_1_0.json"
    registry = load_token_registry(registry_path, parsed)
    if not verify_hash(registry):
        raise SystemExit("token registry hash mismatch")

    print(
        json.dumps(
            {
                "operator_count": 43,
                "source_crosswalk_rows": 319,
                "source_artifacts": 7,
                "seed_bytes": parsed.byte_length,
                "seed_sha256": parsed.sha256,
                "token_registry_content_hash": registry["content_hash"],
                "status": "pass",
            },
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
