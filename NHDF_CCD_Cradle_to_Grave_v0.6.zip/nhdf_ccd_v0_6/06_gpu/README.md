# CUDA source candidate

The fixed-size candidate covers sphere, capsule, box and triangle support mappings,
a bounded GJK core and one-thread-per-pair conservative advancement wrapper.
Convex hulls, quadratic translation, full JSON certificates, BVH traversal and
persistent queues remain CPU-only in this release.

`convex_core.cuh` is dual-annotated for host/device compilation. The release host
smoke compiles this shared arithmetic with a normal C++ compiler. This is useful for
syntax and elementary logic validation, but it is not a CUDA execution result.

The GPU qualification gate requires all of the following:

1. compile for the actual target architecture using a supported CUDA toolkit;
2. run deterministic vectors and randomized corpora on the GPU;
3. compare definitive statuses and contact-band intervals with the Python reference;
4. inject queue, candidate, trace and iteration overflows;
5. report divergent/warp behavior, memory use, throughput, power and thermal state;
6. preserve unresolved states exactly rather than substituting `MISS`.

No GPU speed, precision, tensor-core, ray-core or memory-compression claim is made in
v0.6.
