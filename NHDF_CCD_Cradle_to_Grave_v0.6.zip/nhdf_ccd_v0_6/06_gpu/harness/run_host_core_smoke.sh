#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
g++ -std=c++17 -O2 -Wall -Wextra -pedantic "$HERE/host_core_smoke.cpp" -o "$HERE/host_core_smoke"
"$HERE/host_core_smoke"
