#include "../cuda/nhdf_cuda_common.cuh"
#include <cmath>
#include <iostream>
#include <stdexcept>
using namespace nhdf_cuda_v06;
static void req(bool v,const char* m){if(!v)throw std::runtime_error(m);} 
int main(){
    SpherePair hit{{-5,0,0},{10,0,0},.5,{0,0,0},{0,0,0},.5};
    auto a=sphere_sphere_linear(hit); req(a.status==HIT&&std::abs(a.toi-.4)<1e-12,"hit");
    SpherePair miss{{-5,3,0},{10,0,0},.5,{0,0,0},{0,0,0},.5};
    auto b=sphere_sphere_linear(miss); req(b.status==MISS,"miss");
    SpherePair overlap{{0,0,0},{0,0,0},1,{1,0,0},{0,0,0},1};
    auto c=sphere_sphere_linear(overlap); req(c.status==INITIAL_OVERLAP&&c.toi==0,"overlap");
    SpherePair bad=hit; bad.radius_a=-1; req(sphere_sphere_linear(bad).status==INVALID_INPUT,"invalid");
    std::cout<<"CUDA shared host profile: PASS sizeof(SpherePair)="<<sizeof(SpherePair)<<" sizeof(PairResult)="<<sizeof(PairResult)<<"\n";
}
