from pathlib import Path
p=Path(__file__).parents[1]/'cuda'/'rigid_convex_port_contract.cuh'
s=p.read_text()
required=['MAX_SIMPLEX=4','MAX_GJK_ITERATIONS=64','MAX_CA_ITERATIONS=128','overflow','must not allocate']
missing=[x for x in required if x not in s]
if missing: raise SystemExit(f'missing contract tokens: {missing}')
print('CUDA static port contract: PASS')
