#include "../cuda/convex_core.cuh"
#include <cassert>
#include <cmath>
#include <iostream>
using namespace nhdf_cuda_v06;
int main(){
    Shape sa{SPHERE,{0,0,0},{},{},{},1.0};
    Shape sb{SPHERE,{0,0,0},{},{},{},1.0};
    Body a{sa,{{{0,0,0},{1,0,0,0}},{4,0,0},{0,0,0}}};
    Body b{sb,{{{5,0,0},{1,0,0,0}},{0,0,0},{0,0,0}}};
    auto result=solve_pair(a,b);
    assert(result.status==0);
    assert(result.lo<0.75001 && result.hi>0.7499);
    std::cout<<"CUDA core host smoke passed\n";
}
