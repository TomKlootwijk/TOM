from __future__ import annotations

import json
from pathlib import Path
import shutil

root = Path(__file__).resolve().parents[2]
record = {
    "status": "SKIPPED",
    "reason": "nvcc and a CUDA-capable runtime are required; neither was available in the release environment",
    "nvcc_found": shutil.which("nvcc") is not None,
    "required_gate": "compile kernel, run deterministic vectors, compare statuses/TOI intervals with the Python reference",
}
(root / "04_verification" / "cuda_execution.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record, indent=2))
