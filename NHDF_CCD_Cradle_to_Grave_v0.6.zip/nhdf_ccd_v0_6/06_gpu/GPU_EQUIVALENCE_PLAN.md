# GPU equivalence plan

## Gate G-CUDA-1: compile
- Compile for an explicitly detected architecture; no hard-coded unsupported `sm_*` claim.
- Treat all warnings and register/local-memory spills in critical kernels as review items.

## Gate G-CUDA-2: deterministic vectors
- Run bundled sphere, miss, initial-overlap, tangent, and capacity vectors.
- Compare statuses exactly and TOI fields within declared binary64/binary32 profile tolerances.

## Gate G-CUDA-3: randomized differential
- Replay at least 100,000 seeded pairs against the CPU reference.
- No GPU `MISS` may correspond to CPU `HIT/INITIAL_OVERLAP` unless an independently adjudicated oracle rejects the CPU result.
- Any capacity or numerical alarm must propagate as a non-authoritative status.

## Gate G-CUDA-4: scheduling and overflow
- Inject queue overflow, block underfill, trace overflow, iteration limits, and watchdog budgets.
- Verify deterministic candidate ordering or document a canonical post-sort.

## Gate G-CUDA-5: performance
- Measure kernel time, end-to-end time, transfer cost, occupancy, memory bandwidth, energy/thermal behavior, and equal-budget baselines.

Only after all gates pass may the profile be labeled C2.
