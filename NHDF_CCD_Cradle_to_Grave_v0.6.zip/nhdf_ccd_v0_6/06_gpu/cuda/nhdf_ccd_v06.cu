#include "convex_core.cuh"
#include <cuda_runtime.h>

using namespace nhdf_cuda_v06;

extern "C" __global__ void nhdf_ccd_v06_pairs(const Body* bodies_a,
                                                const Body* bodies_b,
                                                Result* results,
                                                std::uint32_t count) {
    std::uint32_t index = blockIdx.x * blockDim.x + threadIdx.x;
    if (index >= count) return;
    results[index] = solve_pair(bodies_a[index], bodies_b[index]);
}
