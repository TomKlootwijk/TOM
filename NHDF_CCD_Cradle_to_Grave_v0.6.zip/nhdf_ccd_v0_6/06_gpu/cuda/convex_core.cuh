#pragma once

#include <cmath>
#include <cstdint>

#ifdef __CUDACC__
#define NHDF_HD __host__ __device__
#else
#define NHDF_HD
#endif

namespace nhdf_cuda_v06 {

struct Vec3 { double x,y,z; };
NHDF_HD inline Vec3 add(Vec3 a,Vec3 b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
NHDF_HD inline Vec3 sub(Vec3 a,Vec3 b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
NHDF_HD inline Vec3 mul(Vec3 a,double s){return {a.x*s,a.y*s,a.z*s};}
NHDF_HD inline Vec3 neg(Vec3 a){return {-a.x,-a.y,-a.z};}
NHDF_HD inline double dot(Vec3 a,Vec3 b){return a.x*b.x+a.y*b.y+a.z*b.z;}
NHDF_HD inline Vec3 cross(Vec3 a,Vec3 b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
NHDF_HD inline double norm2(Vec3 a){return dot(a,a);}
NHDF_HD inline double norm(Vec3 a){return sqrt(fmax(0.0,norm2(a)));}
NHDF_HD inline Vec3 normalize(Vec3 a){double n=norm(a);return n<=1e-15?Vec3{1,0,0}:mul(a,1.0/n);}
NHDF_HD inline double clamp01(double x){return fmax(0.0,fmin(1.0,x));}
NHDF_HD inline bool finite_scalar(double x){
#ifdef __CUDA_ARCH__
    return isfinite(x);
#else
    return std::isfinite(x);
#endif
}

struct Quat { double w,x,y,z; };
NHDF_HD inline Quat qnormalize(Quat q){double n=sqrt(q.w*q.w+q.x*q.x+q.y*q.y+q.z*q.z);return n<=1e-30?Quat{1,0,0,0}:Quat{q.w/n,q.x/n,q.y/n,q.z/n};}
NHDF_HD inline Quat qmul(Quat a,Quat b){return {a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z,a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w};}
NHDF_HD inline Quat qfrom_rotvec(Vec3 r){double a=norm(r);if(a<=1e-15)return qnormalize({1,.5*r.x,.5*r.y,.5*r.z});Vec3 u=mul(r,1.0/a);double h=.5*a,s=sin(h);return {cos(h),u.x*s,u.y*s,u.z*s};}
NHDF_HD inline Vec3 qrotate(Quat q,Vec3 v){q=qnormalize(q);Vec3 u{q.x,q.y,q.z};Vec3 t=mul(cross(u,v),2.0);return add(add(v,mul(t,q.w)),cross(u,t));}
NHDF_HD inline Vec3 qinvrotate(Quat q,Vec3 v){return qrotate({q.w,-q.x,-q.y,-q.z},v);}

struct Transform { Vec3 p; Quat q; };
struct Motion { Transform start; Vec3 linear; Vec3 angular; };
NHDF_HD inline Transform at(Motion m,double t){return {add(m.start.p,mul(m.linear,t)),qnormalize(qmul(qfrom_rotvec(mul(m.angular,t)),m.start.q))};}
NHDF_HD inline Vec3 apply(Transform t,Vec3 p){return add(qrotate(t.q,p),t.p);}

// Fixed-size source-complete GPU profile. Convex hulls use the CPU path in v0.6.
enum ShapeKind : int32_t { SPHERE=0, CAPSULE=1, BOX=2, TRIANGLE=3 };
struct Shape {
    int32_t kind;
    Vec3 p0,p1,p2;       // center; capsule endpoints; triangle vertices
    Vec3 half_extents;   // box
    double radius;       // sphere/capsule
};
struct Body { Shape shape; Motion motion; };

NHDF_HD inline Vec3 support_local(const Shape& s,Vec3 d){
    Vec3 n=normalize(d);
    if(s.kind==SPHERE)return add(s.p0,mul(n,s.radius));
    if(s.kind==CAPSULE)return add(dot(s.p0,d)>=dot(s.p1,d)?s.p0:s.p1,mul(n,s.radius));
    if(s.kind==BOX)return add(s.p0,{d.x>=0?s.half_extents.x:-s.half_extents.x,d.y>=0?s.half_extents.y:-s.half_extents.y,d.z>=0?s.half_extents.z:-s.half_extents.z});
    Vec3 best=s.p0;double bd=dot(best,d);double value=dot(s.p1,d);if(value>bd){best=s.p1;bd=value;}value=dot(s.p2,d);if(value>bd)best=s.p2;return best;
}
NHDF_HD inline Vec3 center_local(const Shape&s){if(s.kind==SPHERE||s.kind==BOX)return s.p0;if(s.kind==CAPSULE)return mul(add(s.p0,s.p1),.5);return mul(add(add(s.p0,s.p1),s.p2),1.0/3.0);}
NHDF_HD inline double radius_bound(const Shape&s){if(s.kind==SPHERE)return norm(s.p0)+s.radius;if(s.kind==CAPSULE)return fmax(norm(s.p0),norm(s.p1))+s.radius;if(s.kind==BOX)return norm(s.p0)+norm(s.half_extents);return fmax(norm(s.p0),fmax(norm(s.p1),norm(s.p2)));}
NHDF_HD inline Vec3 support_world(const Shape&s,Transform t,Vec3 d){return apply(t,support_local(s,qinvrotate(t.q,d)));}

struct Support { Vec3 p; };
NHDF_HD inline Support support_diff(const Body&a,const Body&b,double t,Vec3 d){Transform ta=at(a.motion,t),tb=at(b.motion,t);return {sub(support_world(a.shape,ta,d),support_world(b.shape,tb,neg(d)))};}

struct Simplex { Support p[4]; double w[4]; int n; Vec3 closest; bool overlap; };
NHDF_HD inline void segment_closest(Vec3 a,Vec3 b,Vec3& p,double*w){Vec3 ab=sub(b,a);double den=norm2(ab);double t=den<=1e-30?0.0:clamp01(dot(neg(a),ab)/den);p=add(a,mul(ab,t));w[0]=1-t;w[1]=t;}
NHDF_HD inline void triangle_closest(Vec3 a,Vec3 b,Vec3 c,Vec3& p,double*w){
    Vec3 ab=sub(b,a),ac=sub(c,a),ap=neg(a);double d1=dot(ab,ap),d2=dot(ac,ap);
    if(d1<=0&&d2<=0){p=a;w[0]=1;w[1]=w[2]=0;return;}Vec3 bp=neg(b);double d3=dot(ab,bp),d4=dot(ac,bp);if(d3>=0&&d4<=d3){p=b;w[1]=1;w[0]=w[2]=0;return;}
    double vc=d1*d4-d3*d2;if(vc<=0&&d1>=0&&d3<=0){double v=d1/(d1-d3);p=add(a,mul(ab,v));w[0]=1-v;w[1]=v;w[2]=0;return;}Vec3 cp=neg(c);double d5=dot(ab,cp),d6=dot(ac,cp);if(d6>=0&&d5<=d6){p=c;w[2]=1;w[0]=w[1]=0;return;}
    double vb=d5*d2-d1*d6;if(vb<=0&&d2>=0&&d6<=0){double q=d2/(d2-d6);p=add(a,mul(ac,q));w[0]=1-q;w[1]=0;w[2]=q;return;}double va=d3*d6-d5*d4;if(va<=0&&(d4-d3)>=0&&(d5-d6)>=0){Vec3 bc=sub(c,b);double q=(d4-d3)/((d4-d3)+(d5-d6));p=add(b,mul(bc,q));w[0]=0;w[1]=1-q;w[2]=q;return;}
    double den=va+vb+vc;if(fabs(den)<=1e-30){Vec3 p0,p1,p2;double w0[2],w1[2],w2[2];segment_closest(a,b,p0,w0);segment_closest(a,c,p1,w1);segment_closest(b,c,p2,w2);if(norm2(p0)<=norm2(p1)&&norm2(p0)<=norm2(p2)){p=p0;w[0]=w0[0];w[1]=w0[1];w[2]=0;}else if(norm2(p1)<=norm2(p2)){p=p1;w[0]=w1[0];w[1]=0;w[2]=w1[1];}else{p=p2;w[0]=0;w[1]=w2[0];w[2]=w2[1];}return;}
    double v=vb/den,q=vc/den;w[0]=1-v-q;w[1]=v;w[2]=q;p=add(add(mul(a,w[0]),mul(b,w[1])),mul(c,w[2]));
}
NHDF_HD inline bool tetra_inside(Vec3 a,Vec3 b,Vec3 c,Vec3 d,double*w){Vec3 ba=sub(b,a),ca=sub(c,a),da=sub(d,a),r=neg(a);double den=dot(ba,cross(ca,da));if(fabs(den)<=1e-18)return false;w[1]=dot(r,cross(ca,da))/den;w[2]=dot(ba,cross(r,da))/den;w[3]=dot(ba,cross(ca,r))/den;w[0]=1-w[1]-w[2]-w[3];return w[0]>=-1e-12&&w[1]>=-1e-12&&w[2]>=-1e-12&&w[3]>=-1e-12;}
NHDF_HD inline Simplex reduce(Simplex s){
    if(s.n==1){s.w[0]=1;s.closest=s.p[0].p;s.overlap=false;return s;}
    double weights[4]{0,0,0,0};Vec3 point{};bool overlap=false;
    if(s.n==2)segment_closest(s.p[0].p,s.p[1].p,point,weights);
    else if(s.n==3)triangle_closest(s.p[0].p,s.p[1].p,s.p[2].p,point,weights);
    else if(tetra_inside(s.p[0].p,s.p[1].p,s.p[2].p,s.p[3].p,weights)){point={0,0,0};overlap=true;}
    else{
        const int face[4][3]={{0,1,2},{0,1,3},{0,2,3},{1,2,3}};double best=1e300,bw[4]{0,0,0,0};Vec3 bp{};
        for(int f=0;f<4;++f){double tw[3];Vec3 tp;triangle_closest(s.p[face[f][0]].p,s.p[face[f][1]].p,s.p[face[f][2]].p,tp,tw);double d2=norm2(tp);if(d2<best){best=d2;bp=tp;for(int i=0;i<4;++i)bw[i]=0;for(int i=0;i<3;++i)bw[face[f][i]]=tw[i];}}
        point=bp;for(int i=0;i<4;++i)weights[i]=bw[i];
    }
    if(overlap){s.closest=point;s.overlap=true;for(int i=0;i<s.n;++i)s.w[i]=weights[i];return s;}
    Simplex out{};out.n=0;out.overlap=false;double total=0;for(int i=0;i<s.n;++i)if(weights[i]>1e-12){out.p[out.n]=s.p[i];out.w[out.n]=weights[i];total+=weights[i];++out.n;}if(out.n==0){out.p[0]=s.p[0];out.w[0]=1;out.n=1;total=1;}out.closest={0,0,0};for(int i=0;i<out.n;++i){out.w[i]/=total;out.closest=add(out.closest,mul(out.p[i].p,out.w[i]));}return out;
}

struct Distance { int status; double lower,upper; int iterations; };
NHDF_HD inline Distance gjk(const Body&a,const Body&b,double t,int max_iter=64){
    Transform ta=at(a.motion,t),tb=at(b.motion,t);Vec3 d=sub(apply(ta,center_local(a.shape)),apply(tb,center_local(b.shape)));if(norm2(d)<=1e-30)d={1,0,0};Simplex s{};s.n=1;s.p[0]=support_diff(a,b,t,d);s=reduce(s);double lower=0;
    for(int it=1;it<=max_iter;++it){double upper=norm(s.closest);if(s.overlap||upper<=1e-10)return {s.overlap?2:1,0,upper,it};Support c=support_diff(a,b,t,neg(s.closest));double lb=dot(s.closest,c.p)/upper;if(finite_scalar(lb))lower=fmax(lower,fmin(upper,lb));lower=fmax(0.0,lower);if(upper-lower<=1e-10+1e-10*upper)return {0,lower,upper,it};bool dup=false;for(int i=0;i<s.n;++i)if(norm2(sub(s.p[i].p,c.p))<=1e-26*fmax(1.0,norm2(c.p)))dup=true;if(dup)return {0,lower,upper,it};if(s.n<4)s.p[s.n++]=c;else{s.p[3]=c;}s=reduce(s);}return {0,lower,norm(s.closest),max_iter};
}

struct Result { int status; double lo,hi,distance; int iterations; };
NHDF_HD inline Result solve_pair(const Body&a,const Body&b,double distance_tol=1e-6,double time_tol=1e-7,int max_iter=256){double speed=norm(sub(a.motion.linear,b.motion.linear))+norm(a.motion.angular)*radius_bound(a.shape)+norm(b.motion.angular)*radius_bound(b.shape);double t=0,prev=0;Distance d=gjk(a,b,0);if(d.status==2)return {2,0,0,d.upper,0};if(d.upper<=distance_tol)return {0,0,0,d.upper,0};if(speed<=1e-14)return {1,0,0,d.upper,0};for(int it=1;it<=max_iter;++it){if(d.lower-speed*(1-t)>distance_tol)return {1,0,0,d.upper,it};double step=.8*d.lower/speed;if(step<=time_tol)return {3,prev,t,d.upper,it};prev=t;t=fmin(1.0,t+step);d=gjk(a,b,t);if(d.upper<=distance_tol||d.status==1||d.status==2)return {0,prev,t,d.upper,it};if(t>=1)return {1,0,0,d.upper,it};}return {3,prev,t,d.upper,max_iter};}

} // namespace nhdf_cuda_v06
