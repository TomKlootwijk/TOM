#include "nhdf_cuda_common.cuh"
using namespace nhdf_cuda_v06;

extern "C" __global__ void nhdf_sphere_pair_ccd_v06(
    const SpherePair* __restrict__ pairs,
    PairResult* __restrict__ results,
    std::uint32_t count)
{
    const std::uint32_t index=blockIdx.x*blockDim.x+threadIdx.x;
    if(index<count) results[index]=sphere_sphere_linear(pairs[index]);
}
