#pragma once
#include <cmath>
#include <cstdint>

#ifdef __CUDACC__
#define NHDF_HD __host__ __device__
#else
#define NHDF_HD
#endif

namespace nhdf_cuda_v06 {

enum Status : std::uint32_t { MISS=0, HIT=1, INITIAL_OVERLAP=2, INVALID_INPUT=3, NUMERICAL_FAILURE=4, UNSUPPORTED=5 };
struct Vec3 { double x,y,z; };
struct SpherePair {
    Vec3 center_a0, velocity_a;
    double radius_a;
    Vec3 center_b0, velocity_b;
    double radius_b;
};
struct PairResult { std::uint32_t status; double toi; double residual; };

NHDF_HD inline Vec3 sub(Vec3 a, Vec3 b){ return {a.x-b.x,a.y-b.y,a.z-b.z}; }
NHDF_HD inline double dot(Vec3 a, Vec3 b){ return a.x*b.x+a.y*b.y+a.z*b.z; }
NHDF_HD inline bool finite_scalar(double x){
#ifdef __CUDA_ARCH__
    return isfinite(x);
#else
    return std::isfinite(x);
#endif
}
NHDF_HD inline bool finite3(Vec3 a){ return finite_scalar(a.x)&&finite_scalar(a.y)&&finite_scalar(a.z); }

NHDF_HD inline PairResult sphere_sphere_linear(const SpherePair& p){
    if(!finite3(p.center_a0)||!finite3(p.center_b0)||!finite3(p.velocity_a)||!finite3(p.velocity_b)||
       !finite_scalar(p.radius_a)||!finite_scalar(p.radius_b)||p.radius_a<0.0||p.radius_b<0.0)
        return {INVALID_INPUT,-1.0,0.0};
    const Vec3 x=sub(p.center_a0,p.center_b0), v=sub(p.velocity_a,p.velocity_b);
    const double r=p.radius_a+p.radius_b;
    const double c=dot(x,x)-r*r;
    if(c<=0.0) return {INITIAL_OVERLAP,0.0,c};
    const double a=dot(v,v), b=2.0*dot(x,v);
    if(a<=1e-30) return {MISS,-1.0,c};
    const double disc=b*b-4.0*a*c;
    if(disc<0.0) return {MISS,-1.0,disc};
    const double root=::sqrt(disc<0.0?0.0:disc);
    const double q=-0.5*(b+::copysign(root,b));
    double t0=q/a;
    double t1=(::fabs(q)>1e-30)?c/q:1e300;
    double t=1e300;
    if(t0>=0.0&&t0<=1.0)t=t0;
    if(t1>=0.0&&t1<=1.0&&t1<t)t=t1;
    return t<1e200 ? PairResult{HIT,t,disc} : PairResult{MISS,-1.0,disc};
}

} // namespace nhdf_cuda_v06
