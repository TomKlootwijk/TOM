#pragma once
// Port contract, not a completed device backend.
// Required fixed-capacity records for a future rigid-convex CUDA profile.
#include <cstdint>
namespace nhdf_cuda_v06 {
constexpr int MAX_SIMPLEX=4;
constexpr int MAX_GJK_ITERATIONS=64;
constexpr int MAX_CA_ITERATIONS=128;
struct SupportPointF64 { double px,py,pz,ax,ay,az,bx,by,bz; std::uint32_t fa,fb; };
struct GJKWorkspaceF64 { SupportPointF64 simplex[MAX_SIMPLEX]; double weight[MAX_SIMPLEX]; std::uint32_t size; };
struct QueueHeader { std::uint32_t count,capacity,overflow; };
// A conforming kernel must preserve INVALID/NUMERICAL/INCONCLUSIVE/RESOURCE states.
// It must not allocate device memory, recurse, or force a minimum unsafe time step.
}
