# Provenance policy

1. Source files are retained byte-for-byte and hashed; they are not treated as
   validated technical evidence merely because they are archived.
2. The 30-page initial chain is the vocabulary origin. The v0.1 formalization is
   the first non-degenerate typed interpretation. The 40-page commute transcript
   motivates CCD but contains unsupported one-clock and response claims. The
   wider whole-substrate transcript is available to the project through parsed
   source context, but its raw attachment bytes were not mounted for this build.
3. v0.4 and v0.5 are historical releases. v0.6 may correct their claims but does
   not rewrite their bytes.
4. Research papers are external references. Their methods inform the work; no
   claim of identity, novelty transfer or endorsement is implied.
5. Generated benchmark data records its seed, runtime environment and limitations.
6. Author identity metadata is attribution only and is never a secret or proof key.
