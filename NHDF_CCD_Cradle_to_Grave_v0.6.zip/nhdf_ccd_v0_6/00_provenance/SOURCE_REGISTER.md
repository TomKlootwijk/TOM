# Source register

| ID | Artifact | Role in v0.6 | Evidence handling |
|---|---|---|---|
| S1 | `S1_original_operator_chain.pdf` | origin of parity, log-polar LUT, local geometry, BST/L-system, sweep and projection vocabulary | preserved; claims reinterpreted through typed CCD contracts |
| S2 | `S2_NHDF_Formal_Specification_v0.1.pdf` | non-degenerate local zero sets, bounded resources, causal timeline and conformance ladder | normative conceptual predecessor |
| S3 | `S3_commute_design_transcript.pdf` | log-polar Jacobian observation and explicit Continuous Collision Detection objective | design input; one-lookup/one-clock statements rejected |
| S4 | wider spherical/Cartesian whole-substrate transcript | sensors, actuators, medical, optical, quantum, chemical, fabrication and cosmology mappings | parsed content mapped into separate adapters; raw bytes unavailable in build mount |
| R04 | previous v0.4 PDF/ZIP | primitive CCD cradle-to-grave baseline | immutable historical annex/source |
| R05 | previous v0.5 PDF | point/sphere-triangle and mesh-facing baseline | immutable predecessor; appended to report |
| P1 | Gilbert-Johnson-Keerthi (1988) | support-mapping convex distance foundation | external primary reference |
| P2 | Redon-Kheddar-Coquillart (2002) | continuous rigid motion, interval and hierarchy context | external primary reference |
| P3 | Ferguson et al. (2021) | modern curved rigid-trajectory and intersection-free dynamics context | external primary reference |

> **Build note:** S4 is fully represented in the supplied parsed-file context and adapter mapping, but its original byte stream was not mounted in the active build runtime. The release does not reconstruct or silently replace it.
