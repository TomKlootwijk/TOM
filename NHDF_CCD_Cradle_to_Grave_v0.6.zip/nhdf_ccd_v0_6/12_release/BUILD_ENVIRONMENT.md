# Build environment snapshot

- Generated: 2026-09-01 UTC
- Python: 3.13.5
- Platform: Linux-6.18.35-x86_64-with-glibc2.41
- Machine: x86_64
- Processor: not reported
- CPU count: 5
- CUDA compiler/device: not detected during authoring; checked again by release script

Exact package/compiler versions are captured in `RELEASE_VALIDATION_LOG.json` and the package manifest.
