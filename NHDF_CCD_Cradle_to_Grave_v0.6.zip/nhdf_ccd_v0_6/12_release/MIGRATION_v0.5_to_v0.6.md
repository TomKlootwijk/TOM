# Migration from v0.5

- Replace primitive-specific dispatch assumptions with the `ConvexShape` support interface where possible.
- Interpret general-profile `HIT` as contact-band entry; keep exact-profile flags separate.
- Include angular velocity and shape bounding radius in motion bounds.
- Handle `NUMERICAL_FAILURE` distinctly from `INCONCLUSIVE`.
- Handle broad-phase `RESOURCE_EXHAUSTED`; partial pairs are not authoritative.
- Update scene/certificate schema versions to `0.6.0`.
- Re-run deterministic replay because GJK termination and witness labels are new.
