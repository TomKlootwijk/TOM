# Roadmap

## v0.7 - linear primitives and deforming mesh
- interval/inclusion triangle-triangle and edge-edge profiles;
- deforming vertex trajectories and exact/filtered predicates;
- public TOI dataset adapter and degeneracy suite.

## v0.8 - contact dynamics
- manifold generation, simultaneous-contact grouping, friction/restitution solver interface;
- energy/momentum diagnostics and solver-level tunnelling regression.

## v0.9 - acceleration and qualification
- CUDA device implementation, deterministic compaction, CPU/GPU differential corpus;
- production BVH/refit path, profiling, power/thermal measurements;
- engine integration study and safety case.

## v1.0 - stable profile
- frozen schemas and conformance suite;
- independently replicated benchmark;
- documented supported/unsupported scene classes and retirement commitments.
