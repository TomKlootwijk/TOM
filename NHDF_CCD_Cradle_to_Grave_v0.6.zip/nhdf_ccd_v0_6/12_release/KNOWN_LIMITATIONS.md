# Known limitations

1. Binary64 GJK and CA are not exact predicates for every degenerate input.
2. The general TOI is contact-band entry, not an exact root.
3. Angular speed bounds can be conservative and slow near contact.
4. No EPA penetration depth or robust manifold generator is included.
5. Triangle is treated as a convex support set; general triangle-triangle/deforming CCD is not provided.
6. Non-convex bodies require external decomposition and pair management.
7. The BVH is a readable deterministic reference, not a production refit/parallel implementation.
8. C++ parity with every Python field/trace is not complete.
9. CUDA device compilation and CPU/GPU differential testing were unavailable.
10. Wider optical, quantum, chemical, biological, medical, fabrication, and cosmological mappings remain A0 hypotheses.
