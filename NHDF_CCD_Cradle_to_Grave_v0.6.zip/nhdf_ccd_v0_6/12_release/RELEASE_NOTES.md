# NHDF-CCD v0.6.0 release notes

This release takes the next roadmap turn after v0.5: from translational sphere/triangle-mesh primitives to a common support-mapped rigid-convex narrow phase and a reference swept-AABB BVH.

The central correctness change is that general CCD no longer pretends to isolate an exact zero-distance root. It certifies safe advancement using a separation lower bound and a linear-plus-angular speed envelope, then reports entry into a declared numerical contact band. Exact linear sphere profiles remain available as specialized backends and independent checks.

The Python and C++17 references are executable. The CUDA sphere kernel and shared host profile are supplied, but device compilation/equivalence remain unverified because no CUDA toolchain/device is present.
