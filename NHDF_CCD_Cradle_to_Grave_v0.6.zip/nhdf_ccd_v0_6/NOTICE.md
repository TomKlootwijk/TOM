# Notice

The author attribution is **Tom Klootwijk**. Civil-registration numbers, dates of
birth and commute photographs or observations appearing in source transcripts are
not runtime credentials, cryptographic keys, scientific evidence or safety
certificates. They are deliberately excluded from executable initialization and
hashing logic.

The bundled source PDFs contain AI-generated statements that overclaim one-clock
CCD, physical immunity, medical repair, quantum behavior and fabrication readiness.
Those statements are retained for provenance and are not endorsed by this release.
The normative core is the bounded CCD specification, implementation, tests and
explicit evidence ladder.

Third-party papers are cited bibliographically but are not redistributed in the
package. Previous NHDF-CCD releases are retained as authored historical artifacts.
