# Cradle-to-grave roadmap

| Gate | Lifecycle question | v0.6 evidence | Exit state |
|---|---|---|---|
| G0 Provenance | What source, claim and release history is being continued? | source register, hashes, v0.4/v0.5 artifacts | complete |
| G1 Definition | What exact CCD profile is in scope? | requirements, exclusions, acceptance criteria | complete |
| G2 Formalization | Are shape, motion, bounds, status and certificate semantics typed? | formal specification and JSON schemas | complete |
| G3 CPU reference | Does executable code implement the profile? | Python and independent C++17 sources | complete for declared slice |
| G4 Verification | Do tests and independent oracles challenge each correctness path? | unit, differential, adversarial and replay tests | complete for generated corpus |
| G5 Benchmarking | Are correctness, tunnelling, error and broad-phase observations reproducible? | seeded CSV/JSON outputs and figures | complete for release environment |
| G6 Acceleration | Is a GPU candidate present and qualified? | source candidate and host smoke; no CUDA run | candidate only |
| G7 Integration | Can an engine consume statuses without unsafe coercion? | integration/migration contracts | documented |
| G8 Operations | Can failures be detected, logged and escalated? | runbook, telemetry, incident response | documented |
| G9 Maintenance | Can changes be reviewed and regressions reproduced? | change control and semantic-version rules | documented |
| G10 Retirement | Can the profile be decommissioned without losing evidence? | retirement and archive plan | documented |

## Forward plan

- **v0.7 - production implicit/SDF profile:** validated Lipschitz contracts, moving
  implicit objects, interval fallbacks, gradient singularity handling and SDF/convex
  cross-backend differential tests.
- **v0.8 - qualified GPU runtime:** persistent bounded queues, compiled CUDA,
  CPU/GPU certificate equivalence, overflow injection and target-hardware metrics.
- **v0.9 - application proof:** integration with a renderer or physics engine and
  equal-budget comparison against established CCD baselines.
- **v1.0 - stable core:** frozen schemas, independent replication, documented
  compatibility policy and a claim set limited to demonstrated results.
