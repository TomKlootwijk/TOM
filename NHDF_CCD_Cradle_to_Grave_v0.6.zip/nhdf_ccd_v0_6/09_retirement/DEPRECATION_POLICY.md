# Deprecation policy

Patch releases may fix implementation defects without changing schema identifiers when semantics remain compatible. Any change to status authority, time-field meaning, coordinate convention, or required field triggers a new schema/profile version. A deprecated profile may be executed only with an explicit opt-in and visible warning.
