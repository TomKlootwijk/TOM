# Retirement plan

Retire v0.6 when a successor freezes compatible schemas and demonstrates equal or
stronger behavior on the v0.6 corpus, or immediately when an unbounded false-negative
mechanism is discovered.

Retirement steps:

1. mark the package read-only and record final SHA-256 manifests;
2. retain source, compiler/environment records, tests, benchmark outputs and report;
3. publish status/schema migration tables;
4. disable runtime selection in deployed systems before deleting binaries;
5. preserve incident and limitation records for the applicable retention period;
6. never delete evidence needed to reproduce a safety or correctness incident.

Historical source transcripts remain provenance, not active requirements.
