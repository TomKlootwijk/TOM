# Changelog

## 0.6.0 - 2026-09-01

### Added
- Support-mapped convex shape contract and deterministic feature labels.
- Audit-oriented GJK result with support-plane lower bound, simplex upper bound, witnesses, termination reason, and optional trace.
- Rigid-convex conservative advancement with a global linear-plus-angular point-speed bound.
- Quadratic translation and constant world-axis angular motion profile.
- Exact linear sphere-capsule profile in addition to sphere-sphere.
- Deterministic swept-AABB BVH and explicit `RESOURCE_EXHAUSTED` result.
- C++17 reference implementation and smoke corpus.
- CUDA exact sphere-pair profile, portable data layout, host mirror, and GPU equivalence plan.
- Independent convex-QP and analytic-orbit benchmark oracles.
- Versioned scene, certificate, telemetry, and adapter schemas.

### Corrected
- A CCD `HIT` in the general profile is now documented as contact-band entry, not exact root isolation.
- Separation distance, topological notation, one-bit parity, and collision certification are kept semantically distinct.
- Angular motion is bounded by `|omega| * bounding_radius`; it is not approximated as translation-only.

### Deferred
- Production-grade EPA penetration depth/manifold generation.
- General triangle-triangle and deforming-mesh CCD.
- Exact predicates/interval arithmetic for all convex queries.
- Device-compiled CUDA and measured CPU/GPU equivalence.
- Full dynamics/contact response.
