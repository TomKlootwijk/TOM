# Distribution and attribution notice

The project files are supplied to the requesting author for research evaluation and continuation. The documents record **Tom Klootwijk** as the supplied author attribution. Civil metadata contained in historical source material is not independently verified and is not a cryptographic credential.

No patentability, freedom-to-operate, clinical efficacy, certification, merchantability, or fitness-for-purpose representation is made. Third-party references remain subject to their own licenses. The implementation in this package was written for this release and does not incorporate openGJK source code.
