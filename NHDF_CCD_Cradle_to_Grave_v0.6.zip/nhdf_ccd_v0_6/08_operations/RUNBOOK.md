# Operations runbook

## Start of run

- record package version, source manifest, configuration and world-unit scale;
- validate scene JSON and reject non-finite values;
- measure available memory/candidate capacity;
- run deterministic smoke vectors after deployment or hardware change.

## Per step telemetry

Record pair count, candidates, BVH nodes tested, status counts, earliest activation,
maximum GJK/CA iterations, non-convergence reasons, contact-band tolerances, trace
hashes, capacity watermarks and wall-clock time.

## Safe degradation

- on `INCONCLUSIVE`: subdivide the global step or use a stronger interval/exact backend;
- on `RESOURCE_EXHAUSTED`: do not use partial pair output; rebuild with greater
  capacity or reduce scene/work partition;
- on `NUMERICAL_FAILURE`: quarantine the pair, preserve inputs and diagnostics;
- on repeated failures: disable the v0.6 backend and restore the last qualified
  engine configuration.

## Stop conditions

Stop authoritative operation when schema mismatch, non-finite data, candidate
truncation, repeated GJK non-convergence, unavailable fallback, digest/replay drift or
unreviewed configuration change occurs.
