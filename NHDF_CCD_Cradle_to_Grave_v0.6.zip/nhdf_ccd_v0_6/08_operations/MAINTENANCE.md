# Maintenance plan

- Quarterly: rebuild in supported Python/C++ toolchains and compare deterministic
  vectors.
- On compiler/NumPy change: rerun all tests and generated benchmarks; examine bound
  and status drift.
- On new shape: prove/inspect compact convexity, support-map correctness and finite
  bounding radius; add analytic or independently computed distance cases.
- On new motion: derive a conservative point-speed bound and swept envelope before
  enabling narrow phase.
- On GPU qualification: maintain a target matrix of toolkit, driver, architecture and
  floating-point mode; no result transfers automatically between devices.
- Annually: review the risk and claim ledgers and archive superseded releases.
