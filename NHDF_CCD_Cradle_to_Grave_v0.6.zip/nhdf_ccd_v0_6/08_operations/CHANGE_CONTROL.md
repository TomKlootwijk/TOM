# Change control

Any modification to support mappings, quaternion order, bounding radius, distance
bounds, speed bound, tolerance, status mapping, broad-phase pruning or serialization
is a correctness-affecting change.

Required review artifacts:

1. issue and rationale;
2. changed formal contract;
3. new/updated adversarial tests;
4. before/after seeded benchmark;
5. Python/C++ and, when qualified, CPU/GPU differential results;
6. schema compatibility statement;
7. risk-register update;
8. reviewer sign-off independent of the implementation author for production use.

Patch releases may fix documentation or non-semantic tooling. Any change to contact
or failure classification requires a minor/major version and a migration note.
