# Incident response

A collision miss, false event, silent pair truncation, non-deterministic replay or
unsafe status coercion is a severity-one correctness incident for any authoritative
integration.

1. Freeze the triggering scene, configuration, binary, driver/runtime and telemetry.
2. Stop using the affected backend; activate the qualified fallback.
3. Reproduce on CPU with full trace and reduced time steps.
4. Determine whether the fault is input, broad phase, support map, GJK, speed bound,
   time advancement, serialization, response or hardware-specific.
5. Add the minimal case to the permanent regression corpus.
6. Correct the formal contract before correcting code if semantics were ambiguous.
7. Re-run all release gates and publish an impact/migration notice.

Do not retroactively relabel an unresolved result as a miss to make a log appear clean.
