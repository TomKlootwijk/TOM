# Public-safety governance boundary

CCD may support obstacle prediction, simulation, robotics and vehicle planning, but
this release is not authorized for autonomous enforcement, pursuit decisions,
identification, use-of-force selection or evidentiary chain-of-custody claims.

A public-safety adapter must add independently validated sensing, uncertainty,
fail-operational/fail-safe analysis, human authorization, cybersecurity, privacy,
bias assessment, logging and jurisdiction-specific legal review. A trace hash is not
a signature and author civil metadata is not a trust anchor.

The appropriate v0.6 use is offline simulation or a shadow-mode geometric safety
component whose failures are measurable and cannot directly command coercive action.
