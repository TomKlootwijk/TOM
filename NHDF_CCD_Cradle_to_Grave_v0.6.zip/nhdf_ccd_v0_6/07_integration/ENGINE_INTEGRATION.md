# Engine integration contract

## Pipeline

1. Normalize the engine step to `t in [0,1]` while preserving the physical duration.
2. Build/update body motion records and conservative swept bounds.
3. Enumerate broad-phase pairs. Abort or fallback when capacity is exhausted.
4. Run the narrow phase per pair and collect certificates.
5. Select the earliest conservative activation time.
6. Group certificates whose intervals overlap the earliest event within the engine's
   declared grouping tolerance.
7. Advance dynamics no later than the conservative activation time.
8. Build/validate a response manifold separately and solve dynamics.
9. Continue the remaining substep with a bounded event budget.

## Mandatory status handling

```text
HIT / INITIAL_OVERLAP -> event path
MISS                  -> pair may be discarded for this declared step
INCONCLUSIVE          -> reduce step, invoke stronger backend, or stop safely
RESOURCE_EXHAUSTED    -> expand/rebuild or stop; partial candidates not authoritative
INVALID_INPUT         -> reject scene/body
NUMERICAL_FAILURE     -> stronger backend or fail safe
```

## Units and scaling

Geometry, translation, velocity and acceleration must share a coherent unit system.
Angular velocity is radians per normalized step unless the caller rescales physical
time. Tolerances must be transformed with world scale; fixed default tolerances are
not universal.

## Determinism

Stable body IDs, pair sorting, fixed configuration, binary64 environment and versioned
schemas are required for replay. The trace hash is not portable evidence across
implementations unless canonical floating-point serialization is also frozen.
