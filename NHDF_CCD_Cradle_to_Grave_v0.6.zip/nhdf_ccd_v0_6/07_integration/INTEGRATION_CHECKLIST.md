# Integration checklist

- [ ] Units, coordinate handedness, quaternion convention, and normalized step documented.
- [ ] Convex decomposition ownership defined for non-convex assets.
- [ ] Bounding radius includes local shape offset from motion origin.
- [ ] Broad-phase capacity sized and overflow is observable.
- [ ] Specialized-profile preconditions checked before dispatch.
- [ ] Contact band tied to engine length scale and solver slop.
- [ ] Simultaneous-contact grouping policy specified.
- [ ] `INCONCLUSIVE/RESOURCE_EXHAUSTED/NUMERICAL_FAILURE` activates conservative fallback.
- [ ] Deterministic replay contains input generation and build hash.
- [ ] Dynamics response is tested independently from detection.
- [ ] CPU/GPU equivalence gate is not bypassed.
