# Migration from v0.5 to v0.6

| v0.5 concept | v0.6 change | Migration action |
|---|---|---|
| point/sphere vs triangle feature roots | support-mapped convex pair query | wrap triangle meshes into convex pieces or retain the v0.5 backend for mesh features |
| mostly translational primitives | quadratic translation plus constant angular velocity | declare body origins and conservative radii |
| `NO_HIT` | `MISS` | map spelling at adapter boundary only |
| TOI interval wording | contact-band activation interval | update UI/logs; do not claim exact impact root |
| primitive broad phase | swept-AABB BVH | configure candidate capacity and handle `RESOURCE_EXHAUSTED` |
| CUDA skeleton | fixed-size host/device candidate | still unqualified; do not enable as authoritative backend |
| feature IDs tied to triangle | diagnostic support feature labels | do not rely on labels as persistent manifold keys |

The v0.5 triangle backend remains valuable for non-convex meshes and exact feature
classification. v0.6 does not supersede it in that domain; an engine may dispatch by
geometry profile and compare overlapping support.
