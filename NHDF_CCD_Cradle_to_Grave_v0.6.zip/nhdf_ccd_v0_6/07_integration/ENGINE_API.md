# Engine integration API

## Step pipeline

1. Freeze body transforms and motion coefficients for generation `g`.
2. Build/refit conservative swept bounds for `[0,1]`.
3. Enumerate bounded candidate pairs.
4. Dispatch specialized exact profiles where their preconditions hold.
5. Dispatch rigid-convex conservative advancement otherwise.
6. Group contacts whose upper times fall in the engine simultaneity window.
7. Send authoritative contacts to the dynamics layer; route all unresolved/resource statuses to a safe fallback.
8. Record generation, build hash, statuses, capacities, timings, and certificate digests.

## Caller obligations

- Use one consistent world unit and time normalization.
- Ensure `pose0` is the state at the beginning of the step.
- Do not extrapolate outside `[0,1]` without rebuilding motion bounds.
- Do not use the witness normal as a penetration manifold after overlap.
- Do not reinterpret `HIT` band-entry time as an exact geometric root.
- Do not discard unresolved statuses.
