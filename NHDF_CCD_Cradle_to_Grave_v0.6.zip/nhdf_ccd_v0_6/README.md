# NHDF-CCD v0.6 - Rigid-Convex Motion Foundation

This release continues the cradle-to-grave NHDF-CCD program by moving from the
v0.5 sphere/point-versus-triangle profile to bounded support-mapped convex bodies
under rigid and accelerated translational motion.

The release center is literal computer-graphics and physics-engine Continuous
Collision Detection. It supplies:

- support mappings for spheres, capsules, boxes, triangles and finite convex hulls;
- a bounded GJK distance query with explicit support-plane lower and simplex upper bounds;
- quadratic translation and constant world-angular-velocity trajectories on normalized time `[0,1]`;
- conservative advancement using a relative linear plus angular point-speed bound;
- exact independent linear sphere-sphere and sphere-capsule profiles;
- an analytic orbiting-sphere verification oracle;
- a deterministic swept-AABB BVH with capacity failure rather than silent truncation;
- a NumPy Python reference, an independent C++17 slice, and a fixed-size CUDA source candidate;
- versioned scene and certificate schemas, lifecycle documentation, tests, benchmarks,
  telemetry requirements, migration and retirement rules;
- independently qualified mappings for optical, quantum, chemical, biological,
  medical, SAR, sensing, fabrication and cosmological research hypotheses.

## Reproduce

```bash
cd nhdf_ccd_v0_6
python -m venv .venv
. .venv/bin/activate
pip install -e .[dev]
./scripts/run_all.sh
```

For a report-only rebuild from recorded evidence, run `python scripts/build_release.py`.
For an explicit gate record, run `python scripts/release_validate.py`.

The CUDA wrapper was not compiled or executed in the release environment because
`nvcc` and a CUDA-capable runtime were absent. The shared host/device arithmetic
core is host-compiled as an additional syntax/logic smoke test. No CPU/GPU
numerical-equivalence claim is made.

## Evidence boundary

A `HIT` certificate means conservative entry into the declared contact band. Its
`toi_lower`/`toi_upper` fields bracket that *activation event*, not an exact-real
zero-distance root. `INCONCLUSIVE`, `RESOURCE_EXHAUSTED`, `INVALID_INPUT` and
`NUMERICAL_FAILURE` are first-class results and must not be converted to `MISS`.

The package is a research reference. It is not a production physics engine, a
safety certificate, a medical device, a cryptographic credential, or evidence that
NHDF is the ontological substrate of physical reality.
