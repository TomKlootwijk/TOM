# Security and safety

Treat all CCD results as untrusted until schema validation, status inspection, capacity checks, and application-level replay succeed. Never reinterpret `INCONCLUSIVE`, `RESOURCE_EXHAUSTED`, `INVALID_INPUT`, or `NUMERICAL_FAILURE` as `MISS`.

For safety-relevant systems, use independent sensing, conservative stop behavior, watchdogs, deterministic logs, bounded actuation, human override, and domain certification. Personal names, dates, journey photographs, signs, or civil identifiers are provenance annotations only; they must not be used as cryptographic keys or evidence of algorithmic correctness.
