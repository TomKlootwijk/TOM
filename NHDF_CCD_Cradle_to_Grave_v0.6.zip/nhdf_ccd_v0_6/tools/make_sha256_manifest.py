#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
out=root/'SHA256SUMS.txt'
lines=[]
for p in sorted(root.rglob('*')):
    if p.is_file() and p != out and not any(part in {'.pytest_cache','__pycache__','build','build-release'} for part in p.parts):
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        lines.append(f'{h}  {p.relative_to(root).as_posix()}')
out.write_text('\n'.join(lines)+'\n')
print(f'wrote {out} with {len(lines)} entries')
