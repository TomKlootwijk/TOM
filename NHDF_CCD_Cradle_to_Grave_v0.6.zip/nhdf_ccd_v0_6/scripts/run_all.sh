#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
"$ROOT/scripts/run_python_tests.sh"
"$ROOT/scripts/run_cpp_tests.sh"
"$ROOT/scripts/run_gpu_host_harness.sh"
PYTHONPATH="$ROOT/03_reference/python/src" python "$ROOT/05_benchmarks/run_benchmarks_staged.py" --stage all
python "$ROOT/scripts/validate_schemas.py"
python "$ROOT/scripts/build_release.py"
python "$ROOT/scripts/release_validate.py"
echo "NHDF-CCD v0.6 validation and report build complete."
