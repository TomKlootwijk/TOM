#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/06_gpu/harness/build"
cmake -S "$ROOT/06_gpu/harness" -B "$BUILD" -DCMAKE_BUILD_TYPE=Release
cmake --build "$BUILD" --parallel
ctest --test-dir "$BUILD" --output-on-failure
python "$ROOT/06_gpu/harness/static_contract_check.py"
if command -v nvcc >/dev/null 2>&1; then echo "nvcc detected: device compilation requires an explicit target and is not run automatically"; else echo "nvcc not detected: device validation remains OPEN"; fi
