#!/usr/bin/env python3
"""Build the NHDF-CCD v0.6 report and internal checksum manifest.

The script intentionally consumes recorded benchmark results instead of silently
rerunning them. Run scripts/run_all.sh first when a new evidence run is desired.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORT_DIR = ROOT / "11_report"
SUMMARY = ROOT / "05_benchmarks" / "results" / "benchmark_summary.json"

EXCLUDED_PARTS = {
    ".git",
    ".pytest_cache",
    "__pycache__",
    "build",
    "build-release",
}
EXCLUDED_SUFFIXES = {
    ".aux", ".fdb_latexmk", ".fls", ".log", ".lof", ".lot", ".toc", ".out", ".pyc"
}


def run(command: list[str], *, cwd: Path | None = None) -> None:
    print("+", " ".join(command), flush=True)
    subprocess.run(command, cwd=cwd, check=True)


def tex_number(value: object) -> str:
    if isinstance(value, float):
        return f"{value:.9g}"
    return str(value)


def collected_test_count() -> int:
    env = dict(**__import__("os").environ)
    env["PYTHONPATH"] = str(ROOT / "03_reference" / "python" / "src")
    process = subprocess.run(
        [sys.executable, "-m", "pytest", "--collect-only", "-q", "04_verification/tests"],
        cwd=ROOT,
        env=env,
        text=True,
        capture_output=True,
        check=True,
    )
    match = re.search(r"(\d+) tests? collected", process.stdout + process.stderr)
    if not match:
        raise RuntimeError("could not determine collected pytest count")
    return int(match.group(1))


def generate_metrics() -> None:
    summary = json.loads(SUMMARY.read_text(encoding="utf-8"))
    checks = summary["authoritative_checks"]
    static = checks["static_gjk_vs_analytic_primitives"]
    linear = checks["linear_sphere_vs_analytic"]
    orbit = checks["orbiting_sphere_vs_analytic"]
    bvh = checks["swept_bvh_vs_bruteforce"]
    qp = summary["diagnostic_crosschecks"]["polytope_qp"]
    env = summary["environment"]
    sys.path.insert(0, str(ROOT / "03_reference" / "python" / "src"))
    from nhdf_ccd_v06 import CAConfig
    default_config = CAConfig()

    # Authoritative excludes the diagnostic QP cross-check by definition.
    authoritative_total = static["queries"] + linear["queries"] + orbit["queries"]
    test_count = 0
    for test_file in (ROOT / "04_verification" / "tests").glob("test_*.py"):
        tree = ast.parse(test_file.read_text(encoding="utf-8"))
        test_count += sum(
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test_")
            for node in ast.walk(tree)
        )

    values = {
        "PythonTestCount": test_count,
        "StaticQueries": static["queries"],
        "LinearQueries": linear["queries"],
        "OrbitQueries": orbit["queries"],
        "QPQueries": qp["queries"],
        "TotalNarrowQueries": authoritative_total,
        "TunnelMissed": linear["endpoint_only_missed_hits"],
        "StaticMaxUpperError": f"{static['max_upper_absolute_error']:.8e}",
        "StaticMaxGap": f"{static['max_gjk_bound_gap']:.8e}",
        "LinearMaxLead": f"{linear['max_contact_band_lead']:.8e}",
        "OrbitMaxLead": f"{orbit['max_contact_band_lead']:.8e}",
        "LinearQPS": tex_number(linear["queries_per_second"]),
        "OrbitQPS": tex_number(orbit["queries_per_second"]),
        "StaticQPS": tex_number(static["queries_per_second"]),
        "BVHLargest": bvh["largest_body_count"],
        "BVHSeconds": tex_number(bvh["largest_scale_seconds"]),
        "BVHPairs": bvh["largest_scale_candidate_pairs"],
        "PythonVersion": env["python"],
        "NumPyVersion": env["numpy"],
        "SciPyVersion": env["scipy"],
        "ContactTolerance": f"{default_config.contact_tolerance:.8e}",
        "DistanceErrorBudget": f"{default_config.distance_error_budget:.8e}",
        "GJKAbsoluteTolerance": f"{default_config.gjk_absolute_tolerance:.8e}",
        "GJKRelativeTolerance": f"{default_config.gjk_relative_tolerance:.8e}",
        "TimeTolerance": f"{default_config.time_tolerance:.8e}",
        "ClosureSlack": f"{64.0 * default_config.gjk_absolute_tolerance:.8e}",
    }
    text = "".join(f"\\newcommand{{\\{key}}}{{{value}}}\n" for key, value in values.items())
    (REPORT_DIR / "generated_metrics.tex").write_text(text, encoding="utf-8")


def included_file(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in EXCLUDED_PARTS for part in rel.parts):
        return False
    if path.suffix in EXCLUDED_SUFFIXES:
        return False
    if rel.parts and rel.parts[0] == "04_verification":
        name = rel.name
        if name.startswith("gate_") or name.startswith("RELEASE_VALIDATION_LOG"):
            return False
    if rel.as_posix() in {
        "SHA256SUMS.txt",
        "NHDF_CCD_Cradle_to_Grave_v0.6.pdf",
        "11_report/report.pdf",
        "11_report/release_tree.txt",
    }:
        return False
    return path.is_file()


def generate_release_tree() -> None:
    lines: list[str] = []
    for path in sorted(ROOT.rglob("*")):
        if included_file(path):
            rel = path.relative_to(ROOT).as_posix()
            lines.append(f"{rel}  ({path.stat().st_size} bytes)")
    (REPORT_DIR / "release_tree.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def generate_manifest() -> None:
    manifest = ROOT / "SHA256SUMS.txt"
    rows: list[str] = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or path == manifest:
            continue
        rel = path.relative_to(ROOT)
        if any(part in EXCLUDED_PARTS for part in rel.parts) or path.suffix in EXCLUDED_SUFFIXES:
            continue
        rows.append(f"{sha256(path)}  {rel.as_posix()}")
    manifest.write_text("\n".join(rows) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-latex", action="store_true", help="refresh metadata without invoking latexmk")
    args = parser.parse_args()

    generate_metrics()
    run([sys.executable, str(ROOT / "05_benchmarks" / "make_figures.py")], cwd=ROOT)
    generate_release_tree()

    report_pdf = REPORT_DIR / "report.pdf"
    if not args.skip_latex:
        latexmk = shutil.which("latexmk")
        if not latexmk:
            raise RuntimeError("latexmk is required unless --skip-latex is used")
        run([latexmk, "-pdf", "-interaction=nonstopmode", "-halt-on-error", "report.tex"], cwd=REPORT_DIR)
    if not report_pdf.is_file() or report_pdf.stat().st_size == 0:
        raise FileNotFoundError(report_pdf)

    shutil.copy2(report_pdf, ROOT / "NHDF_CCD_Cradle_to_Grave_v0.6.pdf")
    generate_manifest()
    print("Release report and SHA256SUMS.txt refreshed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
