#!/usr/bin/env python3
"""Execute and record the NHDF-CCD v0.6 release gates."""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "04_verification"
PDF = ROOT / "NHDF_CCD_Cradle_to_Grave_v0.6.pdf"


def execute(name: str, command: list[str], cwd: Path = ROOT, env: dict[str, str] | None = None) -> dict[str, Any]:
    started = time.perf_counter()
    process = subprocess.run(command, cwd=cwd, env=env, text=True, capture_output=True)
    combined = (process.stdout or "") + (process.stderr or "")
    (OUT_DIR / f"gate_{name}.txt").write_text(combined, encoding="utf-8")
    return {
        "name": name,
        "passed": process.returncode == 0,
        "returncode": process.returncode,
        "elapsed_seconds": round(time.perf_counter() - started, 6),
        "command": command,
        "log": f"04_verification/gate_{name}.txt",
        "tail": combined.strip().splitlines()[-8:],
    }


def inspect_pdf() -> dict[str, Any]:
    try:
        import fitz
    except Exception as exc:  # pragma: no cover - environment-dependent
        return {"passed": False, "error": f"PyMuPDF unavailable: {exc}"}
    with fitz.open(PDF) as document:
        count = document.page_count
        sizes = sorted({(round(page.rect.width), round(page.rect.height)) for page in document})
        # Render every page at low resolution to catch malformed page streams.
        for page in document:
            pix = page.get_pixmap(matrix=fitz.Matrix(0.20, 0.20), alpha=False)
            if pix.width <= 0 or pix.height <= 0:
                return {"passed": False, "error": f"empty render at page {page.number + 1}"}
    result: dict[str, Any] = {
        "passed": count > 0,
        "pages": count,
        "page_sizes_points": sizes,
    }
    pdffonts = shutil.which("pdffonts")
    if pdffonts:
        proc = subprocess.run([pdffonts, str(PDF)], text=True, capture_output=True)
        rows = proc.stdout.splitlines()[2:]
        not_embedded = []
        for row in rows:
            fields = row.split()
            # pdffonts type names can contain spaces; the emb/sub/uni triplet is
            # reliably the five fields before the object ID pair.
            if len(fields) >= 7 and fields[-5] != "yes":
                not_embedded.append(row)
        result["non_embedded_fonts"] = len(not_embedded)
        result["passed"] = result["passed"] and not not_embedded
    return result


def benchmark_gate() -> dict[str, Any]:
    path = ROOT / "05_benchmarks" / "results" / "benchmark_summary.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    a = data["authoritative_checks"]
    decisive = {
        "static_lower_bound_violations": a["static_gjk_vs_analytic_primitives"]["lower_bound_violations_over_tolerance"],
        "static_upper_bound_violations": a["static_gjk_vs_analytic_primitives"]["upper_bound_violations_over_tolerance"],
        "static_overlap_disagreements": a["static_gjk_vs_analytic_primitives"]["overlap_classification_disagreements"],
        "linear_false_negatives": a["linear_sphere_vs_analytic"]["false_negatives"],
        "linear_false_positives": a["linear_sphere_vs_analytic"]["false_positives"],
        "linear_unresolved": a["linear_sphere_vs_analytic"]["unresolved"],
        "orbit_false_negatives": a["orbiting_sphere_vs_analytic"]["false_negatives"],
        "orbit_false_positives": a["orbiting_sphere_vs_analytic"]["false_positives"],
        "orbit_unresolved": a["orbiting_sphere_vs_analytic"]["unresolved"],
        "bvh_pair_disagreements": a["swept_bvh_vs_bruteforce"]["pair_set_disagreements"],
    }
    return {
        "passed": not any(decisive.values()),
        "decisive_failures": decisive,
        "static_queries": a["static_gjk_vs_analytic_primitives"]["queries"],
        "linear_queries": a["linear_sphere_vs_analytic"]["queries"],
        "orbit_queries": a["orbiting_sphere_vs_analytic"]["queries"],
        "diagnostic_qp_queries": data["diagnostic_crosschecks"]["polytope_qp"]["queries"],
        "endpoint_only_missed_hits": a["linear_sphere_vs_analytic"]["endpoint_only_missed_hits"],
        "largest_bvh_body_count": a["swept_bvh_vs_bruteforce"]["largest_body_count"],
        "max_static_upper_absolute_error": a["static_gjk_vs_analytic_primitives"]["max_upper_absolute_error"],
        "max_linear_contact_band_lead": a["linear_sphere_vs_analytic"]["max_contact_band_lead"],
        "max_orbit_contact_band_lead": a["orbiting_sphere_vs_analytic"]["max_contact_band_lead"],
        "seed": data["seed_hex"],
        "environment": data["environment"],
    }


def python_test_count(record: dict[str, Any]) -> int | None:
    for gate in record.get("gates", []):
        if gate.get("name") == "python":
            for line in reversed(gate.get("tail", [])):
                parts = line.split()
                if len(parts) >= 2 and parts[0].isdigit() and parts[1] == "passed":
                    return int(parts[0])
    return None


def passed_pytest_count(gates: list[dict[str, Any]]) -> int | None:
    gate = next((item for item in gates if item.get("name") == "python"), None)
    if gate is None:
        return None
    log_path = ROOT / gate["log"]
    text = log_path.read_text(encoding="utf-8") if log_path.exists() else "\n".join(gate.get("tail", []))
    match = re.search(r"(\d+) passed", text)
    return int(match.group(1)) if match else None


def write_markdown(record: dict[str, Any]) -> None:
    bench = record["benchmark"]
    pdf = record["pdf"]
    gate_map = {gate["name"]: gate for gate in record.get("gates", [])}
    def gate_status(name: str) -> str:
        gate = gate_map.get(name)
        return "NOT RERUN" if gate is None else ("PASS" if gate["passed"] else "FAIL")
    lines = [
        "# NHDF-CCD v0.6 release-validation log",
        "",
        f"- Generated: `{record['generated_utc']}`",
        f"- Overall result: **{'PASS' if record['passed'] else 'FAIL'}**",
        f"- PDF: {pdf.get('pages', '?')} A4 pages; {pdf.get('non_embedded_fonts', '?')} non-embedded fonts; all pages low-resolution render-smoked.",
        f"- Python: {python_test_count(record) if python_test_count(record) is not None else 'recorded'} test methods; gate {gate_status('python')}.",
        f"- C++17 smoke: {gate_status('cpp')}.",
        f"- Host-compiled CUDA arithmetic/layout profile: {gate_status('gpu_host')}.",
        f"- CUDA static source contract: {gate_status('gpu_static')}.",
        f"- JSON schemas/examples: {gate_status('schemas')}.",
        f"- Benchmark decisive checks: {'PASS' if bench['passed'] else 'FAIL'}.",
        "",
        "## Recorded corpus",
        "",
        f"- {bench['static_queries']} static GJK queries against analytic primitive distances.",
        f"- {bench['linear_queries']} linear sphere-sphere CCD queries against analytic roots.",
        f"- {bench['orbit_queries']} rotating/orbiting sphere CCD queries against an analytic trigonometric oracle.",
        f"- {bench['diagnostic_qp_queries']} diagnostic convex-QP cross-checks.",
        f"- Swept-BVH scenes up to {bench['largest_bvh_body_count']} bodies.",
        f"- {bench['endpoint_only_missed_hits']} collisions missed by endpoint-only checks and recovered by CCD.",
        "- Zero recorded false negatives, false positives, GJK bound violations over tolerance, unresolved analytic cases, and checked BVH pair-set disagreements.",
        "",
        "## Open gate",
        "",
        f"- CUDA device compilation/execution: **{'available' if record['nvcc_detected'] else 'OPEN - nvcc/GPU unavailable in this build environment'}**.",
        "- The observations above concern the seeded binary64 corpus and do not prove all inputs or certify production/safety use.",
    ]
    (OUT_DIR / "RELEASE_VALIDATION_LOG.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-execute", action="store_true", help="inspect existing evidence without rerunning test gates")
    args = parser.parse_args()
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT / "03_reference" / "python" / "src")
    if args.no_execute:
        gates = []
    else:
        gates = [
            execute("python", [sys.executable, "-m", "pytest", "-q", "04_verification/tests"], env=env),
            execute("cpp", [str(ROOT / "scripts" / "run_cpp_tests.sh")]),
            execute("gpu_host", [str(ROOT / "scripts" / "run_gpu_host_harness.sh")]),
            execute("schemas", [sys.executable, "scripts/validate_schemas.py"]),
            execute("gpu_static", [sys.executable, "06_gpu/harness/static_contract_check.py"]),
        ]

    record: dict[str, Any] = {
        "schema_version": "nhdf-ccd-release-validation-0.6.0",
        "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "release": "0.6.0",
        "gates": gates,
        "python_test_count": passed_pytest_count(gates),
        "benchmark": benchmark_gate(),
        "pdf": inspect_pdf(),
        "nvcc_detected": shutil.which("nvcc") is not None,
    }
    record["passed"] = (
        all(gate["passed"] for gate in gates)
        and record["benchmark"]["passed"]
        and record["pdf"]["passed"]
    )
    (OUT_DIR / "RELEASE_VALIDATION_LOG.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    write_markdown(record)
    print(json.dumps({"passed": record["passed"], "gates": {g["name"]: g["passed"] for g in gates}, "pages": record["pdf"].get("pages")}, indent=2))
    return 0 if record["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
