#!/usr/bin/env python3
from pathlib import Path
import json, sys
from jsonschema import Draft202012Validator
ROOT=Path(__file__).resolve().parents[1]
S=ROOT/'02_formal_specification'/'schemas'
for p in S.glob('*.json'):
    Draft202012Validator.check_schema(json.loads(p.read_text()))
# Scene example
scene_schema=json.loads((S/'scene.schema.json').read_text())
scene=json.loads((ROOT/'03_reference/python/examples/rotating_capsule_box.json').read_text())
Draft202012Validator(scene_schema).validate(scene)
# Generate and validate one certificate.
sys.path.insert(0,str(ROOT/'03_reference/python/src'))
from nhdf_ccd_v06.io import load_scene
from nhdf_ccd_v06 import conservative_advancement
a,b=load_scene(ROOT/'03_reference/python/examples/rotating_capsule_box.json')
cert=conservative_advancement(a,b).to_dict()
Draft202012Validator(json.loads((S/'certificate.schema.json').read_text())).validate(cert)
Draft202012Validator(json.loads((S/'telemetry.schema.json').read_text())).validate(json.loads((ROOT/'08_operations/telemetry_example.json').read_text()))
adapter_schema=json.loads((S/'adapter.schema.json').read_text())
for p in (ROOT/'10_domain_adapters/records').glob('*.json'):
    Draft202012Validator(adapter_schema).validate(json.loads(p.read_text()))
print('JSON schemas and examples: PASS')
