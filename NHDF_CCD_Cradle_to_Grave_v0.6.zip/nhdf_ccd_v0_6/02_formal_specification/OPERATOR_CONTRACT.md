# NHDF-to-CCD operator contract

The v0.1 operator chain is preserved as a state-threaded architecture rather than
as a sequence of interchangeable values:

`Sigma[n+1] = U o Pi o S_sweep o K_T o R_bound o P_diag o B_contact o A_support o E_scene (Sigma[n])`

| Operator | v0.6 CCD meaning | Correctness role |
|---|---|---|
| `E_scene` | parse units, body IDs, shape and motion records | required input validity |
| `A_support` | support map and Minkowski-difference query | geometric primitive |
| `B_contact` | local separation/contact-band constraint | defines admissible contact event |
| `P_diag` | parity/status/telemetry reduction | diagnostic only; cannot certify collision |
| `R_bound` | GJK simplex reduction, BVH traversal and bounded refinement | required bounded search |
| `K_T` | continuous rigid trajectory over monotonic normalized time | required motion model |
| `S_sweep` | conservative motion envelope/point-speed bound | required no-skip mechanism |
| `Pi` | contact certificate with status, interval, witnesses and trace | observable output |
| `U` | engine consumes certificate, advances to event or escalates failure | integration feedback |

Log-polar coordinates may schedule queries or compress telemetry. Golden-ratio
splits may be evaluated as a refinement ablation. Neither is on the v0.6 safety path.
The Klein-bottle concept remains a possible chart-transition adapter, not a Euclidean
collision primitive.
