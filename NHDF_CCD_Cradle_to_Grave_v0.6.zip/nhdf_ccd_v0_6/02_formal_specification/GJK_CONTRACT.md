# Support-mapping and GJK contract

For a compact convex body `A`, the support mapping is

`support_A(d) = argmax_{a in A} dot(a,d)`.

The Minkowski-difference support used by the reference is

`support_{A-B}(d) = support_A(d) - support_B(-d)`.

At an iteration, the active simplex gives a point `q` closest to the origin. Its norm is an **upper bound** on separation. A support plane in direction `-q` supplies a lower bound. The implementation terminates when their gap is below

`tau_abs + tau_rel * upper`.

The result includes both bounds, closest witnesses, a normal, feature labels, iteration/support counts, convergence/intersection flags, and a termination code. Duplicate support or stalling is not silently called convergence unless the remaining bound gap fits a stated finite-precision envelope.

## Assumptions
- Shapes are nonempty, finite, convex support objects.
- Poses are finite and quaternions normalize successfully.
- Support functions are deterministic for tied extrema.
- Binary64 arithmetic and the declared tolerances define the reference semantics.

## Deliberate non-claims
- The lower/upper pair is not an exact-arithmetic proof for every degenerate input.
- GJK alone does not produce a penetration manifold.
- A distance upper bound is not automatically a safe advancement distance; the step uses the lower bound minus error budgets.
