# State machine

1. `PARSE`: validate shape, pose, motion and configuration.
2. `SAMPLE_0`: run GJK at `t=0`.
3. `INITIAL`: return `INITIAL_OVERLAP` when the contact band is already active.
4. `BOUND`: compute remaining-interval point-speed bound.
5. `MISS_CERT`: return `MISS` if the support-plane lower bound cannot close before `t=1`.
6. `ADVANCE`: take only the conservative step permitted by the lower bound.
7. `RESAMPLE`: run GJK at the new time.
8. `REFINE`: bisection-refine a detected contact-band transition.
9. `HIT`: return witnesses and activation bracket.
10. `FAIL_CLOSED`: preserve numerical, iteration, input or capacity failure.

Every transition carries a monotonic time value. No state may read a later sample to
justify an earlier safe interval without recording that refinement explicitly.
