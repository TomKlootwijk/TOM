# Rigid-convex CCD specification

## 1. Support mappings and Minkowski difference

For a compact convex body `A`, the support mapping is

`S_A(d) = argmax_(a in A) d . a`.

The Minkowski difference `C(t) = A(t) - B(t)` has support

`S_C(d,t) = S_A(d,t) - S_B(-d,t)`.

Contact occurs when the origin belongs to `C(t)`. For a current simplex point `q`
that is a convex combination of support points, `||q||` is a feasible upper bound
on separation. With unit direction `u=q/||q||`, the supporting plane obtained by
minimizing `u.x` over `C` supplies

`d_lower = max(0, min_(x in C) u.x)`.

The query is converged when `d_upper-d_lower` lies inside the declared absolute and
relative tolerance. Duplicate supports and iteration limits preserve explicit
non-convergence when the bound gap is too large.

## 2. Motion

Translation is

`p(t) = p0 + v0 t + 0.5 a t^2`.

Orientation is represented by a normalized quaternion

`q(t) = Exp(0.5 t omega) q0`,

where `omega` is constant in world coordinates for the step. This is a declared
interpolation profile, not a claim that dynamics produce constant angular velocity.

## 3. Conservative speed bound

For the interval `[t0,t1]`, relative origin velocity is affine. A conservative
linear bound is

`V_lin = ||v_A(t0)-v_B(t0)|| + ||a_A-a_B|| (t1-t0)`.

If each shape lies inside a sphere of radius `R` about its body origin, a point-pair
speed bound is

`V = V_lin + ||omega_A|| R_A + ||omega_B|| R_B`.

This may be loose, but it bounds the rate at which separation can close under the
declared profile.

## 4. Conservative advancement

Let `tau` be contact tolerance and `eps_d` the accepted distance-bound uncertainty.
At time `t`, safe progress is

`Delta t = eta (d_lower - tau - eps_d) / V`, with `0 < eta <= 1`.

No positive minimum step may be forced. If safe progress falls below the configured
representable threshold while the upper bound is outside the numerical contact band,
the result is `INCONCLUSIVE`.

A remaining-interval miss can be certified when

`d_lower - eps_d - V(1-t) - tau > 0`.

## 5. Time semantics

The query stops conservatively when the upper separation bound enters
`tau + eps_d`. Therefore the reported interval brackets entry into the declared
contact band. It generally precedes the exact zero-distance root and is suitable as
an early activation time for an engine. It is not an exact-real TOI bracket.

## 6. Broad phase

Every body is enclosed by a swept AABB formed from exact coordinate extrema of its
quadratic origin path and its bounding radius. The deterministic BVH may return
false candidate pairs but must not omit a pair whose swept AABBs overlap. Candidate
capacity exhaustion invalidates the partial list as an authoritative result.

## 7. Status lattice

Definitive: `HIT`, `INITIAL_OVERLAP`, `MISS`.

Non-definitive: `INCONCLUSIVE`, `RESOURCE_EXHAUSTED`, `INVALID_INPUT`,
`NUMERICAL_FAILURE`.

No non-definitive state may be downcast to `MISS`.
