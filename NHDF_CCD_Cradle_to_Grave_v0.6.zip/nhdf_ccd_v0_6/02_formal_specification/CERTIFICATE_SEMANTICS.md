# Certificate semantics

The JSON certificate is an evidence record, not a response impulse.

- `status`: definitive or fail-closed state.
- `toi_lower`, `toi_upper`: bracket for conservative entry into the declared
  contact band; null for `MISS` and some failures.
- `contact_tolerance`, `distance_error_budget`: numerical band definition.
- `distance_at_upper`: GJK simplex upper separation at the returned activation
  sample.
- `witness_a`, `witness_b`: convex combinations of support witnesses.
- `normal_a_to_b`: normalized witness separation; at overlap it may be a fallback
  direction and must not be treated as a penetration normal.
- `feature_a`, `feature_b`: diagnostic support-feature labels, not a stable engine
  feature ID contract.
- `conservative_speed_bound`: global point-pair closure bound used by the query.
- `ca_iterations`, `gjk_iterations_total`: work accounting.
- `termination`: exact exit path.
- `trace_sha256`: deterministic digest of the stored trace; it detects accidental
  record changes but is not a digital signature.
- `warnings`: explicit semantic cautions.

An integration layer must validate schema version and profile before consuming the
record. Contact response must recompute or validate its own manifold, effective mass,
restitution, friction and simultaneous-contact set.
