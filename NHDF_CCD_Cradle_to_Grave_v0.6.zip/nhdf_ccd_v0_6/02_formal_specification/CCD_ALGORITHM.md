# Rigid-convex conservative advancement

Let `d(t)` be Euclidean separation. For body `i`, the reference motion is

`x_i(t) = x_i0 + v_i0 t + 0.5 a_i t^2`,

`R_i(t) = Exp([omega_i]x t) R_i0`.

For any point no farther than `r_i` from the motion origin, a conservative speed bound on `[t,1]` is

`V_i <= ||v_i(t)|| + ||a_i|| (1-t) + ||omega_i|| r_i`.

The pairwise Lipschitz bound is `V = V_A + V_B`, giving

`d(t + h) >= d(t) - V h`.

With GJK lower bound `d_lo`, contact tolerance `tau_c`, and distance error budget `eps_d`, the safe step is

`h = eta * max(0, d_lo - tau_c - eps_d) / V`, with `0 < eta <= 1`.

A remaining-interval miss can be certified when

`d_lo - eps_d - V(1-t) - tau_c > 0`.

The algorithm never substitutes a larger unsafe minimum step. When representable progress falls below `min_safe_step` outside the accepted numerical band, it returns `INCONCLUSIVE`.

## Contact-band semantics

The general profile defines contact as `distance <= tau_c + eps_d` or a GJK intersection result. Therefore the reported time can lead the exact geometric root by approximately the band width divided by closing speed. `toi_lower` and `toi_upper` bracket the detected band transition, not necessarily the exact zero-distance event.

## Refinement

Once a sampled upper time satisfies the contact predicate, midpoint refinement preserves a separated lower sample and contact-band upper sample until the time tolerance or iteration budget is reached. If a refinement GJK call is not usable, the existing conservative bracket is retained rather than extrapolated.
