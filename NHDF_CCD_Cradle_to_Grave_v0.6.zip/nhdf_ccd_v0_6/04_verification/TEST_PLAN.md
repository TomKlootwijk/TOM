# NHDF-CCD v0.6 verification plan

The release gate is fail-closed. A test passes only when every authoritative result remains inside the declared profile and every exhausted numerical/resource path preserves a non-authoritative status.

## Layers

1. Math and support mappings: quaternion normalization, world transforms, support extrema, bounding radii.
2. Static narrow phase: GJK distance, lower/upper bounds, symmetry, degeneracy, trace termination.
3. Specialized oracles: analytic translational sphere-sphere and sphere-capsule roots.
4. Continuous narrow phase: classification and contact-band interval against exact roots; rotational orbit and accelerated translation cases.
5. Broad phase: swept-AABB BVH equality against all-pairs enumeration and capacity truncation.
6. Contracts: JSON Schema validation, deterministic serialization and trace digests.
7. Randomized differential tests: fixed seeds, recorded counts, no hidden retry loop.
8. Cross-language smoke: separately compiled C++17 cases must agree on status and a declared tolerance.
9. Release package: checksums, ZIP CRC, clean extraction, PDF preflight and render inspection.

The benchmark corpus is evidence about this implementation and seed distribution, not a proof over all binary64 inputs.
