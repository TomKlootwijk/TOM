# Oracle independence notes

- The static polytope oracle minimizes a barycentric convex quadratic objective with SciPy SLSQP. It does not use support mappings or the runtime GJK simplex update.
- Linear sphere-sphere and sphere-capsule profiles solve their own quadratic/cylinder/cap equations.
- The orbit oracle solves a trigonometric circle-intersection relation for an offset sphere under z-axis rotation.
- Broad-phase brute force evaluates every pair of already-conservative swept AABBs.

These formulations reduce common-mode algorithm risk, but they still share binary64 arithmetic, constructors, and generated input data. Independent implementations and exact predicates remain future work.
