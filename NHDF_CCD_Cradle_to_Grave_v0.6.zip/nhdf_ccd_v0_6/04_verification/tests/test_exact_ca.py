import math
import numpy as np
import pytest

from nhdf_ccd_v06 import (
    CAConfig, CCDStatus, Capsule, MovingConvex, Pose, RigidMotion, Sphere,
    conservative_advancement, quat_identity, sphere_capsule_linear, sphere_sphere_linear,
)


def motion_at(p, v=(0,0,0), a=(0,0,0), w=(0,0,0)):
    return RigidMotion(Pose(np.asarray(p, dtype=float), quat_identity()), np.asarray(v, dtype=float), np.asarray(a, dtype=float), np.asarray(w, dtype=float))


def test_exact_sphere_sphere_hit():
    result = sphere_sphere_linear(np.array([-5.,0,0]), np.array([10.,0,0]), 1, np.zeros(3), np.zeros(3), 1)
    assert result.hit and result.time == pytest.approx(0.3)


def test_exact_sphere_sphere_miss():
    result = sphere_sphere_linear(np.array([-5.,3,0]), np.array([10.,0,0]), 1, np.zeros(3), np.zeros(3), 1)
    assert not result.hit


def test_exact_sphere_capsule_cylinder_hit():
    result = sphere_capsule_linear(np.array([0.,-3,0]), np.array([0.,6,0]), .25,
                                   np.array([-1.,0,0]), np.array([1.,0,0]), np.zeros(3), .25)
    assert result.hit and result.time == pytest.approx(2.5/6.0, abs=1e-12)
    assert result.feature_b == "cylinder"


def test_ca_matches_linear_sphere_sphere_contact_band():
    a = MovingConvex(Sphere(1), motion_at([-5,0,0], [10,0,0]), "a")
    b = MovingConvex(Sphere(1), motion_at([0,0,0]), "b")
    cert = conservative_advancement(a, b)
    assert cert.status == CCDStatus.HIT
    assert cert.toi_upper is not None
    assert abs(cert.toi_upper - 0.3) <= 2e-7
    assert cert.toi_lower <= cert.toi_upper


def test_ca_miss():
    a = MovingConvex(Sphere(1), motion_at([-5,4,0], [10,0,0]), "a")
    b = MovingConvex(Sphere(1), motion_at([0,0,0]), "b")
    cert = conservative_advancement(a, b)
    assert cert.status == CCDStatus.MISS


def test_ca_initial_overlap():
    a = MovingConvex(Sphere(1), motion_at([0,0,0]), "a")
    b = MovingConvex(Sphere(1), motion_at([1,0,0]), "b")
    cert = conservative_advancement(a, b)
    assert cert.status == CCDStatus.INITIAL_OVERLAP
    assert cert.toi_upper == 0.0


def test_ca_sphere_capsule_matches_exact():
    a = MovingConvex(Sphere(.25), motion_at([0,-3,0], [0,6,0]), "sphere")
    b = MovingConvex(Capsule(np.array([-1.,0,0]), np.array([1.,0,0]), .25), motion_at([0,0,0]), "capsule")
    exact = sphere_capsule_linear(np.array([0.,-3,0]), np.array([0.,6,0]), .25,
                                  np.array([-1.,0,0]), np.array([1.,0,0]), np.zeros(3), .25)
    cert = conservative_advancement(a, b)
    assert exact.hit and cert.status == CCDStatus.HIT
    assert abs(cert.toi_upper - exact.time) <= 3e-7


def test_ca_trace_digest_is_deterministic():
    a = MovingConvex(Sphere(.5), motion_at([-2,0,0], [4,0,0]), "a")
    b = MovingConvex(Sphere(.5), motion_at([0,0,0]), "b")
    x = conservative_advancement(a, b)
    y = conservative_advancement(a, b)
    assert x.trace_sha256 == y.trace_sha256
    assert x.to_dict() == y.to_dict()


def test_ca_no_unsafe_minimum_step():
    config = CAConfig(max_iterations=1)
    a = MovingConvex(Sphere(.5), motion_at([-10,0,0], [20,0,0]), "a")
    b = MovingConvex(Sphere(.5), motion_at([0,0,0]), "b")
    cert = conservative_advancement(a, b, config)
    assert cert.status == CCDStatus.INCONCLUSIVE
    assert "iteration_limit" in cert.termination
