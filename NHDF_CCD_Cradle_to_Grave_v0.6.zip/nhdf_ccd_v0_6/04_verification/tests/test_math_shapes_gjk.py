import math

import numpy as np

from nhdf_ccd_v06 import Box, Capsule, ConvexHull, Pose, Sphere, Triangle, gjk_distance, quat_from_rotation_vector, quat_identity


def test_quaternion_rotation_about_z():
    pose = Pose(np.zeros(3), quat_from_rotation_vector(np.array([0.0, 0.0, math.pi / 2.0])))
    point = pose.transform_point(np.array([1.0, 0.0, 0.0]))
    assert np.allclose(point, [0.0, 1.0, 0.0], atol=1e-12)


def test_sphere_sphere_distance_and_witnesses():
    result = gjk_distance(Sphere(1.0), Pose.identity(), Sphere(0.5), Pose(np.array([3.0, 0.0, 0.0]), quat_identity()))
    assert result.converged
    assert abs(result.distance - 1.5) < 1e-12
    assert result.lower_bound <= 1.5 <= result.upper_bound
    assert np.allclose(result.closest_a, [1.0, 0.0, 0.0], atol=1e-12)
    assert np.allclose(result.closest_b, [2.5, 0.0, 0.0], atol=1e-12)


def test_overlap_is_reported():
    result = gjk_distance(Sphere(1.0), Pose.identity(), Sphere(1.0), Pose(np.array([1.0, 0.0, 0.0]), quat_identity()))
    assert result.intersect
    assert result.upper_bound <= 1e-10


def test_box_box_axis_separation():
    result = gjk_distance(Box(np.ones(3)), Pose.identity(), Box(np.full(3, 0.5)), Pose(np.array([3.0, 0.0, 0.0]), quat_identity()))
    assert result.converged
    assert abs(result.distance - 1.5) < 1e-10


def test_capsule_sphere_distance():
    capsule = Capsule(np.array([-1.0, 0.0, 0.0]), np.array([1.0, 0.0, 0.0]), 0.2)
    result = gjk_distance(capsule, Pose.identity(), Sphere(0.4), Pose(np.array([0.0, 2.0, 0.0]), quat_identity()))
    assert result.converged
    assert abs(result.distance - 1.4) < 1e-8


def test_triangle_sphere_distance():
    triangle = Triangle(np.array([-1.0, 0.0, 0.0]), np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0]))
    result = gjk_distance(triangle, Pose.identity(), Sphere(0.2), Pose(np.array([0.0, 0.0, 1.0]), quat_identity()))
    assert result.converged
    assert abs(result.distance - 0.8) < 1e-7


def test_convex_hull_support_path():
    tetra = ConvexHull(np.array([[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]))
    result = gjk_distance(tetra, Pose.identity(), Sphere(0.1), Pose(np.array([2.0, 0.0, 0.0]), quat_identity()))
    assert result.converged
    assert 0.899999 < result.distance < 0.900001
