import math
import numpy as np
import pytest

from nhdf_ccd_v06 import CAConfig, CCDStatus, MovingConvex, Pose, RigidMotion, Sphere, conservative_advancement, quat_identity
from nhdf_ccd_v06.oracles import orbiting_sphere_fixed_sphere_toi


def test_rotating_offset_sphere_matches_analytic_orbit():
    omega = math.pi / 2
    moving = MovingConvex(
        Sphere(.1, np.array([1.,0,0])),
        RigidMotion(Pose.identity(), angular_velocity=np.array([0.,0.,omega])),
        "orbit",
    )
    fixed = MovingConvex(Sphere(.1), RigidMotion(Pose(np.array([0.,1.,0]), quat_identity())), "fixed")
    oracle = orbiting_sphere_fixed_sphere_toi(np.array([1.,0,0]), np.zeros(3), omega, .1, np.array([0.,1,0]), .1)
    cert = conservative_advancement(moving, fixed)
    assert oracle is not None and cert.status == CCDStatus.HIT
    assert abs(cert.toi_upper - oracle) < 2e-6


def test_rotational_tunnelling_not_seen_at_endpoints():
    omega = math.pi
    moving = MovingConvex(Sphere(.08, np.array([1.,0,0])), RigidMotion(Pose.identity(), angular_velocity=np.array([0.,0.,omega])), "orbit")
    fixed = MovingConvex(Sphere(.08), RigidMotion(Pose(np.array([0.,1.,0]), quat_identity())), "fixed")
    d0 = np.linalg.norm(np.array([1.,0,0]) - np.array([0.,1,0]))
    d1 = np.linalg.norm(np.array([-1.,0,0]) - np.array([0.,1,0]))
    assert d0 > .16 and d1 > .16
    cert = conservative_advancement(moving, fixed)
    assert cert.status == CCDStatus.HIT


def test_quadratic_translation_hit():
    moving = MovingConvex(Sphere(.5), RigidMotion(Pose(np.array([-3.,0,0]), quat_identity()), linear_acceleration=np.array([8.,0,0])), "accelerating")
    fixed = MovingConvex(Sphere(.5), RigidMotion(Pose(np.zeros(3), quat_identity())), "fixed")
    # center: -3 + 4 t^2; contact at center=-1 -> t=sqrt(0.5)
    cert = conservative_advancement(moving, fixed)
    assert cert.status == CCDStatus.HIT
    assert cert.toi_upper == pytest.approx(math.sqrt(.5), abs=3e-6)


def test_rotation_speed_bound_increases_certificate_bound():
    slow = MovingConvex(Sphere(.1, np.array([2.,0,0])), RigidMotion(Pose.identity(), angular_velocity=np.array([0,0,.5])), "slow")
    fast = MovingConvex(Sphere(.1, np.array([2.,0,0])), RigidMotion(Pose.identity(), angular_velocity=np.array([0,0,2.])), "fast")
    fixed = MovingConvex(Sphere(.1), RigidMotion(Pose(np.array([0.,2,0]), quat_identity())), "fixed")
    cs = conservative_advancement(slow, fixed)
    cf = conservative_advancement(fast, fixed)
    assert cf.conservative_speed_bound > cs.conservative_speed_bound


def test_contact_band_semantics_are_explicit():
    moving = MovingConvex(Sphere(.5), RigidMotion(Pose(np.array([-2.,0,0]), quat_identity()), linear_velocity=np.array([3.,0,0])), "a")
    fixed = MovingConvex(Sphere(.5), RigidMotion(Pose.identity()), "b")
    cert = conservative_advancement(moving, fixed, CAConfig(contact_tolerance=1e-6))
    assert "contact band" in cert.time_semantics
