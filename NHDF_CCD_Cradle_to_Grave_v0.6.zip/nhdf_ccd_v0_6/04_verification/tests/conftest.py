from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "03_reference" / "python" / "src"
sys.path.insert(0, str(SRC))
