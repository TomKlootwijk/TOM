import numpy as np
import pytest

from nhdf_ccd_v06 import CCDStatus, MovingConvex, Pose, RigidMotion, Sphere, conservative_advancement, gjk_distance, quat_identity, sphere_sphere_linear


def test_seeded_random_sphere_gjk_exact_distances():
    rng = np.random.default_rng(61001)
    for _ in range(250):
        ca = rng.uniform(-5,5,3); cb = rng.uniform(-5,5,3)
        ra = rng.uniform(0,1.5); rb = rng.uniform(0,1.5)
        result = gjk_distance(Sphere(ra), Pose(ca,quat_identity()), Sphere(rb), Pose(cb,quat_identity()))
        exact = max(0.0, float(np.linalg.norm(cb-ca))-ra-rb)
        assert result.distance == pytest.approx(exact, abs=2e-10)


def test_seeded_random_linear_ca_has_no_classification_disagreement():
    rng = np.random.default_rng(61002)
    for i in range(200):
        ca = rng.uniform(-4,4,3); cb = rng.uniform(-4,4,3)
        va = rng.uniform(-6,6,3); vb = rng.uniform(-6,6,3)
        ra = rng.uniform(.05,.8); rb = rng.uniform(.05,.8)
        exact = sphere_sphere_linear(ca,va,ra,cb,vb,rb)
        a = MovingConvex(Sphere(ra), RigidMotion(Pose(ca,quat_identity()),linear_velocity=va),f"a{i}")
        b = MovingConvex(Sphere(rb), RigidMotion(Pose(cb,quat_identity()),linear_velocity=vb),f"b{i}")
        cert = conservative_advancement(a,b)
        observed_hit = cert.status in {CCDStatus.HIT,CCDStatus.INITIAL_OVERLAP}
        assert observed_hit == exact.hit
        if exact.hit and exact.time is not None and cert.toi_upper is not None:
            assert abs(cert.toi_upper-exact.time) <= 4e-6
