import json
from pathlib import Path
import subprocess
import sys

import numpy as np
import pytest
from jsonschema import Draft202012Validator

from nhdf_ccd_v06 import (
    AABB,
    CAConfig,
    MovingConvex,
    Pose,
    RigidMotion,
    Sphere,
    conservative_advancement,
    pair_speed_bound,
    quat_identity,
)
from nhdf_ccd_v06.io import load_scene


ROOT = Path(__file__).resolve().parents[2]
EXAMPLE = ROOT / "03_reference" / "python" / "examples" / "rotating_capsule_box.json"


def fixed_sphere(body_id: str, x: float = 0.0) -> MovingConvex:
    return MovingConvex(
        Sphere(0.5),
        RigidMotion(Pose(np.array([x, 0.0, 0.0]), quat_identity())),
        body_id,
    )


def test_certificate_schema_accepts_full_and_trace_free_output():
    schema = json.loads((ROOT / "02_formal_specification" / "certificate.schema.json").read_text())
    validator = Draft202012Validator(schema)
    a = MovingConvex(
        Sphere(0.5),
        RigidMotion(Pose(np.array([-2.0, 0.0, 0.0]), quat_identity()), np.array([4.0, 0.0, 0.0])),
        "moving",
    )
    cert = conservative_advancement(a, fixed_sphere("fixed"))
    validator.validate(cert.to_dict(include_trace=True))
    validator.validate(cert.to_dict(include_trace=False))


def test_scene_schema_accepts_bundled_example():
    schema = json.loads((ROOT / "02_formal_specification" / "scene.schema.json").read_text())
    scene = json.loads(EXAMPLE.read_text())
    Draft202012Validator(schema).validate(scene)


def test_certificate_records_non_default_numeric_contract():
    cfg = CAConfig(contact_tolerance=2.5e-6, distance_error_budget=7.5e-8)
    a = MovingConvex(
        Sphere(0.5),
        RigidMotion(Pose(np.array([-2.0, 0.0, 0.0]), quat_identity()), np.array([4.0, 0.0, 0.0])),
        "moving",
    )
    cert = conservative_advancement(a, fixed_sphere("fixed"), cfg)
    assert cert.contact_tolerance == cfg.contact_tolerance
    assert cert.distance_error_budget == cfg.distance_error_budget
    assert "contact band" in cert.time_semantics


def test_relative_speed_bound_cancels_shared_translation():
    motion = RigidMotion(Pose.identity(), np.array([100.0, -50.0, 25.0]))
    a = MovingConvex(Sphere(1.0), motion, "a")
    b = MovingConvex(Sphere(1.0), motion, "b")
    assert pair_speed_bound(a, b, 0.0, 1.0) == pytest.approx(0.0, abs=1e-15)


def test_pair_speed_bound_includes_relative_acceleration_and_rotation():
    a = MovingConvex(
        Sphere(2.0),
        RigidMotion(Pose.identity(), linear_acceleration=np.array([3.0, 4.0, 0.0]), angular_velocity=np.array([0.0, 0.0, 2.0])),
        "a",
    )
    b = fixed_sphere("b")
    assert pair_speed_bound(a, b, 0.0, 1.0) == pytest.approx(5.0 + 4.0)


def test_quadratic_swept_aabb_includes_interior_extremum():
    body = MovingConvex(
        Sphere(0.25),
        RigidMotion(
            Pose(np.zeros(3), quat_identity()),
            linear_velocity=np.array([2.0, 0.0, 0.0]),
            linear_acceleration=np.array([-4.0, 0.0, 0.0]),
        ),
        "turning",
    )
    lower, upper = body.swept_aabb()
    # Translation reaches x=0.5 at t=0.5, then returns to x=0 at t=1.
    assert lower[0] == pytest.approx(-0.25)
    assert upper[0] == pytest.approx(0.75)


def test_aabb_rejects_reversed_bounds():
    with pytest.raises(ValueError):
        AABB(np.ones(3), np.zeros(3))


def test_scene_loader_rejects_duplicate_body_ids(tmp_path: Path):
    scene = json.loads(EXAMPLE.read_text())
    scene["bodies"][1]["id"] = scene["bodies"][0]["id"]
    path = tmp_path / "duplicate.json"
    path.write_text(json.dumps(scene))
    with pytest.raises(ValueError, match="unique"):
        load_scene(path)


def test_cli_valid_scene_and_no_trace():
    env = dict(**__import__("os").environ)
    env["PYTHONPATH"] = str(ROOT / "03_reference" / "python" / "src")
    result = subprocess.run(
        [sys.executable, "-m", "nhdf_ccd_v06.cli", str(EXAMPLE), "--no-trace"],
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    assert result.returncode == 0
    payload = json.loads(result.stdout)
    assert payload["status"] == "HIT"
    assert "trace" not in payload


def test_cli_invalid_scene_is_nonzero(tmp_path: Path):
    bad = tmp_path / "bad.json"
    bad.write_text('{"schema_version":"wrong","bodies":[]}')
    env = dict(**__import__("os").environ)
    env["PYTHONPATH"] = str(ROOT / "03_reference" / "python" / "src")
    result = subprocess.run(
        [sys.executable, "-m", "nhdf_ccd_v06.cli", str(bad)],
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    assert result.returncode == 2
    assert json.loads(result.stderr)["status"] == "INVALID_INPUT"
