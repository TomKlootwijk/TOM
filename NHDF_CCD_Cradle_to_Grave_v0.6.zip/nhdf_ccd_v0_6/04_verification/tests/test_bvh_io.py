import json
from pathlib import Path

import numpy as np

from nhdf_ccd_v06 import Box, CCDStatus, MovingConvex, Pose, RigidMotion, Sphere, SweptBVH, quat_identity
from nhdf_ccd_v06.io import load_scene


def body(body_id, center, velocity=(0.0, 0.0, 0.0), radius=0.5):
    return MovingConvex(Sphere(radius), RigidMotion(Pose(np.asarray(center, dtype=float), quat_identity()), np.asarray(velocity, dtype=float)), body_id)


def test_bvh_matches_brute_force_pairs():
    bodies = [
        body("a", [-2.0, 0.0, 0.0], [4.0, 0.0, 0.0]),
        body("b", [0.0, 0.0, 0.0]),
        body("c", [10.0, 0.0, 0.0]),
        MovingConvex(Box(np.array([1.0, 0.5, 0.5])), RigidMotion(Pose(np.array([3.0, 0.0, 0.0]), quat_identity())), "d"),
    ]
    bvh = SweptBVH(bodies, leaf_size=2)
    result = bvh.candidate_pairs()
    brute = set()
    for i in range(len(bodies)):
        lo_i, hi_i = bodies[i].swept_aabb()
        for j in range(i + 1, len(bodies)):
            lo_j, hi_j = bodies[j].swept_aabb()
            if np.all(lo_i <= hi_j) and np.all(lo_j <= hi_i):
                brute.add(tuple(sorted((bodies[i].body_id, bodies[j].body_id))))
    assert set(result.pairs) == brute


def test_bvh_capacity_is_fail_closed():
    bodies = [body(str(i), [0.0, 0.0, 0.0]) for i in range(5)]
    result = SweptBVH(bodies).candidate_pairs(capacity=2)
    assert result.status == CCDStatus.RESOURCE_EXHAUSTED
    assert len(result.pairs) == 2
    assert "not_authoritative" in result.termination


def test_scene_loader(tmp_path: Path):
    scene = {
        "schema_version": "nhdf-ccd-scene-0.6.0",
        "bodies": [
            {"id": "sphere", "shape": {"kind": "sphere", "radius": 0.5}, "pose0": {"translation": [-2, 0, 0]}, "linear_velocity": [4, 0, 0]},
            {"id": "box", "shape": {"kind": "box", "half_extents": [0.5, 0.5, 0.5]}, "pose0": {"translation": [0, 0, 0]}},
        ],
    }
    path = tmp_path / "scene.json"
    path.write_text(json.dumps(scene), encoding="utf-8")
    a, b = load_scene(path)
    assert a.body_id == "sphere"
    assert b.shape.kind == "box"
