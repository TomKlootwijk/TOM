import math

import numpy as np

from nhdf_ccd_v06 import (
    Box,
    CAConfig,
    CCDStatus,
    Capsule,
    MovingConvex,
    Pose,
    RigidMotion,
    Sphere,
    conservative_advancement,
    quat_identity,
    sphere_sphere_linear,
)
from nhdf_ccd_v06.oracles import orbiting_sphere_fixed_sphere_toi


def stationary(shape, at, body_id):
    return MovingConvex(shape, RigidMotion(Pose(np.asarray(at, dtype=float), quat_identity())), body_id)


def test_translational_sphere_hit_matches_exact_band():
    a = MovingConvex(Sphere(1.0), RigidMotion(Pose(np.array([-3.0, 0.0, 0.0]), quat_identity()), np.array([6.0, 0.0, 0.0])), "a")
    b = stationary(Sphere(1.0), [0.0, 0.0, 0.0], "b")
    exact = sphere_sphere_linear(np.array([-3.0, 0.0, 0.0]), np.array([6.0, 0.0, 0.0]), 1.0,
                                 np.zeros(3), np.zeros(3), 1.0)
    result = conservative_advancement(a, b)
    assert result.status == CCDStatus.HIT
    assert result.toi_upper is not None
    assert result.toi_upper <= exact.time
    assert exact.time - result.toi_upper < 5e-7


def test_sphere_miss():
    a = MovingConvex(Sphere(0.5), RigidMotion(Pose(np.array([-3.0, 3.0, 0.0]), quat_identity()), np.array([6.0, 0.0, 0.0])), "a")
    b = stationary(Sphere(0.5), [0.0, 0.0, 0.0], "b")
    result = conservative_advancement(a, b)
    assert result.status == CCDStatus.MISS


def test_initial_overlap():
    a = stationary(Sphere(1.0), [0.0, 0.0, 0.0], "a")
    b = stationary(Sphere(1.0), [1.0, 0.0, 0.0], "b")
    result = conservative_advancement(a, b)
    assert result.status == CCDStatus.INITIAL_OVERLAP
    assert result.toi_upper == 0.0


def test_rotating_orbit_matches_analytic_oracle():
    local_center = np.array([2.0, 0.0, 0.0])
    fixed_center = np.array([0.0, 2.0, 0.0])
    omega = math.pi
    exact = orbiting_sphere_fixed_sphere_toi(local_center, np.zeros(3), omega, 0.2, fixed_center, 0.2)
    a = MovingConvex(Sphere(0.2, local_center), RigidMotion(Pose.identity(), angular_velocity=np.array([0.0, 0.0, omega])), "orbit")
    b = stationary(Sphere(0.2), fixed_center, "fixed")
    result = conservative_advancement(a, b)
    assert exact is not None
    assert result.status == CCDStatus.HIT
    assert result.toi_upper is not None
    assert result.toi_upper <= exact
    assert exact - result.toi_upper < 5e-7


def test_rotating_capsule_box_hit():
    a = MovingConvex(Capsule(np.array([-1.0, 0.0, 0.0]), np.array([1.0, 0.0, 0.0]), 0.15),
                     RigidMotion(Pose.identity(), angular_velocity=np.array([0.0, 0.0, 2.4])), "capsule")
    b = stationary(Box(np.array([0.25, 0.25, 0.25])), [0.0, 1.0, 0.0], "box")
    result = conservative_advancement(a, b)
    assert result.status == CCDStatus.HIT
    assert result.toi_upper is not None and 0.43 < result.toi_upper < 0.46


def test_quadratic_translation_profile_hit():
    a = MovingConvex(Sphere(0.5), RigidMotion(Pose(np.array([-3.0, 0.0, 0.0]), quat_identity()),
                                                linear_velocity=np.array([1.0, 0.0, 0.0]),
                                                linear_acceleration=np.array([8.0, 0.0, 0.0])), "accelerating")
    b = stationary(Sphere(0.5), [0.0, 0.0, 0.0], "fixed")
    result = conservative_advancement(a, b)
    assert result.status == CCDStatus.HIT
    assert result.toi_upper is not None and result.toi_upper < 1.0


def test_small_iteration_budget_fails_closed():
    a = MovingConvex(Sphere(1.0), RigidMotion(Pose(np.array([-3.0, 0.0, 0.0]), quat_identity()), np.array([6.0, 0.0, 0.0])), "a")
    b = stationary(Sphere(1.0), [0.0, 0.0, 0.0], "b")
    result = conservative_advancement(a, b, CAConfig(max_iterations=1))
    assert result.status == CCDStatus.INCONCLUSIVE


def test_trace_digest_is_deterministic():
    a = MovingConvex(Sphere(1.0), RigidMotion(Pose(np.array([-3.0, 0.0, 0.0]), quat_identity()), np.array([6.0, 0.0, 0.0])), "a")
    b = stationary(Sphere(1.0), [0.0, 0.0, 0.0], "b")
    first = conservative_advancement(a, b)
    second = conservative_advancement(a, b)
    assert first.trace_sha256 == second.trace_sha256
    assert first.to_dict() == second.to_dict()


def test_orbiting_oracle_reports_initial_overlap_at_zero():
    from nhdf_ccd_v06.oracles import orbiting_sphere_fixed_sphere_toi
    t = orbiting_sphere_fixed_sphere_toi(
        np.array([2.0, 0.0, 0.0]), np.zeros(3), math.pi,
        0.25, np.array([2.1, 0.0, 0.0]), 0.25,
    )
    assert t == 0.0
