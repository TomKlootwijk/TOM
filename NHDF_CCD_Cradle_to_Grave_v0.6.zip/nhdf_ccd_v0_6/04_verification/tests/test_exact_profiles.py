import numpy as np

from nhdf_ccd_v06 import sphere_capsule_linear, sphere_sphere_linear


def test_exact_sphere_sphere_hit():
    result = sphere_sphere_linear(np.array([-3.0, 0.0, 0.0]), np.array([6.0, 0.0, 0.0]), 1.0,
                                  np.zeros(3), np.zeros(3), 1.0)
    assert result.hit
    assert abs(result.time - 1.0 / 6.0) < 1e-14
    assert np.linalg.norm(result.witness_a - result.witness_b) < 1e-12


def test_exact_sphere_sphere_miss():
    result = sphere_sphere_linear(np.array([-3.0, 3.0, 0.0]), np.array([6.0, 0.0, 0.0]), 0.5,
                                  np.zeros(3), np.zeros(3), 0.5)
    assert not result.hit


def test_exact_sphere_capsule_cylinder_hit():
    result = sphere_capsule_linear(np.array([-3.0, 0.0, 0.0]), np.array([6.0, 0.0, 0.0]), 0.5,
                                   np.array([0.0, -1.0, 0.0]), np.array([0.0, 1.0, 0.0]), np.zeros(3), 0.5)
    assert result.hit
    assert abs(result.time - 1.0 / 3.0) < 1e-12
    assert result.feature_b == "cylinder"


def test_exact_sphere_capsule_end_cap_hit():
    result = sphere_capsule_linear(np.array([-3.0, 2.0, 0.0]), np.array([6.0, 0.0, 0.0]), 0.25,
                                   np.array([0.0, -1.0, 0.0]), np.array([0.0, 1.0, 0.0]), np.zeros(3), 0.75)
    assert result.hit
    assert result.feature_b == "cap_b"
