import math
import numpy as np
import pytest

from nhdf_ccd_v06 import Box, Capsule, ConvexHull, Pose, Sphere, Triangle, quat_from_rotation_vector, quat_identity
from nhdf_ccd_v06.math3d import norm, quat_rotate
from nhdf_ccd_v06.shapes import support_world


def test_quaternion_identity_rotation():
    v = np.array([1.0, -2.0, 3.0])
    assert np.allclose(quat_rotate(quat_identity(), v), v)


def test_quaternion_quarter_turn():
    q = quat_from_rotation_vector(np.array([0.0, 0.0, math.pi / 2]))
    assert np.allclose(quat_rotate(q, np.array([1.0, 0.0, 0.0])), [0.0, 1.0, 0.0], atol=1e-12)


def test_pose_rejects_zero_quaternion():
    with pytest.raises(ValueError):
        Pose(np.zeros(3), np.zeros(4))


def test_sphere_support_and_radius():
    sphere = Sphere(0.5, np.array([2.0, 0.0, 0.0]))
    s = sphere.support_local(np.array([3.0, 0.0, 0.0]))
    assert np.allclose(s.point, [2.5, 0.0, 0.0])
    assert sphere.bounding_radius() == pytest.approx(2.5)


def test_capsule_support_selects_cap():
    capsule = Capsule(np.array([-1.0, 0.0, 0.0]), np.array([1.0, 0.0, 0.0]), 0.25)
    assert capsule.support_local(np.array([1.0, 0.0, 0.0])).feature == "cap_b"
    assert capsule.support_local(np.array([-1.0, 0.0, 0.0])).feature == "cap_a"


def test_box_has_eight_vertices():
    box = Box(np.array([1.0, 2.0, 3.0]))
    vertices = box.vertices_local()
    assert vertices.shape == (8, 3)
    assert np.max(np.linalg.norm(vertices, axis=1)) == pytest.approx(math.sqrt(14.0))


def test_triangle_support_is_vertex():
    tri = Triangle(np.array([0.0, 0.0, 0.0]), np.array([2.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0]))
    assert tri.support_local(np.array([1.0, 0.1, 0.0])).feature == "vertex_b"


def test_convex_hull_validates_shape():
    with pytest.raises(ValueError):
        ConvexHull(np.zeros((0, 3)))


def test_world_support_respects_pose_rotation():
    pose = Pose(np.array([1.0, 2.0, 0.0]), quat_from_rotation_vector(np.array([0.0, 0.0, math.pi / 2])))
    box = Box(np.array([1.0, 0.5, 0.25]))
    support = support_world(box, pose, np.array([0.0, 1.0, 0.0]))
    assert support.point[1] == pytest.approx(3.0)
    assert norm(support.point - pose.translation) <= box.bounding_radius() + 1e-12
