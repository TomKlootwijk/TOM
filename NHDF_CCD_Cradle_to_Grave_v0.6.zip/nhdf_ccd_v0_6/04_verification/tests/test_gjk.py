import math
import numpy as np
import pytest

from nhdf_ccd_v06 import Box, Capsule, ConvexHull, Pose, Sphere, Triangle, gjk_distance, quat_from_rotation_vector, quat_identity


def pose(x, q=None):
    return Pose(np.asarray(x, dtype=float), quat_identity() if q is None else q)


def test_sphere_sphere_separation_exact():
    result = gjk_distance(Sphere(1.0), pose([0, 0, 0]), Sphere(1.0), pose([3, 0, 0]))
    assert result.converged
    assert not result.intersect
    assert result.distance == pytest.approx(1.0, abs=1e-12)
    assert result.lower_bound <= 1.0 <= result.upper_bound


def test_sphere_sphere_overlap():
    result = gjk_distance(Sphere(1.0), pose([0, 0, 0]), Sphere(1.0), pose([1.0, 0, 0]))
    assert result.intersect
    assert result.distance <= 1e-10


def test_sphere_box_axis_distance():
    result = gjk_distance(Sphere(0.5), pose([3, 0, 0]), Box(np.array([1.0, 1.0, 1.0])), pose([0, 0, 0]))
    assert result.distance == pytest.approx(1.5, abs=1e-9)


def test_capsule_triangle_distance():
    capsule = Capsule(np.array([-0.5, 0, 0]), np.array([0.5, 0, 0]), 0.2)
    tri = Triangle(np.array([-1, -1, 0]), np.array([1, -1, 0]), np.array([0, 1, 0]))
    result = gjk_distance(capsule, pose([0, 0, 2]), tri, pose([0, 0, 0]))
    assert result.distance == pytest.approx(1.8, abs=2e-8)


def test_rotated_box_distance_symmetry():
    qa = quat_from_rotation_vector(np.array([0.2, -0.3, 0.4]))
    qb = quat_from_rotation_vector(np.array([-0.1, 0.5, -0.2]))
    a = Box(np.array([1.0, 0.4, 0.6]))
    b = Box(np.array([0.5, 0.7, 0.8]))
    ab = gjk_distance(a, pose([-2, 0.2, 0.1], qa), b, pose([2, -0.1, 0.3], qb))
    ba = gjk_distance(b, pose([2, -0.1, 0.3], qb), a, pose([-2, 0.2, 0.1], qa))
    assert ab.distance == pytest.approx(ba.distance, abs=1e-9)
    assert np.allclose(ab.closest_a, ba.closest_b, atol=1e-8)


def test_convex_hull_point_distance():
    hull = ConvexHull(np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float))
    point = Sphere(0.0)
    result = gjk_distance(hull, pose([0, 0, 0]), point, pose([2, 2, 2]))
    expected = math.sqrt(3.0) * (2.0 - 1.0 / 3.0)
    assert result.distance == pytest.approx(expected, abs=1e-8)


def test_gjk_trace_has_bounds():
    result = gjk_distance(Box(np.ones(3)), pose([0, 0, 0]), Sphere(0.5), pose([4, 1, 0]), capture_trace=True)
    assert result.trace
    assert all(step["lower"] <= step["upper"] + 1e-14 for step in result.trace)


def test_gjk_invalid_iterations():
    with pytest.raises(ValueError):
        gjk_distance(Sphere(1), pose([0, 0, 0]), Sphere(1), pose([2, 0, 0]), max_iterations=0)
