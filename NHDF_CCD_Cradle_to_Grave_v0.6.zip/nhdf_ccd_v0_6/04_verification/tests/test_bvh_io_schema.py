import json
from pathlib import Path

import numpy as np
import pytest
from jsonschema import Draft202012Validator

from nhdf_ccd_v06 import Box, CCDStatus, MovingConvex, Pose, RigidMotion, Sphere, SweptBVH, conservative_advancement, quat_identity
from nhdf_ccd_v06.bvh import AABB
from nhdf_ccd_v06.io import load_scene

ROOT = Path(__file__).resolve().parents[2]


def body(identifier, position, velocity=(0,0,0), radius=.5):
    return MovingConvex(Sphere(radius), RigidMotion(Pose(np.asarray(position,dtype=float), quat_identity()), linear_velocity=np.asarray(velocity,dtype=float)), identifier)


def test_aabb_overlap():
    assert AABB(np.zeros(3), np.ones(3)).overlaps(AABB(np.array([1.,.5,.5]), np.array([2.,1.5,1.5])))


def test_bvh_matches_bruteforce_pairs():
    bodies = [body("a", [-3,0,0], [6,0,0]), body("b", [0,0,0]), body("c", [8,0,0]), body("d", [8.5,0,0])]
    bvh = SweptBVH(bodies, leaf_size=2)
    result = bvh.candidate_pairs()
    brute = set()
    boxes = [AABB(*b.swept_aabb()) for b in bodies]
    for i in range(len(bodies)):
        for j in range(i+1,len(bodies)):
            if boxes[i].overlaps(boxes[j]):
                brute.add(tuple(sorted((bodies[i].body_id,bodies[j].body_id))))
    assert set(result.pairs) == brute


def test_bvh_capacity_fails_closed():
    bodies = [body(str(i), [0,0,0]) for i in range(5)]
    result = SweptBVH(bodies).candidate_pairs(capacity=2)
    assert result.status == CCDStatus.RESOURCE_EXHAUSTED
    assert "not_authoritative" in result.termination


def test_scene_json_schema_and_loader():
    scene_path = ROOT / "03_reference/python/examples/rotating_capsule_box.json"
    scene = json.loads(scene_path.read_text())
    schema = json.loads((ROOT / "02_formal_specification/scene.schema.json").read_text())
    Draft202012Validator(schema).validate(scene)
    a,b = load_scene(scene_path)
    assert a.body_id == "rotating_capsule" and b.body_id == "box"


def test_certificate_json_schema():
    a = body("a", [-2,0,0], [4,0,0])
    b = body("b", [0,0,0])
    data = conservative_advancement(a,b).to_dict()
    schema = json.loads((ROOT / "02_formal_specification/certificate.schema.json").read_text())
    Draft202012Validator(schema).validate(data)


def test_broadphase_json_schema():
    result = SweptBVH([body("a", [0,0,0]),body("b", [.5,0,0])]).candidate_pairs().to_dict()
    schema = json.loads((ROOT / "02_formal_specification/broadphase.schema.json").read_text())
    Draft202012Validator(schema).validate(result)


def test_loader_rejects_duplicate_ids(tmp_path):
    source = json.loads((ROOT / "03_reference/python/examples/rotating_capsule_box.json").read_text())
    source["bodies"][1]["id"] = source["bodies"][0]["id"]
    path = tmp_path / "bad.json"
    path.write_text(json.dumps(source))
    with pytest.raises(ValueError):
        load_scene(path)
