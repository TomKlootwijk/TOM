# Adversarial and degeneracy catalogue

- zero and near-zero radii;
- coincident centers and initial overlap;
- tangential/grazing contact;
- high-speed tunnelling with separated endpoints;
- near-parallel capsule approaches;
- support ties at box and triangle vertices;
- duplicate GJK support points;
- simplex rank deficiency;
- very small closing speeds;
- large angular reach and offset local centers;
- quadratic translation extrema inside the step;
- no representable safe time increment;
- CA, GJK, refinement, trace, and candidate capacity exhaustion;
- malformed quaternion, NaN/Inf vectors, negative radii, empty hull;
- deterministic replay after order permutations.

A catalogue entry is not considered closed merely because no crash occurs. The expected status and authority of every output must be checked.
