# NHDF-CCD v0.6 release-validation log

- Generated: `2026-09-01T14:33:57.052393+00:00`
- Overall result: **PASS**
- PDF: 163 A4 pages; 0 non-embedded fonts; all pages low-resolution render-smoked.
- Python: 73 test methods; gate PASS.
- C++17 smoke: PASS.
- Host-compiled CUDA arithmetic/layout profile: PASS.
- CUDA static source contract: PASS.
- JSON schemas/examples: PASS.
- Benchmark decisive checks: PASS.

## Recorded corpus

- 2400 static GJK queries against analytic primitive distances.
- 1400 linear sphere-sphere CCD queries against analytic roots.
- 550 rotating/orbiting sphere CCD queries against an analytic trigonometric oracle.
- 100 diagnostic convex-QP cross-checks.
- Swept-BVH scenes up to 2000 bodies.
- 1034 collisions missed by endpoint-only checks and recovered by CCD.
- Zero recorded false negatives, false positives, GJK bound violations over tolerance, unresolved analytic cases, and checked BVH pair-set disagreements.

## Open gate

- CUDA device compilation/execution: **OPEN - nvcc/GPU unavailable in this build environment**.
- The observations above concern the seeded binary64 corpus and do not prove all inputs or certify production/safety use.
