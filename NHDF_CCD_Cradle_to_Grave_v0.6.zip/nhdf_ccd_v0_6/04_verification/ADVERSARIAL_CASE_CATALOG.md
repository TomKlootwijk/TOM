# Adversarial case catalogue

| ID | Case | Expected handling |
|---|---|---|
| A-01 | Initial overlap | `INITIAL_OVERLAP`, time interval `[0,0]` |
| A-02 | Tangential sphere contact | Hit or a declared contact-band result; never an authoritative miss from endpoint checking |
| A-03 | Rotational tunnelling with separated endpoints | Continuous hit recovered |
| A-04 | Parallel capsule axis and motion | Stable finite-cylinder/end-cap reduction |
| A-05 | Zero-length capsule | Behaves as a sphere through support mapping |
| A-06 | Coplanar/zero-area triangle | Convex support remains defined; no fabricated feature proof |
| A-07 | Duplicate hull vertices | Deterministic support and bounded GJK termination |
| A-08 | Large/small scale ratio | Explicit tolerances; unresolved states stay non-authoritative |
| A-09 | GJK iteration exhaustion | `NUMERICAL_FAILURE` or `INCONCLUSIVE`, not `MISS` |
| A-10 | CA progress underflows | `INCONCLUSIVE`; no unsafe minimum step |
| A-11 | Broad-phase capacity exhaustion | Partial list marked non-authoritative |
| A-12 | Non-finite scene data | Schema or runtime rejection |
| A-13 | Identical body IDs | Loader rejection |
| A-14 | Curved translational trajectory | Quadratic speed and swept bounds cover the entire interval |
| A-15 | High angular displacement | Global `|omega|R` bound; performance may degrade but safety classification is preserved |
