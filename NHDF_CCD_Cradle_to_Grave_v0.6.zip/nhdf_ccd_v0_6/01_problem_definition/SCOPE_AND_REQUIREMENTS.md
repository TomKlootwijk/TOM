# Scope and requirements

## Problem

Given two closed convex bodies A and B whose rigid trajectories are declared on
normalized time `t in [0,1]`, determine whether their contact band is reached,
return the earliest conservative activation interval when found, or preserve an
explicit unresolved/failure state.

## Supported geometry

- sphere with optional local center;
- capsule as a local segment plus radius;
- oriented box;
- triangle treated as a closed convex set of zero volume;
- finite vertex set interpreted through its convex hull.

## Supported motion

For each body:

- translation `p(t) = p0 + v0 t + 0.5 a t^2`;
- orientation `q(t) = exp(0.5 t omega) q0` for constant world angular velocity;
- a finite shape bounding radius measured from the body origin.

## Mandatory behavior

1. Use support mappings rather than require an explicit triangulation.
2. Expose both a lower and upper separation bound from the distance query.
3. Advance only from a conservative lower separation bound and a conservative
   point-pair speed bound.
4. Accept contact only from an upper separation bound inside the declared band.
5. Preserve `INCONCLUSIVE` when progress, iteration or numerical conditions are
   insufficient.
6. Treat broad-phase capacity overflow as `RESOURCE_EXHAUSTED`; never silently
   truncate an authoritative candidate set.
7. Record witnesses, normal, feature labels, iteration counts, termination reason,
   configuration and deterministic trace hash where available.
8. Keep collision response outside the detection certificate.
9. Keep NHDF log-polar, parity, golden-ratio and topology constructs outside the
   safety path unless separately proven equivalent.

## Out of scope

Non-convex narrow phase, triangle-triangle feature-root CCD, deforming meshes,
self-collision, exact penetration depth, contact manifolds, friction, restitution,
constraint solving, exact-real arithmetic, certified rounding, compiled CUDA
execution, clinical use and autonomous enforcement decisions.
