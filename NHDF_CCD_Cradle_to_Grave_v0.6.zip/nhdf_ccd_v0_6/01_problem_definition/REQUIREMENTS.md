# v0.6 requirements

## Functional

- **R-001** Accept support-mapped convex shapes: sphere, capsule, box, triangle, finite convex hull.
- **R-002** Evaluate distance with witnesses and auditable lower/upper bounds.
- **R-003** Detect contact-band entry over normalized `t in [0,1]` for quadratic translation and constant angular velocity.
- **R-004** Use a conservative relative point-speed bound including rotational reach.
- **R-005** Return exact linear sphere-sphere and sphere-capsule profiles for validation and fast paths.
- **R-006** Generate broad-phase pairs from conservative swept AABBs.
- **R-007** Emit a versioned result with status, time semantics, witnesses, bounds, termination, and deterministic trace digest.

## Safety and resource bounds

- **R-101** Never force an unsafe minimum time step.
- **R-102** Never convert an unresolved numerical state to `MISS`.
- **R-103** Bound CA/GJK/refinement iterations and trace length.
- **R-104** Bound broad-phase candidate output and surface partial-list non-authoritativeness.
- **R-105** Reject non-finite or malformed inputs.
- **R-106** Preserve deterministic ordering and replay under the reference profile.

## Lifecycle

- **R-201** Provide Python and C++17 implementations, tests, benchmark generators, schemas, report source, release hashes, migration, operations, and retirement records.
- **R-202** Provide a GPU porting artifact without claiming device verification when unavailable.
- **R-203** Keep non-CCD substrate mappings under an independent qualification protocol.
