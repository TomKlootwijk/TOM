# Scope and exclusions

## In scope
- Pairwise rigid convex CCD over a normalized step.
- Conservative contact-band entry, witnesses, traceability, and explicit failure.
- Quadratic center translation and constant world angular velocity.
- Conservative swept-AABB broad phase.
- Analytic translational sphere profiles.

## Out of scope
- General non-convex bodies without decomposition.
- General triangle-triangle, edge-edge, deforming mesh, cloth self-collision, and topology changes.
- Exact penetration depth/manifold generation and impulse/contact response.
- Guaranteed exact-real results for all degenerate floating-point inputs.
- Unbounded recursion, silent allocation, or one-clock universal CCD.
- Medical treatment, autonomous policing authority, identity locking, universal physics, or cryptographic proof from personal metadata.
