# Hazard analysis

| Hazard | Cause | Detection | Required response |
|---|---|---|---|
| False `MISS` | invalid lower bound, underestimated speed, numerical bug | analytic/differential corpus, runtime residuals | fail closed; stop or fallback |
| False `HIT` | loose bounds/contact band | compare exact profile; telemetry | accept conservatism or refine |
| Time stall | floating-point increment cannot advance | `next_t <= t` | `INCONCLUSIVE` |
| GJK uncertainty | support duplication, ill-conditioned simplex, iteration cap | bound gap and termination | retry/stronger backend; never call miss |
| Candidate overflow | finite broad-phase output | capacity counter | `RESOURCE_EXHAUSTED`, discard authority |
| Invalid shape/motion | NaN, negative radius, zero quaternion | constructors/schema | `INVALID_INPUT` |
| Angular under-bound | wrong radius/origin convention | review and oracle cases | reject profile; enlarge bound |
| Integration misuse | caller treats unresolved as miss | API contract and tests | safety interlock and incident |
| Evidence overreach | CCD results generalized to medicine/physics | claim ledger | adapter qualification only |
