# Acceptance criteria

A v0.6 release candidate is accepted only when all mandatory gates pass:

| ID | Criterion |
|---|---|
| AC-01 | Python package imports and every declared unit test passes. |
| AC-02 | C++17 reference configures, builds without compiler warnings under the supplied flags, and passes CTest. |
| AC-03 | Static GJK generated cases show no lower/upper bound violation above the declared oracle tolerance for the analytic primitive families. |
| AC-04 | Translating sphere cases show no observed false positive or false negative against the analytic quadratic oracle. |
| AC-05 | Orbiting sphere cases show no observed false positive or false negative against the analytic trigonometric oracle. |
| AC-06 | Swept-BVH pair sets exactly match brute force at the checked scales. |
| AC-07 | Tunnelling cases demonstrate that endpoint-only tests miss contacts recovered by the continuous query. |
| AC-08 | Forced resource and iteration shortages return failure/unresolved states rather than `MISS`. |
| AC-09 | Scene and certificate examples validate against versioned JSON schemas. |
| AC-10 | CUDA status is reported honestly as unexecuted when no CUDA toolchain/runtime exists. |
| AC-11 | PDF compiles, passes preflight, embeds fonts, and has no visible clipping/overlap in rendered inspection. |
| AC-12 | ZIP passes CRC and clean-extraction SHA-256 verification. |

Passing these criteria establishes only the declared reference profile on the tested
corpus. It does not establish production readiness or a proof for all floating-point
inputs.
