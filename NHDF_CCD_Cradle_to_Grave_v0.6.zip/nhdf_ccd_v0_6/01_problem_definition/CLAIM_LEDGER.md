# Claim ledger

| Claim | v0.6 status | Permitted wording |
|---|---|---|
| Support-mapped convex distance can drive bounded conservative advancement | implemented and tested on declared shapes | "reference implementation" |
| Quadratic translation and constant angular velocity are represented continuously over one normalized step | implemented | "supported trajectory profile" |
| The generated analytic corpora had no observed classification errors | measured | report exact counts and seed; never call a proof |
| Endpoint-only collision checks can miss mid-step contacts | demonstrated | "constructed tunnelling demonstration" |
| General rigid-body CCD is fully solved | not established | prohibited |
| The returned `toi_upper` is an exact impact-time upper bound | false for tolerance-band activation | prohibited |
| The CUDA candidate is CPU-equivalent and fast | not tested | prohibited |
| Parity, golden ratio or Klein topology supplies collision correctness | not established | prohibited |
| CCD validation transfers to optics, biology, medicine, chemistry or cosmology | false without independent adapter evidence | prohibited |
| NHDF treats civil identity data as cryptographic proof | rejected | prohibited |
