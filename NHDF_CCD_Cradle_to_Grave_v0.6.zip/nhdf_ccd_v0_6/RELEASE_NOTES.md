# Release notes - v0.6.0

## What is new

1. **Rigid-convex narrow phase.** The main pair query now accepts support-mapped
   sphere, capsule, box, triangle and finite convex-hull shapes.
2. **Auditable distance bounds.** GJK records a support-plane lower bound and a
   simplex/witness upper bound. Conservative advancement uses the lower bound for
   safe progress and the upper bound for contact-band acceptance.
3. **Curved rigid trajectories.** Translation may be quadratic; orientation uses a
   constant world angular-velocity exponential-map update.
4. **Motion-bound contract.** The point-pair speed bound contains relative affine
   translation plus `|omega| R` angular terms for both bodies.
5. **Broad phase.** A deterministic swept-AABB BVH reports all conservative pairs
   or fails closed with `RESOURCE_EXHAUSTED`.
6. **Independent verification.** Exact primitive distance formulas, quadratic
   sphere roots, an orbiting-sphere trigonometric oracle, brute-force broad phase,
   Python tests and a separately written C++17 implementation are included.
7. **GPU continuation.** A fixed-size sphere/capsule/box/triangle host/device core
   and CUDA batch wrapper are supplied as an unqualified candidate.
8. **Lifecycle continuity.** v0.4 and v0.5 are retained as historical source
   artifacts, while migration and retirement records identify changed semantics.

## Important semantic change

The v0.6 Python certificate uses `MISS` rather than v0.5's `NO_HIT` spelling.
Adapters must map only these definitive states:

- `HIT` or `INITIAL_OVERLAP` -> contact event;
- `MISS` -> no contact under the declared profile and bounds;
- every other status -> unresolved/failure handling.

The time interval is explicitly a conservative *contact-band activation interval*.
It must not be represented as a mathematically exact time-of-impact root.

## Deferred

- exact or interval-certified general rotation roots;
- penetration depth/EPA and contact manifolds;
- deforming geometry, cloth self-collision and triangle-triangle CCD;
- production SAH/LBVH broad phase and persistent GPU queues;
- compiled CUDA equivalence and target-GPU performance;
- dynamics, restitution, friction and constraint solving;
- formal proof over all binary64 inputs or exact-real arithmetic.
