#!/usr/bin/env python3
from pathlib import Path
import csv, json
import numpy as np
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'05_benchmarks'/'results'
F=ROOT/'05_benchmarks'/'figures'
F.mkdir(parents=True,exist_ok=True)
summary=json.loads((R/'benchmark_summary.json').read_text())
checks=summary['authoritative_checks']

# 1. Query coverage
names=['Static GJK\nanalytic','Linear sphere\nanalytic','Rotating sphere\nanalytic','Swept BVH\nscales']
values=[checks['static_gjk_vs_analytic_primitives']['queries'],checks['linear_sphere_vs_analytic']['queries'],checks['orbiting_sphere_vs_analytic']['queries'],checks['swept_bvh_vs_bruteforce']['largest_body_count']]
fig,ax=plt.subplots(figsize=(8.6,5.0))
bars=ax.bar(names,values)
ax.set_ylabel('Queries or largest body count')
ax.set_title('NHDF-CCD v0.6 validation coverage')
ax.grid(axis='y',alpha=.25)
for b,v in zip(bars,values): ax.text(b.get_x()+b.get_width()/2,v,f'{v:,}',ha='center',va='bottom')
fig.tight_layout(); fig.savefig(F/'validation_coverage.png',dpi=180); plt.close(fig)

# helpers

def read_csv(name):
    with (R/name).open(newline='',encoding='utf-8') as f: return list(csv.DictReader(f))

# 2. Timing lead distributions
linear=read_csv('linear_sphere_cases.csv')
orbit=read_csv('orbiting_sphere_cases.csv')
lin=np.array([float(x['lead_before_exact']) for x in linear if x.get('lead_before_exact') not in ('',None)],dtype=float)
orb=np.array([float(x['lead_before_exact']) for x in orbit if x.get('lead_before_exact') not in ('',None)],dtype=float)
fig,ax=plt.subplots(figsize=(8.6,5.0))
bins=np.logspace(-14,-6,45)
ax.hist(lin[lin>0],bins=bins,alpha=.6,label='linear sphere')
ax.hist(orb[orb>0],bins=bins,alpha=.6,label='rotating offset sphere')
ax.set_xscale('log')
ax.set_xlabel('Contact-band lead before exact geometric TOI')
ax.set_ylabel('Cases')
ax.set_title('Conservative timing lead distribution')
ax.legend(); ax.grid(axis='y',alpha=.25)
fig.tight_layout(); fig.savefig(F/'contact_band_lead.png',dpi=180); plt.close(fig)

# 3. GJK accuracy by family
rows=read_csv('static_gjk_analytic_cases.csv')
families=sorted(set(r['family'] for r in rows))
data=[]
for family in families:
    vals=[max(float(r['upper_absolute_error']),1e-18) for r in rows if r['family']==family]
    data.append(vals)
fig,ax=plt.subplots(figsize=(8.8,5.1))
ax.boxplot(data,tick_labels=[f.replace('_','\n') for f in families],showfliers=False)
ax.set_yscale('log')
ax.set_ylabel('Absolute upper-bound error')
ax.set_title('Static GJK distance accuracy against analytic primitive distances')
ax.grid(axis='y',alpha=.25)
fig.tight_layout(); fig.savefig(F/'gjk_accuracy.png',dpi=180); plt.close(fig)

# 4. BVH scaling
bvh=read_csv('bvh_scaling.csv')
x=np.array([int(r['bodies']) for r in bvh])
y=np.array([float(r['bvh_seconds']) for r in bvh])
fig,ax=plt.subplots(figsize=(8.2,4.9))
ax.plot(x,y,marker='o')
ax.set_xlabel('Bodies')
ax.set_ylabel('Wall time (seconds)')
ax.set_title('Deterministic swept-AABB BVH scaling')
ax.grid(alpha=.25)
for xi,yi in zip(x,y): ax.annotate(f'{yi:.3f}s',(xi,yi),xytext=(4,5),textcoords='offset points',fontsize=8)
fig.tight_layout(); fig.savefig(F/'bvh_scaling.png',dpi=180); plt.close(fig)

# 5. Outcome counts (expected zero errors)
labels=['Linear sphere','Rotating sphere','Static GJK','BVH']
false_neg=[checks['linear_sphere_vs_analytic']['false_negatives'],checks['orbiting_sphere_vs_analytic']['false_negatives'],0,0]
false_pos=[checks['linear_sphere_vs_analytic']['false_positives'],checks['orbiting_sphere_vs_analytic']['false_positives'],0,0]
unresolved=[checks['linear_sphere_vs_analytic']['unresolved'],checks['orbiting_sphere_vs_analytic']['unresolved'],checks['static_gjk_vs_analytic_primitives']['gjk_unresolved'],checks['swept_bvh_vs_bruteforce']['pair_set_disagreements']]
fig,ax=plt.subplots(figsize=(8.5,4.8))
pos=np.arange(len(labels)); width=.25
ax.bar(pos-width,false_neg,width,label='false negatives')
ax.bar(pos,false_pos,width,label='false positives')
ax.bar(pos+width,unresolved,width,label='unresolved/disagreement')
ax.set_xticks(pos,labels); ax.set_ylabel('Count'); ax.set_title('Decisive validation outcomes')
ax.set_ylim(0,1); ax.legend(); ax.grid(axis='y',alpha=.25)
fig.tight_layout(); fig.savefig(F/'validation_outcomes.png',dpi=180); plt.close(fig)

print('wrote',len(list(F.glob('*.png'))),'figures to',F)

# 6. Conservative advancement trace (rotating capsule vs box)
certs=json.loads((R/'reference_certificates.json').read_text())
rot=next(x['certificate'] for x in certs if x['name']=='rotating_capsule_box')
trace=rot['trace']
t=np.array([float(x['time']) for x in trace])
d=np.array([max(float(x['distance']),1e-16) for x in trace])
fig,ax=plt.subplots(figsize=(8.6,5.0))
ax.plot(t,d,marker='o',markersize=3)
ax.axhline(float(rot['contact_tolerance'])+float(rot['distance_error_budget']),linestyle='--',label='declared contact band')
ax.set_yscale('log')
ax.set_xlabel('Normalized time')
ax.set_ylabel('GJK upper separation bound')
ax.set_title('Conservative advancement convergence: rotating capsule vs box')
ax.grid(alpha=.25)
ax.legend()
fig.tight_layout(); fig.savefig(F/'ca_trace.png',dpi=180); plt.close(fig)

# 7. GJK lower and upper bound closure for the deterministic trace vector
trace_doc=json.loads((R/'gjk_bound_trace.json').read_text())['result']['trace']
it=np.array([int(x['iteration']) for x in trace_doc])
lo=np.array([float(x['lower']) for x in trace_doc])
hi=np.array([float(x['upper']) for x in trace_doc])
fig,ax=plt.subplots(figsize=(8.2,4.8))
ax.plot(it,lo,marker='o',label='support-plane lower bound')
ax.plot(it,hi,marker='o',label='simplex upper bound')
ax.set_xlabel('GJK iteration')
ax.set_ylabel('Separation bound')
ax.set_title('Deterministic GJK bound closure')
ax.set_xticks(it)
ax.grid(alpha=.25)
ax.legend()
fig.tight_layout(); fig.savefig(F/'gjk_bound_closure.png',dpi=180); plt.close(fig)
