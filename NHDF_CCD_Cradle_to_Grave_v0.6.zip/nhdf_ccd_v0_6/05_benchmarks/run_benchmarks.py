#!/usr/bin/env python3
"""Deterministic verification benchmarks for NHDF-CCD v0.6.

The benchmark separates authoritative checks from observational stress tests:
- static GJK bounds are checked against an independently formulated convex QP;
- translating sphere CCD is checked against an analytic quadratic oracle;
- an offset sphere rotating about the z axis is checked against an analytic trigonometric oracle;
- swept-AABB BVH output is checked against brute force at matched scales.

All generated data uses a fixed seed and is written as machine-readable CSV/JSON.
"""
from __future__ import annotations

import csv
import gc
import json
import math
import os
from pathlib import Path
import sys
import time
from dataclasses import asdict
from typing import Any

import numpy as np
from scipy.optimize import minimize

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "03_reference" / "python" / "src"
sys.path.insert(0, str(SRC))

from nhdf_ccd_v06 import (  # noqa: E402
    Box,
    CAConfig,
    CCDStatus,
    Capsule,
    ConvexHull,
    MovingConvex,
    Pose,
    RigidMotion,
    Sphere,
    SweptBVH,
    Triangle,
    conservative_advancement,
    gjk_distance,
    quat_from_rotation_vector,
    quat_identity,
    sphere_sphere_linear,
)
from nhdf_ccd_v06.oracles import orbiting_sphere_fixed_sphere_toi  # noqa: E402
from nhdf_ccd_v06.shapes import vertices_world  # noqa: E402

SEED = 0x4E484446  # ASCII-ish "NHDF"
RNG = np.random.default_rng(SEED)
RESULTS = ROOT / "05_benchmarks" / "results"
RESULTS.mkdir(parents=True, exist_ok=True)


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def jsonable(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return [float(x) for x in value]
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, CCDStatus):
        return value.value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    return value


def random_quaternion() -> np.ndarray:
    axis = RNG.normal(size=3)
    axis /= np.linalg.norm(axis)
    angle = RNG.uniform(-math.pi, math.pi)
    return quat_from_rotation_vector(axis * angle)


def independent_polytope_distance(vertices_a: np.ndarray, vertices_b: np.ndarray) -> tuple[float, bool, int, float]:
    """Distance between convex hulls via an independent barycentric QP.

    This is deliberately not a support-mapping/GJK implementation. SLSQP minimizes
    ||Va^T alpha - Vb^T beta||^2 with simplex constraints on alpha and beta.
    """
    va = np.asarray(vertices_a, dtype=np.float64)
    vb = np.asarray(vertices_b, dtype=np.float64)
    na, nb = len(va), len(vb)
    x0 = np.concatenate([np.full(na, 1.0 / na), np.full(nb, 1.0 / nb)])

    def objective(x: np.ndarray) -> float:
        delta = x[:na] @ va - x[na:] @ vb
        return 0.5 * float(np.dot(delta, delta))

    def gradient(x: np.ndarray) -> np.ndarray:
        delta = x[:na] @ va - x[na:] @ vb
        return np.concatenate([va @ delta, -(vb @ delta)])

    constraints = [
        {"type": "eq", "fun": lambda x: float(np.sum(x[:na]) - 1.0),
         "jac": lambda x: np.concatenate([np.ones(na), np.zeros(nb)])},
        {"type": "eq", "fun": lambda x: float(np.sum(x[na:]) - 1.0),
         "jac": lambda x: np.concatenate([np.zeros(na), np.ones(nb)])},
    ]
    result = minimize(
        objective,
        x0,
        method="SLSQP",
        jac=gradient,
        bounds=[(0.0, 1.0)] * (na + nb),
        constraints=constraints,
        options={"ftol": 1e-14, "maxiter": 1000, "disp": False},
    )
    eq_residual = max(
        abs(float(np.sum(result.x[:na]) - 1.0)),
        abs(float(np.sum(result.x[na:]) - 1.0)),
    )
    distance = math.sqrt(max(0.0, 2.0 * float(result.fun)))
    usable = bool(result.success and eq_residual <= 1e-8 and np.min(result.x) >= -1e-8)
    return distance, usable, int(result.nit), eq_residual


def _point_segment_distance(point: np.ndarray, a: np.ndarray, b: np.ndarray) -> float:
    ab = b - a
    den = float(np.dot(ab, ab))
    if den <= 1e-30:
        return float(np.linalg.norm(point - a))
    t = min(1.0, max(0.0, float(np.dot(point - a, ab) / den)))
    return float(np.linalg.norm(point - (a + t * ab)))


def _segment_segment_distance(p1: np.ndarray, q1: np.ndarray, p2: np.ndarray, q2: np.ndarray) -> float:
    """Robust closest distance between two finite segments."""
    d1 = q1 - p1
    d2 = q2 - p2
    r = p1 - p2
    a = float(np.dot(d1, d1))
    e = float(np.dot(d2, d2))
    f = float(np.dot(d2, r))
    eps = 1e-30
    if a <= eps and e <= eps:
        return float(np.linalg.norm(p1 - p2))
    if a <= eps:
        s = 0.0
        t = min(1.0, max(0.0, f / e))
    else:
        c = float(np.dot(d1, r))
        if e <= eps:
            t = 0.0
            s = min(1.0, max(0.0, -c / a))
        else:
            b = float(np.dot(d1, d2))
            denom = a * e - b * b
            s = min(1.0, max(0.0, (b * f - c * e) / denom)) if abs(denom) > eps else 0.0
            t = (b * s + f) / e
            if t < 0.0:
                t = 0.0
                s = min(1.0, max(0.0, -c / a))
            elif t > 1.0:
                t = 1.0
                s = min(1.0, max(0.0, (b - c) / a))
    return float(np.linalg.norm((p1 + d1 * s) - (p2 + d2 * t)))


def _analytic_distance(family: str, shape_a: Any, pose_a: Pose, shape_b: Any, pose_b: Pose) -> float:
    if family == "sphere_sphere":
        ca = pose_a.transform_point(shape_a.center)
        cb = pose_b.transform_point(shape_b.center)
        return max(0.0, float(np.linalg.norm(ca - cb)) - shape_a.radius - shape_b.radius)
    if family == "sphere_capsule":
        center = pose_a.transform_point(shape_a.center)
        a = pose_b.transform_point(shape_b.a)
        b = pose_b.transform_point(shape_b.b)
        return max(0.0, _point_segment_distance(center, a, b) - shape_a.radius - shape_b.radius)
    if family == "capsule_capsule":
        a0 = pose_a.transform_point(shape_a.a)
        a1 = pose_a.transform_point(shape_a.b)
        b0 = pose_b.transform_point(shape_b.a)
        b1 = pose_b.transform_point(shape_b.b)
        return max(0.0, _segment_segment_distance(a0, a1, b0, b1) - shape_a.radius - shape_b.radius)
    if family == "sphere_box":
        center_world = pose_a.transform_point(shape_a.center)
        local = pose_b.inverse_rotate_vector(center_world - pose_b.translation)
        nearest = np.minimum(np.maximum(local, shape_b.center - shape_b.half_extents), shape_b.center + shape_b.half_extents)
        return max(0.0, float(np.linalg.norm(local - nearest)) - shape_a.radius)
    raise AssertionError(family)


def static_gjk_analytic_benchmark(per_family: int = 600) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Check support-mapped GJK against exact primitive separation formulae."""
    rows: list[dict[str, Any]] = []
    families = ("sphere_sphere", "sphere_capsule", "capsule_capsule", "sphere_box")
    lower_violations = upper_violations = overlap_disagreements = unresolved = 0
    max_upper_error = max_lower_violation = max_upper_violation = max_gap = 0.0
    total_iterations = 0
    started = time.perf_counter()
    for family in families:
        for index in range(per_family):
            if family == "sphere_sphere":
                shape_a = Sphere(RNG.uniform(0.02, 1.0), RNG.normal(scale=0.2, size=3))
                shape_b = Sphere(RNG.uniform(0.02, 1.0), RNG.normal(scale=0.2, size=3))
            elif family == "sphere_capsule":
                shape_a = Sphere(RNG.uniform(0.02, 0.7), RNG.normal(scale=0.2, size=3))
                axis = RNG.normal(size=3); axis /= np.linalg.norm(axis)
                half = RNG.uniform(0.1, 1.5)
                shape_b = Capsule(-half * axis, half * axis, RNG.uniform(0.02, 0.5))
            elif family == "capsule_capsule":
                axis_a = RNG.normal(size=3); axis_a /= np.linalg.norm(axis_a)
                axis_b = RNG.normal(size=3); axis_b /= np.linalg.norm(axis_b)
                half_a, half_b = RNG.uniform(0.1, 1.5, size=2)
                shape_a = Capsule(-half_a * axis_a, half_a * axis_a, RNG.uniform(0.02, 0.5))
                shape_b = Capsule(-half_b * axis_b, half_b * axis_b, RNG.uniform(0.02, 0.5))
            else:
                shape_a = Sphere(RNG.uniform(0.02, 0.7), RNG.normal(scale=0.2, size=3))
                shape_b = Box(RNG.uniform(0.1, 1.2, size=3), RNG.normal(scale=0.1, size=3))
            pose_a = Pose(RNG.uniform(-1.0, 1.0, size=3), random_quaternion())
            # Every tenth case is deliberately close/overlapping; the rest cover broad separation.
            scale = RNG.uniform(0.0, 1.0) if index % 10 == 0 else RNG.uniform(1.0, 7.0)
            direction = RNG.normal(size=3); direction /= np.linalg.norm(direction)
            pose_b = Pose(pose_a.translation + scale * direction, random_quaternion())
            exact = _analytic_distance(family, shape_a, pose_a, shape_b, pose_b)
            gjk = gjk_distance(shape_a, pose_a, shape_b, pose_b)
            tolerance = 2e-8 * max(1.0, exact, gjk.upper_bound)
            lower_violation = max(0.0, gjk.lower_bound - exact)
            upper_violation = max(0.0, exact - gjk.upper_bound)
            lower_bad = lower_violation > tolerance
            upper_bad = upper_violation > tolerance
            lower_violations += int(lower_bad)
            upper_violations += int(upper_bad)
            exact_overlap = exact <= 2e-9
            gjk_overlap = gjk.intersect or gjk.upper_bound <= 2e-9
            overlap_disagreements += int(exact_overlap != gjk_overlap)
            unresolved += int(not (gjk.converged or gjk.intersect))
            upper_error = abs(gjk.upper_bound - exact)
            max_upper_error = max(max_upper_error, upper_error)
            max_lower_violation = max(max_lower_violation, lower_violation)
            max_upper_violation = max(max_upper_violation, upper_violation)
            max_gap = max(max_gap, gjk.bound_gap)
            total_iterations += gjk.iterations
            rows.append({
                "family": family,
                "index": index,
                "exact_distance": exact,
                "gjk_lower": gjk.lower_bound,
                "gjk_upper": gjk.upper_bound,
                "gjk_gap": gjk.bound_gap,
                "upper_absolute_error": upper_error,
                "lower_bound_violation": lower_violation,
                "upper_bound_violation": upper_violation,
                "lower_violation_over_tolerance": lower_bad,
                "upper_violation_over_tolerance": upper_bad,
                "exact_overlap": exact_overlap,
                "gjk_intersect": gjk.intersect,
                "gjk_converged": gjk.converged,
                "gjk_iterations": gjk.iterations,
                "gjk_termination": gjk.termination,
            })
    elapsed = time.perf_counter() - started
    count = len(rows)
    summary = {
        "queries": count,
        "queries_per_family": per_family,
        "families": list(families),
        "elapsed_seconds": elapsed,
        "queries_per_second": count / elapsed,
        "lower_bound_violations_over_tolerance": lower_violations,
        "upper_bound_violations_over_tolerance": upper_violations,
        "overlap_classification_disagreements": overlap_disagreements,
        "gjk_unresolved": unresolved,
        "max_upper_absolute_error": max_upper_error,
        "max_lower_bound_violation": max_lower_violation,
        "max_upper_bound_violation": max_upper_violation,
        "max_gjk_bound_gap": max_gap,
        "mean_gjk_iterations": total_iterations / count,
    }
    return summary, rows


def static_qp_crosscheck(count: int = 100) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Non-gating polytope cross-check against an independent numerical QP."""
    rows: list[dict[str, Any]] = []
    started = time.perf_counter()
    qp_failures = qp_above_feasible_witness = 0
    max_qp_minus_gjk_upper = max_gjk_upper_minus_qp = 0.0
    for case in range(count):
        shape_a = ConvexHull(RNG.normal(size=(RNG.integers(4, 9), 3)))
        shape_b = ConvexHull(RNG.normal(size=(RNG.integers(4, 9), 3)))
        pose_a = Pose(RNG.uniform(-1.0, 1.0, size=3), random_quaternion())
        direction = RNG.normal(size=3); direction /= np.linalg.norm(direction)
        pose_b = Pose(pose_a.translation + direction * RNG.uniform(0.5, 5.0), random_quaternion())
        qp, ok, nit, residual = independent_polytope_distance(vertices_world(shape_a, pose_a), vertices_world(shape_b, pose_b))
        gjk = gjk_distance(shape_a, pose_a, shape_b, pose_b)
        qp_minus_upper = qp - gjk.upper_bound
        upper_minus_qp = gjk.upper_bound - qp
        if qp_minus_upper > 2e-7 * max(1.0, qp, gjk.upper_bound):
            qp_above_feasible_witness += 1
        qp_failures += int(not ok)
        max_qp_minus_gjk_upper = max(max_qp_minus_gjk_upper, qp_minus_upper)
        max_gjk_upper_minus_qp = max(max_gjk_upper_minus_qp, upper_minus_qp)
        rows.append({"case": case, "qp_distance": qp, "qp_success": ok, "qp_iterations": nit,
                     "qp_equality_residual": residual, "gjk_lower": gjk.lower_bound,
                     "gjk_upper": gjk.upper_bound, "qp_minus_gjk_upper": qp_minus_upper,
                     "gjk_upper_minus_qp": upper_minus_qp})
    elapsed = time.perf_counter() - started
    return {
        "queries": count,
        "elapsed_seconds": elapsed,
        "qp_failures": qp_failures,
        "qp_results_above_known_feasible_gjk_witness": qp_above_feasible_witness,
        "max_qp_minus_gjk_upper": max_qp_minus_gjk_upper,
        "max_gjk_upper_minus_qp": max_gjk_upper_minus_qp,
        "interpretation": "diagnostic only; the numerical QP is not a release oracle when it returns above a known feasible GJK witness",
    }, rows


def _stationary_sphere(center: np.ndarray, radius: float, body_id: str = "b") -> MovingConvex:
    return MovingConvex(Sphere(radius), RigidMotion(Pose(center, quat_identity())), body_id)


def linear_sphere_benchmark(tunnelling: int = 800, general_hits: int = 300, misses: int = 300) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    false_negatives = false_positives = unresolved = 0
    max_lead = 0.0
    max_late = 0.0
    max_gjk_iterations = 0
    total_ca_iterations = 0
    endpoint_missed = 0
    t0 = time.perf_counter()

    cases: list[tuple[np.ndarray, np.ndarray, float, float, str]] = []
    for _ in range(tunnelling):
        ra, rb = RNG.uniform(0.05, 0.7, size=2)
        rsum = ra + rb
        half_path = RNG.uniform(rsum + 0.5, rsum + 8.0)
        transverse = RNG.uniform(-0.75 * rsum, 0.75 * rsum)
        p0 = np.array([-half_path, transverse, RNG.uniform(-0.1, 0.1)])
        velocity = np.array([2.0 * half_path, 0.0, 0.0])
        cases.append((p0, velocity, ra, rb, "tunnelling"))
    for _ in range(general_hits):
        ra, rb = RNG.uniform(0.05, 1.0, size=2)
        rsum = ra + rb
        p0 = RNG.normal(size=3)
        p0 /= np.linalg.norm(p0)
        p0 *= RNG.uniform(rsum + 0.1, rsum + 8.0)
        target = RNG.normal(scale=0.15 * rsum, size=3)
        velocity = target - p0
        velocity *= RNG.uniform(1.05, 2.0)
        cases.append((p0, velocity, ra, rb, "general_hit"))
    for _ in range(misses):
        ra, rb = RNG.uniform(0.05, 0.8, size=2)
        rsum = ra + rb
        half_path = RNG.uniform(rsum + 0.5, rsum + 8.0)
        transverse = RNG.choice([-1.0, 1.0]) * RNG.uniform(rsum + 0.25, rsum + 3.0)
        p0 = np.array([-half_path, transverse, RNG.uniform(-0.2, 0.2)])
        velocity = np.array([2.0 * half_path, 0.0, 0.0])
        cases.append((p0, velocity, ra, rb, "miss"))

    for case, (p0, velocity, ra, rb, category) in enumerate(cases):
        exact = sphere_sphere_linear(p0, velocity, ra, np.zeros(3), np.zeros(3), rb)
        body_a = MovingConvex(Sphere(ra), RigidMotion(Pose(p0, quat_identity()), velocity), "a")
        body_b = _stationary_sphere(np.zeros(3), rb)
        cert = conservative_advancement(body_a, body_b)
        actual_hit = exact.hit
        predicted_hit = cert.status in {CCDStatus.HIT, CCDStatus.INITIAL_OVERLAP}
        definitive = cert.status in {CCDStatus.HIT, CCDStatus.INITIAL_OVERLAP, CCDStatus.MISS}
        false_negatives += int(actual_hit and cert.status == CCDStatus.MISS)
        false_positives += int((not actual_hit) and predicted_hit)
        unresolved += int(not definitive)
        total_ca_iterations += cert.ca_iterations
        max_gjk_iterations = max(max_gjk_iterations, cert.gjk_iterations_total)
        lead = late = None
        if actual_hit and cert.toi_upper is not None and exact.time is not None:
            lead = max(0.0, exact.time - cert.toi_upper)
            late = max(0.0, cert.toi_upper - exact.time)
            max_lead = max(max_lead, lead)
            max_late = max(max_late, late)
        endpoint_only_hit = False
        rsum = ra + rb
        if np.linalg.norm(p0) <= rsum or np.linalg.norm(p0 + velocity) <= rsum:
            endpoint_only_hit = True
        if actual_hit and not endpoint_only_hit:
            endpoint_missed += 1
        rows.append(
            {
                "case": case,
                "category": category,
                "exact_hit": actual_hit,
                "exact_toi": exact.time,
                "status": cert.status.value,
                "toi_lower": cert.toi_lower,
                "toi_upper": cert.toi_upper,
                "lead_before_exact": lead,
                "late_after_exact": late,
                "ca_iterations": cert.ca_iterations,
                "gjk_iterations_total": cert.gjk_iterations_total,
                "termination": cert.termination,
                "endpoint_only_hit": endpoint_only_hit,
            }
        )
    elapsed = time.perf_counter() - t0
    summary = {
        "queries": len(cases),
        "elapsed_seconds": elapsed,
        "queries_per_second": len(cases) / elapsed,
        "exact_hits": sum(bool(row["exact_hit"]) for row in rows),
        "exact_misses": sum(not bool(row["exact_hit"]) for row in rows),
        "false_negatives": false_negatives,
        "false_positives": false_positives,
        "unresolved": unresolved,
        "endpoint_only_missed_hits": endpoint_missed,
        "max_contact_band_lead": max_lead,
        "max_late_after_exact": max_late,
        "mean_ca_iterations": total_ca_iterations / len(cases),
        "max_total_gjk_iterations_per_query": max_gjk_iterations,
    }
    return summary, rows


def orbiting_sphere_benchmark(hits: int = 300, misses: int = 200, overlaps: int = 50) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    false_negatives = false_positives = unresolved = oracle_failures = 0
    max_lead = max_late = 0.0
    total_ca_iterations = 0
    t0 = time.perf_counter()

    cases: list[dict[str, Any]] = []
    for i in range(hits):
        orbit_radius = RNG.uniform(0.7, 4.0)
        moving_radius = RNG.uniform(0.03, 0.25)
        fixed_radius = RNG.uniform(0.03, 0.25)
        omega = RNG.choice([-1.0, 1.0]) * RNG.uniform(1.0, 5.5)
        target_fraction = RNG.uniform(0.2, 0.8)
        angle = omega * target_fraction
        fixed_center = np.array([orbit_radius * math.cos(angle), orbit_radius * math.sin(angle), 0.0])
        cases.append({"category": "hit", "R": orbit_radius, "ra": moving_radius, "rb": fixed_radius, "omega": omega, "fixed": fixed_center})
    for i in range(misses):
        orbit_radius = RNG.uniform(0.7, 4.0)
        moving_radius = RNG.uniform(0.03, 0.25)
        fixed_radius = RNG.uniform(0.03, 0.25)
        omega = RNG.choice([-1.0, 1.0]) * RNG.uniform(1.0, 5.5)
        radial_gap = moving_radius + fixed_radius + RNG.uniform(0.2, 1.5)
        angle = RNG.uniform(-math.pi, math.pi)
        fixed_center = np.array([(orbit_radius + radial_gap) * math.cos(angle), (orbit_radius + radial_gap) * math.sin(angle), 0.0])
        cases.append({"category": "miss", "R": orbit_radius, "ra": moving_radius, "rb": fixed_radius, "omega": omega, "fixed": fixed_center})
    for i in range(overlaps):
        orbit_radius = RNG.uniform(0.7, 4.0)
        moving_radius = RNG.uniform(0.05, 0.25)
        fixed_radius = RNG.uniform(0.05, 0.25)
        omega = RNG.choice([-1.0, 1.0]) * RNG.uniform(1.0, 5.5)
        fixed_center = np.array([orbit_radius + RNG.uniform(-0.25, 0.25) * (moving_radius + fixed_radius), 0.0, 0.0])
        cases.append({"category": "initial_overlap", "R": orbit_radius, "ra": moving_radius, "rb": fixed_radius, "omega": omega, "fixed": fixed_center})

    for case, spec in enumerate(cases):
        local = np.array([spec["R"], 0.0, 0.0])
        exact = orbiting_sphere_fixed_sphere_toi(local, np.zeros(3), spec["omega"], spec["ra"], spec["fixed"], spec["rb"])
        actual_hit = exact is not None
        expected_by_construction = spec["category"] != "miss"
        oracle_failures += int(actual_hit != expected_by_construction)
        a = MovingConvex(
            Sphere(spec["ra"], local),
            RigidMotion(Pose.identity(), angular_velocity=np.array([0.0, 0.0, spec["omega"]])),
            "orbit",
        )
        b = _stationary_sphere(spec["fixed"], spec["rb"], "fixed")
        cert = conservative_advancement(a, b)
        predicted_hit = cert.status in {CCDStatus.HIT, CCDStatus.INITIAL_OVERLAP}
        definitive = cert.status in {CCDStatus.HIT, CCDStatus.INITIAL_OVERLAP, CCDStatus.MISS}
        false_negatives += int(actual_hit and cert.status == CCDStatus.MISS)
        false_positives += int((not actual_hit) and predicted_hit)
        unresolved += int(not definitive)
        total_ca_iterations += cert.ca_iterations
        lead = late = None
        if exact is not None and cert.toi_upper is not None:
            lead = max(0.0, exact - cert.toi_upper)
            late = max(0.0, cert.toi_upper - exact)
            max_lead = max(max_lead, lead)
            max_late = max(max_late, late)
        rows.append(
            {
                "case": case,
                "category": spec["category"],
                "orbit_radius": spec["R"],
                "angular_velocity": spec["omega"],
                "analytic_hit": actual_hit,
                "analytic_toi": exact,
                "status": cert.status.value,
                "toi_lower": cert.toi_lower,
                "toi_upper": cert.toi_upper,
                "lead_before_exact": lead,
                "late_after_exact": late,
                "ca_iterations": cert.ca_iterations,
                "gjk_iterations_total": cert.gjk_iterations_total,
                "termination": cert.termination,
            }
        )
    elapsed = time.perf_counter() - t0
    summary = {
        "queries": len(cases),
        "elapsed_seconds": elapsed,
        "queries_per_second": len(cases) / elapsed,
        "analytic_hits_or_initial_overlaps": sum(row["analytic_hit"] for row in rows),
        "analytic_misses": sum(not row["analytic_hit"] for row in rows),
        "construction_or_oracle_disagreements": oracle_failures,
        "false_negatives": false_negatives,
        "false_positives": false_positives,
        "unresolved": unresolved,
        "max_contact_band_lead": max_lead,
        "max_late_after_exact": max_late,
        "mean_ca_iterations": total_ca_iterations / len(cases),
    }
    return summary, rows


def brute_pairs(bodies: list[MovingConvex]) -> set[tuple[str, str]]:
    boxes = [body.swept_aabb() for body in bodies]
    pairs: set[tuple[str, str]] = set()
    for i in range(len(bodies)):
        lo_i, hi_i = boxes[i]
        for j in range(i + 1, len(bodies)):
            lo_j, hi_j = boxes[j]
            if np.all(lo_i <= hi_j) and np.all(lo_j <= hi_i):
                pairs.add(tuple(sorted((bodies[i].body_id, bodies[j].body_id))))
    return pairs


def bvh_benchmark(sizes: tuple[int, ...] = (100, 300, 1000, 2000)) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    disagreements = 0
    for count in sizes:
        bodies: list[MovingConvex] = []
        # Scale the domain with N to keep candidate density moderate.
        extent = 5.0 * (count / 100.0) ** (1.0 / 3.0)
        for i in range(count):
            radius = RNG.uniform(0.05, 0.22)
            center = RNG.uniform(-extent, extent, size=3)
            velocity = RNG.normal(scale=0.18, size=3)
            bodies.append(MovingConvex(Sphere(radius), RigidMotion(Pose(center, quat_identity()), velocity), f"body_{i:05d}"))
        start = time.perf_counter()
        result = SweptBVH(bodies, leaf_size=8).candidate_pairs(capacity=10_000_000)
        bvh_elapsed = time.perf_counter() - start
        brute_elapsed = None
        brute_count = None
        matches = None
        if count <= 300:
            start = time.perf_counter()
            reference = brute_pairs(bodies)
            brute_elapsed = time.perf_counter() - start
            brute_count = len(reference)
            matches = set(result.pairs) == reference
            disagreements += int(not matches)
        rows.append(
            {
                "bodies": count,
                "candidate_pairs": len(result.pairs),
                "tested_bvh_nodes": result.tested_aabbs,
                "bvh_seconds": bvh_elapsed,
                "bodies_per_second": count / bvh_elapsed,
                "brute_force_seconds": brute_elapsed,
                "brute_force_pairs": brute_count,
                "matches_brute_force": matches,
                "status": result.status.value,
            }
        )
    summary = {
        "scales": list(sizes),
        "brute_force_checked_scales": [n for n in sizes if n <= 300],
        "pair_set_disagreements": disagreements,
        "largest_body_count": max(sizes),
        "largest_scale_seconds": rows[-1]["bvh_seconds"],
        "largest_scale_candidate_pairs": rows[-1]["candidate_pairs"],
    }
    return summary, rows


def curated_certificates() -> list[dict[str, Any]]:
    config = CAConfig()
    cases: list[tuple[str, MovingConvex, MovingConvex, CAConfig]] = []
    cases.append((
        "linear_sphere_tunnelling",
        MovingConvex(Sphere(0.5), RigidMotion(Pose(np.array([-5.0, 0.0, 0.0]), quat_identity()), np.array([10.0, 0.0, 0.0])), "sphere_fast"),
        _stationary_sphere(np.zeros(3), 0.5, "sphere_fixed"),
        config,
    ))
    cases.append((
        "rotating_capsule_box",
        MovingConvex(Capsule(np.array([-1.0, 0.0, 0.0]), np.array([1.0, 0.0, 0.0]), 0.15),
                     RigidMotion(Pose.identity(), angular_velocity=np.array([0.0, 0.0, 2.4])), "capsule"),
        MovingConvex(Box(np.array([0.25, 0.25, 0.25])), RigidMotion(Pose(np.array([0.0, 1.0, 0.0]), quat_identity())), "box"),
        config,
    ))
    cases.append((
        "accelerating_hull_box",
        MovingConvex(ConvexHull(np.array([[-0.3, -0.2, 0.0], [0.4, -0.2, 0.0], [0.0, 0.4, 0.0], [0.0, 0.0, 0.5]])),
                     RigidMotion(Pose(np.array([-3.0, 0.0, 0.0]), quat_identity()), np.array([1.0, 0.0, 0.0]), np.array([8.0, 0.0, 0.0])), "hull"),
        MovingConvex(Box(np.array([0.4, 0.5, 0.5])), RigidMotion(Pose.identity()), "box"),
        config,
    ))
    cases.append((
        "rotating_box_miss",
        MovingConvex(Box(np.array([0.5, 0.25, 0.2]), np.array([1.0, 0.0, 0.0])),
                     RigidMotion(Pose.identity(), angular_velocity=np.array([0.0, 0.0, 1.5])), "rotating_box"),
        MovingConvex(Box(np.array([0.3, 0.3, 0.3])), RigidMotion(Pose(np.array([5.0, 5.0, 0.0]), quat_identity())), "remote_box"),
        config,
    ))
    cases.append((
        "forced_inconclusive_budget",
        MovingConvex(Sphere(1.0), RigidMotion(Pose(np.array([-3.0, 0.0, 0.0]), quat_identity()), np.array([6.0, 0.0, 0.0])), "a"),
        _stationary_sphere(np.zeros(3), 1.0, "b"),
        CAConfig(max_iterations=1),
    ))
    output = []
    for name, a, b, cfg in cases:
        cert = conservative_advancement(a, b, cfg)
        output.append({"name": name, "certificate": cert.to_dict(include_trace=True)})
    return output


def gjk_trace_vector() -> dict[str, Any]:
    a = Box(np.array([0.8, 0.4, 0.3]))
    b = ConvexHull(np.array([[-0.5, -0.3, -0.2], [0.6, -0.2, -0.1], [0.1, 0.7, -0.2], [0.0, 0.0, 0.8], [-0.2, 0.1, 0.3]]))
    pa = Pose(np.array([-0.2, 0.1, 0.0]), quat_from_rotation_vector(np.array([0.1, -0.2, 0.5])))
    pb = Pose(np.array([2.2, 0.6, 0.1]), quat_from_rotation_vector(np.array([-0.3, 0.4, 0.2])))
    result = gjk_distance(a, pa, b, pb, capture_trace=True)
    return {
        "shape_a": "box",
        "shape_b": "convex_hull",
        "result": {
            "distance": result.distance,
            "lower_bound": result.lower_bound,
            "upper_bound": result.upper_bound,
            "bound_gap": result.bound_gap,
            "iterations": result.iterations,
            "support_calls": result.support_calls,
            "converged": result.converged,
            "termination": result.termination,
            "trace": result.trace,
        },
    }


def main() -> int:
    global RNG
    started = time.time()
    # Each benchmark owns a stable derived seed.  This prevents a change in one
    # corpus generator from silently changing every later corpus and keeps each
    # stage independently reproducible.
    stages = [
        ("static GJK vs analytic primitives", static_gjk_analytic_benchmark, 0),
        ("diagnostic convex QP", static_qp_crosscheck, 1),
        ("linear sphere CCD", linear_sphere_benchmark, 2),
        ("orbiting sphere CCD", orbiting_sphere_benchmark, 3),
        ("swept BVH", bvh_benchmark, 4),
    ]
    outputs = []
    stage_seeds: dict[str, int] = {}
    for label, function, seed_offset in stages:
        stage_seed = SEED + seed_offset
        stage_seeds[label] = stage_seed
        RNG = np.random.default_rng(stage_seed)
        stage_start = time.perf_counter()
        print(f"[benchmark] start: {label} (seed={stage_seed})", flush=True)
        outputs.append(function())
        print(f"[benchmark] done:  {label} ({time.perf_counter() - stage_start:.3f} s)", flush=True)
    (static_summary, static_rows), (qp_summary, qp_rows), (linear_summary, linear_rows), (orbit_summary, orbit_rows), (bvh_summary, bvh_rows) = outputs
    certificates = curated_certificates()
    trace = gjk_trace_vector()

    write_csv(RESULTS / "static_gjk_analytic_cases.csv", static_rows)
    write_csv(RESULTS / "static_qp_crosscheck_cases.csv", qp_rows)
    write_csv(RESULTS / "linear_sphere_cases.csv", linear_rows)
    write_csv(RESULTS / "orbiting_sphere_cases.csv", orbit_rows)
    write_csv(RESULTS / "bvh_scaling.csv", bvh_rows)

    summary = {
        "schema_version": "nhdf-ccd-benchmark-summary-0.6.0",
        "release": "0.6.0",
        "seed_decimal": SEED,
        "seed_hex": hex(SEED),
        "stage_seeds": stage_seeds,
        "generated_unix_time": started,
        "environment": {
            "python": sys.version.split()[0],
            "numpy": np.__version__,
            "scipy": __import__("scipy").__version__,
            "platform": sys.platform,
            "cpu_count": os.cpu_count(),
        },
        "authoritative_checks": {
            "static_gjk_vs_analytic_primitives": static_summary,
            "linear_sphere_vs_analytic": linear_summary,
            "orbiting_sphere_vs_analytic": orbit_summary,
            "swept_bvh_vs_bruteforce": bvh_summary,
        },
        "diagnostic_crosschecks": {"polytope_qp": qp_summary},
        "scope_note": "Observed results on generated binary64 cases are not a proof over all real inputs.",
    }
    (RESULTS / "benchmark_summary.json").write_text(json.dumps(jsonable(summary), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    flattened = []
    for group, data in summary["authoritative_checks"].items():
        for metric, value in data.items():
            if isinstance(value, (str, int, float, bool)) or value is None:
                flattened.append({"group": group, "metric": metric, "value": value})
    write_csv(RESULTS / "benchmark_summary.csv", flattened)
    (RESULTS / "reference_certificates.json").write_text(json.dumps(jsonable(certificates), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (RESULTS / "gjk_bound_trace.json").write_text(json.dumps(jsonable(trace), indent=2, sort_keys=True) + "\n", encoding="utf-8")

    decisive_failures = {
        "static_lower_bound_violations": static_summary["lower_bound_violations_over_tolerance"],
        "static_upper_bound_violations": static_summary["upper_bound_violations_over_tolerance"],
        "linear_false_negatives": linear_summary["false_negatives"],
        "linear_false_positives": linear_summary["false_positives"],
        "orbit_false_negatives": orbit_summary["false_negatives"],
        "orbit_false_positives": orbit_summary["false_positives"],
        "bvh_pair_disagreements": bvh_summary["pair_set_disagreements"],
    }
    print(json.dumps({"summary": summary, "decisive_failures": decisive_failures}, indent=2, sort_keys=True))
    # Explicitly release large row collections before interpreter shutdown.  This
    # also avoids slow finalization observed with some NumPy/SciPy build mixes.
    del static_rows, qp_rows, linear_rows, orbit_rows, bvh_rows, outputs
    gc.collect()
    return 1 if any(decisive_failures.values()) else 0


if __name__ == "__main__":
    # Some containerized SciPy/BLAS builds can stall during interpreter finalization
    # after all benchmark artifacts have been written. Flush the public output and
    # terminate explicitly so the reproducible pipeline has a bounded completion
    # time. This does not bypass any benchmark stage or result check.
    exit_code = main()
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(exit_code)
