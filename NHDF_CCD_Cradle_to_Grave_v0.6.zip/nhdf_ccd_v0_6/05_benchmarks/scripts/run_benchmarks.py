#!/usr/bin/env python3
"""Deterministic NHDF-CCD v0.6 validation and benchmark harness.

The generated numbers are implementation observations for the declared distributions,
not universal proofs.  All random sources are seeded and every oracle is independent
of the support-mapped conservative-advancement implementation under test.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import platform
import sys
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np
from scipy.optimize import minimize

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "03_reference" / "python" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from nhdf_ccd_v06 import (  # noqa: E402
    AABB,
    CAConfig,
    CCDStatus,
    Capsule,
    ConvexHull,
    MovingConvex,
    Pose,
    RigidMotion,
    Sphere,
    SweptBVH,
    conservative_advancement,
    gjk_distance,
    quat_from_rotation_vector,
    quat_identity,
    sphere_capsule_linear,
    sphere_sphere_linear,
)
from nhdf_ccd_v06.oracles import orbiting_sphere_fixed_sphere_toi  # noqa: E402
from nhdf_ccd_v06.shapes import vertices_world  # noqa: E402

SEED = 0x4E484446  # ASCII-ish "NHDF"
CONFIG = CAConfig()
BAND = CONFIG.contact_tolerance + CONFIG.distance_error_budget


def unit_vector(rng: np.random.Generator) -> np.ndarray:
    v = rng.normal(size=3)
    n = float(np.linalg.norm(v))
    return v / (n if n > 1e-15 else 1.0)


def orthonormal_frame(rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    x = unit_vector(rng)
    temp = unit_vector(rng)
    y = temp - x * float(np.dot(temp, x))
    yn = float(np.linalg.norm(y))
    if yn <= 1e-12:
        temp = np.array([1.0, 0.0, 0.0]) if abs(x[0]) < 0.8 else np.array([0.0, 1.0, 0.0])
        y = temp - x * float(np.dot(temp, x))
        yn = float(np.linalg.norm(y))
    y /= yn
    z = np.cross(x, y)
    return x, y, z


def stationary(shape: Any, at: np.ndarray, body_id: str) -> MovingConvex:
    return MovingConvex(shape, RigidMotion(Pose(np.asarray(at, dtype=float), quat_identity())), body_id)


def digest_object(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def classify_ca(result, oracle_t: float | None, timing_tolerance: float = 2e-7) -> dict[str, Any]:
    observed_hit = result.status in (CCDStatus.HIT, CCDStatus.INITIAL_OVERLAP)
    expected_hit = oracle_t is not None
    error = None
    late = False
    if observed_hit and expected_hit and result.toi_upper is not None:
        error = float(result.toi_upper - oracle_t)
        late = error > timing_tolerance
    return {
        "expected_hit": expected_hit,
        "observed_hit": observed_hit,
        "false_negative": expected_hit and not observed_hit,
        "false_positive": observed_hit and not expected_hit,
        "inconclusive": result.status in (CCDStatus.INCONCLUSIVE, CCDStatus.NUMERICAL_FAILURE, CCDStatus.INVALID_INPUT),
        "late": late,
        "time_error": error,
        "status": result.status.value,
        "ca_iterations": result.ca_iterations,
        "gjk_iterations_total": result.gjk_iterations_total,
    }


def aggregate_ca(name: str, rows: list[dict[str, Any]], elapsed: float) -> dict[str, Any]:
    errors = np.array([r["time_error"] for r in rows if r["time_error"] is not None], dtype=float)
    ca_iters = np.array([r["ca_iterations"] for r in rows], dtype=float)
    gjk_iters = np.array([r["gjk_iterations_total"] for r in rows], dtype=float)
    return {
        "name": name,
        "queries": len(rows),
        "expected_hits": sum(bool(r["expected_hit"]) for r in rows),
        "expected_misses": sum(not bool(r["expected_hit"]) for r in rows),
        "observed_hits": sum(bool(r["observed_hit"]) for r in rows),
        "false_negatives": sum(bool(r["false_negative"]) for r in rows),
        "false_positives": sum(bool(r["false_positive"]) for r in rows),
        "inconclusive_or_numerical": sum(bool(r["inconclusive"]) for r in rows),
        "late_band_entries": sum(bool(r["late"]) for r in rows),
        "max_late_error": float(max(0.0, errors.max(initial=0.0))) if errors.size else None,
        "max_early_error": float(max(0.0, -errors.min(initial=0.0))) if errors.size else None,
        "mean_abs_time_error": float(np.mean(np.abs(errors))) if errors.size else None,
        "p99_abs_time_error": float(np.percentile(np.abs(errors), 99)) if errors.size else None,
        "mean_ca_iterations": float(ca_iters.mean()) if ca_iters.size else 0.0,
        "p99_ca_iterations": float(np.percentile(ca_iters, 99)) if ca_iters.size else 0.0,
        "mean_gjk_iterations_total": float(gjk_iters.mean()) if gjk_iters.size else 0.0,
        "elapsed_seconds": elapsed,
        "queries_per_second": len(rows) / elapsed if elapsed > 0.0 else None,
        "result_digest": digest_object(rows),
    }


def sphere_sphere_corpus(rng: np.random.Generator, n: int) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    start = time.perf_counter()
    for i in range(n):
        ra = float(rng.uniform(0.08, 1.2))
        rb = float(rng.uniform(0.08, 1.2))
        x_axis, y_axis, z_axis = orthonormal_frame(rng)
        speed = float(rng.uniform(0.8, 12.0))
        base_velocity = rng.uniform(-1.0, 1.0, size=3)
        band_radius = ra + rb + BAND
        should_hit = (i % 2) == 0
        if should_hit:
            lateral_y = float(rng.uniform(-0.75, 0.75) * band_radius)
            lateral_z_max = math.sqrt(max(0.0, (0.82 * band_radius) ** 2 - lateral_y * lateral_y))
            lateral_z = float(rng.uniform(-1.0, 1.0) * lateral_z_max)
            lateral = lateral_y * y_axis + lateral_z * z_axis
            axial_at_contact = math.sqrt(max(0.0, band_radius * band_radius - float(np.dot(lateral, lateral))))
            target_t = float(rng.uniform(0.04, 0.94))
            center_a = -(axial_at_contact + speed * target_t) * x_axis + lateral
        else:
            miss_offset = band_radius + float(rng.uniform(0.03, 1.5))
            lateral = miss_offset * y_axis
            center_a = -float(rng.uniform(0.5, 8.0)) * x_axis + lateral
        center_b = rng.uniform(-3.0, 3.0, size=3)
        center_a = center_a + center_b
        va = base_velocity + speed * x_axis
        vb = base_velocity
        oracle = sphere_sphere_linear(center_a, va, ra + BAND, center_b, vb, rb)
        a = MovingConvex(Sphere(ra), RigidMotion(Pose(center_a, quat_identity()), va), f"ssa_{i}")
        b = MovingConvex(Sphere(rb), RigidMotion(Pose(center_b, quat_identity()), vb), f"ssb_{i}")
        result = conservative_advancement(a, b, CONFIG)
        row = classify_ca(result, oracle.time if oracle.hit else None)
        row.update({"query": i, "oracle_time": oracle.time, "toi_upper": result.toi_upper})
        rows.append(row)
    elapsed = time.perf_counter() - start
    return aggregate_ca("sphere_sphere_linear_contact_band", rows, elapsed), rows


def sphere_capsule_corpus(rng: np.random.Generator, n: int) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    start = time.perf_counter()
    for i in range(n):
        rs = float(rng.uniform(0.05, 0.7))
        rc = float(rng.uniform(0.03, 0.45))
        half = float(rng.uniform(0.3, 2.5))
        speed = float(rng.uniform(0.8, 10.0))
        base_velocity = rng.uniform(-0.8, 0.8, size=3)
        # A local frame makes the corpus orientation-independent while retaining an exact oracle.
        x_axis, y_axis, z_axis = orthonormal_frame(rng)
        capsule_center = rng.uniform(-2.0, 2.0, size=3)
        a0 = capsule_center - half * y_axis
        b0 = capsule_center + half * y_axis
        combined = rs + rc + BAND
        should_hit = (i % 2) == 0
        axial = float(rng.uniform(-0.72, 0.72) * half)
        if should_hit:
            zoff = float(rng.uniform(-0.70, 0.70) * combined)
            axial_x = math.sqrt(max(0.0, combined * combined - zoff * zoff))
            target_t = float(rng.uniform(0.04, 0.94))
            sphere_center = capsule_center + axial * y_axis + zoff * z_axis - (axial_x + speed * target_t) * x_axis
        else:
            zoff = combined + float(rng.uniform(0.03, 1.4))
            sphere_center = capsule_center + axial * y_axis + zoff * z_axis - float(rng.uniform(0.2, 5.0)) * x_axis
        sphere_velocity = base_velocity + speed * x_axis
        capsule_velocity = base_velocity
        oracle = sphere_capsule_linear(
            sphere_center,
            sphere_velocity,
            rs + BAND,
            a0,
            b0,
            capsule_velocity,
            rc,
        )
        # Put the capsule endpoints in world coordinates as local vertices with identity pose.
        sphere = MovingConvex(Sphere(rs), RigidMotion(Pose(sphere_center, quat_identity()), sphere_velocity), f"sca_{i}")
        capsule = MovingConvex(Capsule(a0, b0, rc), RigidMotion(Pose.identity(), capsule_velocity), f"scb_{i}")
        result = conservative_advancement(sphere, capsule, CONFIG)
        row = classify_ca(result, oracle.time if oracle.hit else None)
        row.update({"query": i, "oracle_time": oracle.time, "toi_upper": result.toi_upper, "oracle_feature": oracle.feature_b})
        rows.append(row)
    elapsed = time.perf_counter() - start
    return aggregate_ca("sphere_capsule_linear_contact_band", rows, elapsed), rows


def orbit_corpus(rng: np.random.Generator, n: int) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    start = time.perf_counter()
    for i in range(n):
        orbit_radius = float(rng.uniform(0.8, 3.0))
        moving_radius = float(rng.uniform(0.03, 0.25))
        fixed_radius = float(rng.uniform(0.03, 0.25))
        omega = float(rng.uniform(0.7, 2.6))
        origin = rng.uniform(-1.0, 1.0, size=3)
        local = np.array([orbit_radius, 0.0, 0.0])
        should_hit = (i % 2) == 0
        if should_hit:
            band_sum = moving_radius + fixed_radius + BAND
            alpha = 2.0 * math.asin(min(0.95, band_sum / (2.0 * orbit_radius)))
            target_t = float(rng.uniform(0.05, 0.70))
            angle = omega * target_t + alpha
            # Keep first contact in the forward arc and away from wraparound.
            if angle > math.pi - 0.1:
                omega = max(0.7, (math.pi - 0.2 - alpha) / target_t)
                angle = omega * target_t + alpha
            fixed_center = origin + orbit_radius * np.array([math.cos(angle), math.sin(angle), 0.0])
        else:
            radial = orbit_radius + moving_radius + fixed_radius + BAND + float(rng.uniform(0.05, 1.2))
            angle = float(rng.uniform(0.0, 2.0 * math.pi))
            fixed_center = origin + radial * np.array([math.cos(angle), math.sin(angle), 0.0])
        oracle_t = orbiting_sphere_fixed_sphere_toi(local, origin, omega, moving_radius + BAND, fixed_center, fixed_radius)
        moving = MovingConvex(
            Sphere(moving_radius, local),
            RigidMotion(Pose(origin, quat_identity()), angular_velocity=np.array([0.0, 0.0, omega])),
            f"oa_{i}",
        )
        fixed = stationary(Sphere(fixed_radius), fixed_center, f"ob_{i}")
        result = conservative_advancement(moving, fixed, CONFIG)
        row = classify_ca(result, oracle_t)
        row.update({"query": i, "oracle_time": oracle_t, "toi_upper": result.toi_upper})
        rows.append(row)
    elapsed = time.perf_counter() - start
    return aggregate_ca("rotating_offset_sphere_contact_band", rows, elapsed), rows


def polytope_qp_distance(a: np.ndarray, b: np.ndarray) -> tuple[float, bool, int]:
    m, n = len(a), len(b)
    x0 = np.concatenate([np.full(m, 1.0 / m), np.full(n, 1.0 / n)])

    def objective(x: np.ndarray) -> float:
        d = x[:m] @ a - x[m:] @ b
        return float(np.dot(d, d))

    constraints = [
        {"type": "eq", "fun": lambda x, m=m: float(np.sum(x[:m]) - 1.0)},
        {"type": "eq", "fun": lambda x, m=m: float(np.sum(x[m:]) - 1.0)},
    ]
    result = minimize(
        objective,
        x0,
        method="SLSQP",
        bounds=[(0.0, None)] * (m + n),
        constraints=constraints,
        options={"ftol": 1e-14, "maxiter": 1200, "disp": False},
    )
    return math.sqrt(max(0.0, objective(result.x))), bool(result.success), int(result.nit)


def gjk_qp_corpus(rng: np.random.Generator, n: int) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    start = time.perf_counter()
    for i in range(n):
        na = int(rng.integers(4, 11))
        nb = int(rng.integers(4, 11))
        va = rng.normal(size=(na, 3)) * rng.uniform(0.2, 1.2)
        vb = rng.normal(size=(nb, 3)) * rng.uniform(0.2, 1.2)
        ta = rng.uniform(-1.0, 1.0, size=3)
        separation_scale = 0.4 if i % 3 == 0 else 2.8
        tb = ta + rng.normal(size=3) * separation_scale
        qa = quat_from_rotation_vector(unit_vector(rng) * float(rng.uniform(-math.pi, math.pi)))
        qb = quat_from_rotation_vector(unit_vector(rng) * float(rng.uniform(-math.pi, math.pi)))
        shape_a = ConvexHull(va)
        shape_b = ConvexHull(vb)
        pose_a = Pose(ta, qa)
        pose_b = Pose(tb, qb)
        gjk = gjk_distance(shape_a, pose_a, shape_b, pose_b, max_iterations=128)
        world_a = vertices_world(shape_a, pose_a)
        world_b = vertices_world(shape_b, pose_b)
        oracle, success, qp_iters = polytope_qp_distance(world_a, world_b)
        tolerance = 2e-7 + 2e-7 * max(1.0, oracle)
        violation = max(0.0, gjk.lower_bound - oracle, oracle - gjk.upper_bound)
        rows.append(
            {
                "query": i,
                "oracle_distance": oracle,
                "qp_success": success,
                "qp_iterations": qp_iters,
                "lower_bound": gjk.lower_bound,
                "upper_bound": gjk.upper_bound,
                "bound_gap": gjk.bound_gap,
                "bound_violation": violation,
                "violates_tolerance": violation > tolerance,
                "gjk_converged": gjk.converged,
                "gjk_intersect": gjk.intersect,
                "gjk_iterations": gjk.iterations,
                "termination": gjk.termination,
            }
        )
    elapsed = time.perf_counter() - start
    violations = [r["bound_violation"] for r in rows]
    upper_errors = [max(0.0, r["upper_bound"] - r["oracle_distance"]) for r in rows]
    return {
        "name": "gjk_bounds_vs_independent_slsqp_qp",
        "queries": n,
        "qp_failures": sum(not r["qp_success"] for r in rows),
        "gjk_nonconvergence": sum(not r["gjk_converged"] and not r["gjk_intersect"] for r in rows),
        "bound_violations_over_tolerance": sum(r["violates_tolerance"] for r in rows),
        "max_raw_bound_violation": float(max(violations, default=0.0)),
        "max_upper_bound_excess": float(max(upper_errors, default=0.0)),
        "mean_bound_gap": float(np.mean([r["bound_gap"] for r in rows])),
        "p99_bound_gap": float(np.percentile([r["bound_gap"] for r in rows], 99)),
        "elapsed_seconds": elapsed,
        "queries_per_second": n / elapsed,
        "result_digest": digest_object(rows),
    }, rows


def bvh_corpus(rng: np.random.Generator, n: int) -> dict[str, Any]:
    bodies: list[MovingConvex] = []
    for i in range(n):
        radius = float(rng.uniform(0.05, 0.35))
        position = rng.uniform(-12.0, 12.0, size=3)
        velocity = rng.uniform(-1.8, 1.8, size=3)
        acceleration = rng.uniform(-0.2, 0.2, size=3)
        bodies.append(MovingConvex(Sphere(radius), RigidMotion(Pose(position, quat_identity()), velocity, acceleration), f"body_{i:05d}"))

    start = time.perf_counter()
    bvh = SweptBVH(bodies, leaf_size=4)
    result = bvh.candidate_pairs(capacity=n * n)
    bvh_elapsed = time.perf_counter() - start

    start = time.perf_counter()
    aabbs = [AABB(*body.swept_aabb()) for body in bodies]
    brute: list[tuple[str, str]] = []
    for i in range(n):
        for j in range(i + 1, n):
            if aabbs[i].overlaps(aabbs[j]):
                brute.append((bodies[i].body_id, bodies[j].body_id))
    brute_elapsed = time.perf_counter() - start
    expected = tuple(sorted(brute))
    observed = tuple(result.pairs)
    cap = max(0, len(expected) // 4)
    exhausted = bvh.candidate_pairs(capacity=cap)
    rerun = SweptBVH(bodies, leaf_size=4).candidate_pairs(capacity=n * n)
    return {
        "name": "deterministic_swept_aabb_bvh",
        "bodies": n,
        "candidate_pairs": len(observed),
        "brute_force_pairs": len(expected),
        "pair_set_equal": observed == expected,
        "missing_pairs": len(set(expected) - set(observed)),
        "extra_pairs": len(set(observed) - set(expected)),
        "tested_bvh_nodes": result.tested_aabbs,
        "bvh_seconds": bvh_elapsed,
        "brute_force_seconds": brute_elapsed,
        "speedup_vs_python_bruteforce": brute_elapsed / bvh_elapsed if bvh_elapsed else None,
        "deterministic_rerun_equal": rerun.pairs == observed,
        "pair_digest": digest_object(observed),
        "capacity_injection": {
            "capacity": cap,
            "status": exhausted.status.value,
            "returned_pairs": len(exhausted.pairs),
            "termination": exhausted.termination,
        },
    }


def tunnelling_corpus(rng: np.random.Generator, n: int) -> dict[str, Any]:
    exact_hits = 0
    endpoint_misses = 0
    ca_recovered = 0
    ca_failures = 0
    start = time.perf_counter()
    for i in range(n):
        ra = float(rng.uniform(0.03, 0.4))
        rb = float(rng.uniform(0.03, 0.4))
        total = ra + rb
        speed = float(rng.uniform(4.0, 30.0))
        t_hit = float(rng.uniform(0.10, 0.45))
        start_x = -(total + speed * t_hit)
        a0 = np.array([start_x, 0.0, 0.0])
        va = np.array([speed, 0.0, 0.0])
        b0 = np.zeros(3)
        exact = sphere_sphere_linear(a0, va, ra, b0, np.zeros(3), rb)
        if exact.hit:
            exact_hits += 1
        endpoint_overlap = np.linalg.norm(a0 - b0) <= total or np.linalg.norm((a0 + va) - b0) <= total
        if exact.hit and not endpoint_overlap:
            endpoint_misses += 1
        result = conservative_advancement(
            MovingConvex(Sphere(ra), RigidMotion(Pose(a0, quat_identity()), va), f"ta_{i}"),
            stationary(Sphere(rb), b0, f"tb_{i}"),
            CONFIG,
        )
        if result.status in (CCDStatus.HIT, CCDStatus.INITIAL_OVERLAP):
            ca_recovered += 1
        else:
            ca_failures += 1
    elapsed = time.perf_counter() - start
    return {
        "name": "endpoint_tunnelling_recovery",
        "queries": n,
        "exact_hits": exact_hits,
        "endpoint_only_missed_hits": endpoint_misses,
        "ccd_recovered_hits": ca_recovered,
        "ccd_failures": ca_failures,
        "elapsed_seconds": elapsed,
        "queries_per_second": n / elapsed,
    }


def write_rows(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    keys = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def make_figures(results: dict[str, Any], all_rows: dict[str, list[dict[str, Any]]], out_dir: Path) -> None:
    import matplotlib.pyplot as plt

    out_dir.mkdir(parents=True, exist_ok=True)
    ca_results = results["conservative_advancement"]
    labels = [r["name"].replace("_contact_band", "").replace("_", "\n") for r in ca_results]
    qps = [r["queries_per_second"] for r in ca_results]
    fig, ax = plt.subplots(figsize=(9, 5.2))
    bars = ax.bar(labels, qps)
    ax.set_ylabel("Queries per second (single Python process)")
    ax.set_title("NHDF-CCD v0.6 conservative-advancement throughput")
    ax.grid(axis="y", alpha=0.25)
    for bar, value in zip(bars, qps):
        ax.text(bar.get_x() + bar.get_width() / 2, value, f"{value:,.0f}", ha="center", va="bottom", fontsize=8)
    fig.tight_layout()
    fig.savefig(out_dir / "ca_throughput.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(9, 5.2))
    data = []
    names = []
    for key, rows in all_rows.items():
        errors = [-float(r["time_error"]) for r in rows if r.get("time_error") is not None]
        if errors:
            data.append(errors)
            names.append(key.replace("_", " "))
    ax.boxplot(data, tick_labels=names, showfliers=False)
    ax.set_yscale("log")
    ax.set_ylabel("Conservative lead before oracle band entry")
    ax.set_title("Contact-band timing conservatism (lower is tighter)")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(out_dir / "ca_timing_error.png", dpi=180)
    plt.close(fig)

    outcome_labels = ["False negatives", "False positives", "Inconclusive", "Late entries"]
    matrix = np.array([
        [r["false_negatives"], r["false_positives"], r["inconclusive_or_numerical"], r["late_band_entries"]]
        for r in ca_results
    ])
    fig, ax = plt.subplots(figsize=(9, 5.2))
    x = np.arange(len(labels))
    width = 0.18
    for j, outcome in enumerate(outcome_labels):
        ax.bar(x + (j - 1.5) * width, matrix[:, j], width, label=outcome)
    ax.set_xticks(x, labels)
    ax.set_ylabel("Observed count")
    ax.set_title("Fail-closed validation outcomes")
    ax.legend()
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(out_dir / "ca_outcomes.png", dpi=180)
    plt.close(fig)

    bvh = results["broad_phase"]
    fig, ax = plt.subplots(figsize=(7.5, 4.8))
    labels2 = ["BVH", "Brute force"]
    values = [bvh["bvh_seconds"], bvh["brute_force_seconds"]]
    bars = ax.bar(labels2, values)
    ax.set_ylabel("Wall time (seconds)")
    ax.set_title(f"Swept-AABB broad phase ({bvh['bodies']:,} bodies)")
    ax.grid(axis="y", alpha=0.25)
    for bar, value in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, value, f"{value:.3f}", ha="center", va="bottom")
    fig.tight_layout()
    fig.savefig(out_dir / "bvh_wall_time.png", dpi=180)
    plt.close(fig)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scale", type=float, default=1.0, help="Scale query counts for quick smoke runs")
    parser.add_argument("--results", type=Path, default=ROOT / "05_benchmarks" / "results")
    parser.add_argument("--figures", type=Path, default=ROOT / "05_benchmarks" / "figures")
    args = parser.parse_args()
    rng = np.random.default_rng(SEED)
    counts = {
        "sphere_sphere": max(20, int(2000 * args.scale)),
        "sphere_capsule": max(20, int(150 * args.scale)),
        "orbit": max(20, int(750 * args.scale)),
        "gjk_qp": max(20, int(250 * args.scale)),
        "bvh": max(50, int(800 * args.scale)),
        "tunnelling": max(20, int(2500 * args.scale)),
    }
    args.results.mkdir(parents=True, exist_ok=True)

    ss_summary, ss_rows = sphere_sphere_corpus(rng, counts["sphere_sphere"])
    sc_summary, sc_rows = sphere_capsule_corpus(rng, counts["sphere_capsule"])
    orbit_summary, orbit_rows = orbit_corpus(rng, counts["orbit"])
    gjk_summary, gjk_rows = gjk_qp_corpus(rng, counts["gjk_qp"])
    broad = bvh_corpus(rng, counts["bvh"])
    tunnelling = tunnelling_corpus(rng, counts["tunnelling"])

    write_rows(args.results / "sphere_sphere.csv", ss_rows)
    write_rows(args.results / "sphere_capsule.csv", sc_rows)
    write_rows(args.results / "rotating_orbit.csv", orbit_rows)
    write_rows(args.results / "gjk_qp.csv", gjk_rows)

    summary = {
        "schema_version": "nhdf-ccd-benchmark-0.6.0",
        "release": "NHDF-CCD v0.6.0",
        "seed": SEED,
        "contact_tolerance": CONFIG.contact_tolerance,
        "distance_error_budget": CONFIG.distance_error_budget,
        "contact_band": BAND,
        "query_counts": counts,
        "environment": {
            "python": sys.version.split()[0],
            "numpy": np.__version__,
            "platform": platform.platform(),
            "processor": platform.processor(),
        },
        "conservative_advancement": [ss_summary, sc_summary, orbit_summary],
        "gjk": gjk_summary,
        "broad_phase": broad,
        "tunnelling": tunnelling,
    }
    summary["all_validation_checks_pass"] = bool(
        all(r["false_negatives"] == 0 and r["false_positives"] == 0 and r["inconclusive_or_numerical"] == 0 and r["late_band_entries"] == 0 for r in summary["conservative_advancement"])
        and gjk_summary["bound_violations_over_tolerance"] == 0
        and gjk_summary["qp_failures"] == 0
        and broad["pair_set_equal"]
        and broad["missing_pairs"] == 0
        and broad["deterministic_rerun_equal"]
        and broad["capacity_injection"]["status"] == CCDStatus.RESOURCE_EXHAUSTED.value
        and tunnelling["ccd_failures"] == 0
    )
    summary["summary_digest"] = digest_object(summary)
    (args.results / "benchmark_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    make_figures(summary, {"sphere sphere": ss_rows, "sphere capsule": sc_rows, "rotating orbit": orbit_rows}, args.figures)
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0 if summary["all_validation_checks_pass"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
