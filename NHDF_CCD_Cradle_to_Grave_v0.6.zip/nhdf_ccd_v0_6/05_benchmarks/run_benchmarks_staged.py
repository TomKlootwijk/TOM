#!/usr/bin/env python3
"""Bounded staged benchmark runner for NHDF-CCD v0.6.

Each corpus runs in a fresh process with a stable derived seed.  This avoids
cross-stage RNG coupling and bounds interpreter/library finalization behavior in
containerized SciPy/BLAS environments.  The assembled output has the same public
summary shape as the monolithic reference runner.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RESULTS = HERE / "results"
STAGES = RESULTS / "stages"
RESULTS.mkdir(parents=True, exist_ok=True)
STAGES.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(HERE))
import run_benchmarks as core  # noqa: E402

STAGE_TABLE = {
    "static": ("static GJK vs analytic primitives", core.static_gjk_analytic_benchmark, 0, "static_gjk_analytic_cases.csv"),
    "qp": ("diagnostic convex QP", core.static_qp_crosscheck, 1, "static_qp_crosscheck_cases.csv"),
    "linear": ("linear sphere CCD", core.linear_sphere_benchmark, 2, "linear_sphere_cases.csv"),
    "orbit": ("orbiting sphere CCD", core.orbiting_sphere_benchmark, 3, "orbiting_sphere_cases.csv"),
    "bvh": ("swept BVH", core.bvh_benchmark, 4, "bvh_scaling.csv"),
}


def _write_stage(name: str) -> int:
    label, function, offset, csv_name = STAGE_TABLE[name]
    stage_seed = core.SEED + offset
    core.RNG = np.random.default_rng(stage_seed)
    started = time.time()
    wall = time.perf_counter()
    print(f"[stage] start: {name} - {label} (seed={stage_seed})", flush=True)
    summary, rows = function()
    elapsed = time.perf_counter() - wall
    core.write_csv(RESULTS / csv_name, rows)
    record = {
        "schema_version": "nhdf-ccd-benchmark-stage-0.6.0",
        "stage": name,
        "label": label,
        "seed": stage_seed,
        "generated_unix_time": started,
        "wall_seconds": elapsed,
        "summary": core.jsonable(summary),
        "row_count": len(rows),
        "csv": csv_name,
    }
    (STAGES / f"{name}.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(record, indent=2, sort_keys=True), flush=True)
    sys.stdout.flush()
    sys.stderr.flush()
    # The result files and checks are complete.  Explicit exit keeps completion
    # bounded on environments whose numerical-library finalizers can stall.
    os._exit(0)


def _read(name: str) -> dict:
    return json.loads((STAGES / f"{name}.json").read_text(encoding="utf-8"))


def _assemble() -> int:
    records = {name: _read(name) for name in STAGE_TABLE}
    static_summary = records["static"]["summary"]
    qp_summary = records["qp"]["summary"]
    linear_summary = records["linear"]["summary"]
    orbit_summary = records["orbit"]["summary"]
    bvh_summary = records["bvh"]["summary"]

    certificates = core.curated_certificates()
    trace = core.gjk_trace_vector()
    (RESULTS / "reference_certificates.json").write_text(
        json.dumps(core.jsonable(certificates), indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (RESULTS / "gjk_bound_trace.json").write_text(
        json.dumps(core.jsonable(trace), indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    summary = {
        "schema_version": "nhdf-ccd-benchmark-summary-0.6.0",
        "release": "0.6.0",
        "seed_decimal": core.SEED,
        "seed_hex": hex(core.SEED),
        "stage_seeds": {records[name]["label"]: records[name]["seed"] for name in STAGE_TABLE},
        "generated_unix_time": time.time(),
        "environment": {
            "python": sys.version.split()[0],
            "numpy": np.__version__,
            "scipy": __import__("scipy").__version__,
            "platform": sys.platform,
            "cpu_count": os.cpu_count(),
        },
        "authoritative_checks": {
            "static_gjk_vs_analytic_primitives": static_summary,
            "linear_sphere_vs_analytic": linear_summary,
            "orbiting_sphere_vs_analytic": orbit_summary,
            "swept_bvh_vs_bruteforce": bvh_summary,
        },
        "diagnostic_crosschecks": {"polytope_qp": qp_summary},
        "scope_note": "Observed results on generated binary64 cases are not a proof over all real inputs.",
        "runner": "staged fresh-process runner",
    }
    (RESULTS / "benchmark_summary.json").write_text(
        json.dumps(core.jsonable(summary), indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    flattened = []
    for group, data in summary["authoritative_checks"].items():
        for metric, value in data.items():
            if isinstance(value, (str, int, float, bool)) or value is None:
                flattened.append({"group": group, "metric": metric, "value": value})
    core.write_csv(RESULTS / "benchmark_summary.csv", flattened)

    decisive_failures = {
        "static_lower_bound_violations": static_summary["lower_bound_violations_over_tolerance"],
        "static_upper_bound_violations": static_summary["upper_bound_violations_over_tolerance"],
        "linear_false_negatives": linear_summary["false_negatives"],
        "linear_false_positives": linear_summary["false_positives"],
        "linear_unresolved": linear_summary["unresolved"],
        "orbit_false_negatives": orbit_summary["false_negatives"],
        "orbit_false_positives": orbit_summary["false_positives"],
        "orbit_unresolved": orbit_summary["unresolved"],
        "bvh_pair_disagreements": bvh_summary["pair_set_disagreements"],
    }
    result = {"summary": summary, "decisive_failures": decisive_failures}
    (RESULTS / "benchmark_decision.json").write_text(
        json.dumps(core.jsonable(result), indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(core.jsonable(result), indent=2, sort_keys=True), flush=True)
    return 1 if any(decisive_failures.values()) else 0


def _all() -> int:
    for name in STAGE_TABLE:
        subprocess.run([sys.executable, str(Path(__file__).resolve()), "--stage", name], check=True)
    subprocess.run([sys.executable, str(Path(__file__).resolve()), "--stage", "assemble"], check=True)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=[*STAGE_TABLE, "assemble", "all"], default="all")
    args = parser.parse_args()
    if args.stage in STAGE_TABLE:
        return _write_stage(args.stage)
    if args.stage == "assemble":
        return _assemble()
    return _all()


if __name__ == "__main__":
    raise SystemExit(main())
