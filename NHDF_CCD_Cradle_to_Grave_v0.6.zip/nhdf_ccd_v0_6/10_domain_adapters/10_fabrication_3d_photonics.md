# Fabrication and 3D photonics

**Current level:** A0

**CCD relation:** CCD can validate geometric tool paths and printed/etched clearance; photonic computing requires its own design.

**Next falsifiable experiment:** Run process-design-kit DRC, optical simulation, tolerance analysis and fabricated test coupons.

**Forbidden transfer:**
- Curvilinear coordinates do not bypass manufacturing tolerances or fabs by themselves.
