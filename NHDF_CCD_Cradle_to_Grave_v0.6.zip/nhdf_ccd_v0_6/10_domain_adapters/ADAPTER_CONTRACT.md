# Independent adapter qualification contract

CCD validation does not transfer across domains. Every adapter advances independently:

- **A0 - terminology:** analogous words only;
- **A1 - formal map:** typed state, units, dynamics, measurement and residual;
- **A2 - simulation:** reproducible comparison with accepted domain equations;
- **A3 - component experiment:** calibrated hardware/biological/chemical measurement;
- **A4 - system demonstration:** end-to-end task under representative conditions;
- **A5 - independent replication:** external team reproduces the claim.

An adapter must declare what CCD contributes, what constitutive laws remain external,
what experiment could falsify the map and which conclusions are forbidden. No A-level
is inherited from the CCD core.
