# GPU and edge AI

**Current level:** A1

**CCD relation:** Bounded queues, structure-of-arrays and certificate-preserving kernels are directly relevant; model compression is separate.

**Next falsifiable experiment:** Compile and execute CUDA, compare every status/interval against CPU, then benchmark power/memory/performance.

**Forbidden transfer:**
- Tensor cores do not implement parity/topology automatically.
- No weight-compression claim from CCD.
