# A0-A5 adapter qualification protocol

Using the same symbols in another domain does not transfer CCD validation to that domain.

- **A0 terminology:** analogy or proposed vocabulary only.
- **A1 formal map:** typed state, governing equations, units, encoder/decoder, and failure semantics.
- **A2 simulation:** reproducible numerical comparison with accepted domain models.
- **A3 component experiment:** calibrated physical component demonstrates the mapped operator.
- **A4 system demonstration:** integrated system meets declared performance and safety criteria.
- **A5 independent replication:** external group reproduces the result.

Every adapter must declare the domain state space, accepted evolution law, NHDF encoder/decoder, observable, uncertainty, invariants, baseline, falsification threshold, and hard boundary against unsupported inference.
