# Optical and photonic systems

**Current level:** A1

**CCD relation:** An optical stage may approximate support/projection or distance transforms.

**Next falsifiable experiment:** Build one calibrated operator-equivalence experiment and report transfer error, drift, bandwidth, energy and recalibration.

**Forbidden transfer:**
- No passive perfect correction or zero-power claim.
