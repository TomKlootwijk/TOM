# Cosmology and holography

**Current level:** A0

**CCD relation:** Only terminology and boundary/projection analogies are presently shared.

**Next falsifiable experiment:** Specify an actual bulk theory, boundary theory and observable correspondence before any duality claim.

**Forbidden transfer:**
- An SDF boundary is not evidence of the holographic principle.
