# Chemical reaction networks

**Current level:** A0

**CCD relation:** Event detection and bounded graph routing may wrap a reaction-network controller.

**Next falsifiable experiment:** Retain stoichiometric ODEs, kinetics and thermodynamics; compare a coded controller in simulation and chemical experiment.

**Forbidden transfer:**
- Parity is not a universal chemical conservation law.
