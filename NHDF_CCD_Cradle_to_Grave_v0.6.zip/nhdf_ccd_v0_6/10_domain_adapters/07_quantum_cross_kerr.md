# Quantum and Cross-Kerr hypotheses

**Current level:** A0

**CCD relation:** Photon-number parity and conditional phase are distinct possible laboratory operators.

**Next falsifiable experiment:** Specify Hamiltonian/channel, encoding, loss/noise, preparation, measurement and classical baseline; test a component.

**Forbidden transfer:**
- No claim that tissue or generic optics implements a quantum parity gate.
