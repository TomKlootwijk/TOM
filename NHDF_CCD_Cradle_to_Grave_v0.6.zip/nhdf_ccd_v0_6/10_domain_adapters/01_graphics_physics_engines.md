# Graphics and physics engines

**Current level:** A2

**CCD relation:** Use rigid-convex activation certificates as one narrow-phase backend; retain v0.5 for triangle features.

**Next falsifiable experiment:** Integrate into an open renderer/engine, run public CCD corpora and compare misses, false events, activation error, time and memory with established backends.

**Forbidden transfer:**
- Do not call detection a complete response solver.
