# SAR and wave sensing

**Current level:** A0

**CCD relation:** Swept-support and bounded-search ideas may inspire aperture support or hypothesis scheduling.

**Next falsifiable experiment:** Specify a complex-valued forward model, disturbance dataset and autofocus baseline; measure phase/error and image metrics.

**Forbidden transfer:**
- Collision validation does not imply SAR focus improvement.
