# Robotics and public safety

**Current level:** A0

**CCD relation:** Potential geometric safety layer for robot links, vehicles and obstacles.

**Next falsifiable experiment:** Shadow-mode simulation with calibrated uncertainty, latency and fail-safe behavior before any control authority.

**Forbidden transfer:**
- No autonomous enforcement or use-of-force decisions.
- No evidentiary cryptographic claim.
