# Biology and medicine

**Current level:** A0

**CCD relation:** CCD may be used in biomechanics/imaging simulation only; wider morphogenetic mappings are hypotheses.

**Next falsifiable experiment:** Define a non-therapeutic model, biological mechanism, calibrated data and preclinical validation path.

**Forbidden transfer:**
- No diagnosis, treatment, regeneration or dementia-reversal claim.
- No human application from this release.
