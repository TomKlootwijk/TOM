# Measurement, sensors and actuators

**Current level:** A1

**CCD relation:** CCD may bound geometric contact between calibrated moving components; NHDF can be an interface model.

**Next falsifiable experiment:** Define units, calibration, uncertainty and transduction for one instrument; compare predicted contact with traceable measurement.

**Forbidden transfer:**
- Do not treat representation as a universal transducer law.
