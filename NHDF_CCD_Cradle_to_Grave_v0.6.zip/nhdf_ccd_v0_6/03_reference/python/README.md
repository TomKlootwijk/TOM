# Python reference

The package is intentionally readable rather than optimized. NumPy supplies vector
and small linear algebra operations. `gjk.py` examines all active simplex subsets
(up to four points in 3D) to make degeneracy handling auditable. `ccd.py` threads
GJK lower/upper bounds into conservative advancement. `bvh.py` provides a bounded,
deterministic swept-AABB broad phase.

```bash
PYTHONPATH=src python examples/run_demo.py
PYTHONPATH=src python -m nhdf_ccd_v06.cli examples/rotating_capsule_box.json
```

The reference uses binary64 arithmetic. It does not control hardware rounding modes
or prove outward-rounded interval enclosures.
