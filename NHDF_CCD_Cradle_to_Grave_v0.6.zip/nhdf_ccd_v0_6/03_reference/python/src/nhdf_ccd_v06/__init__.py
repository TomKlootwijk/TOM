"""NHDF-CCD v0.6 reference package."""
from .bvh import AABB, SweptBVH
from .ccd import conservative_advancement, distance_at, pair_speed_bound
from .exact import ExactTOI, sphere_capsule_linear, sphere_sphere_linear
from .gjk import GJKResult, distance as gjk_distance
from .math3d import Pose, quat_from_rotation_vector, quat_identity
from .motion import MovingConvex, RigidMotion
from .shapes import Box, Capsule, ConvexHull, Sphere, Triangle
from .types import CAConfig, CCDStatus, ContactCertificate

__all__ = [
    "AABB", "Box", "CAConfig", "CCDStatus", "Capsule", "ContactCertificate",
    "ConvexHull", "ExactTOI", "GJKResult", "MovingConvex", "Pose", "RigidMotion", "Sphere",
    "SweptBVH", "Triangle", "conservative_advancement", "distance_at", "gjk_distance",
    "pair_speed_bound", "sphere_capsule_linear", "sphere_sphere_linear", "quat_from_rotation_vector", "quat_identity",
]

__version__ = "0.6.0"
