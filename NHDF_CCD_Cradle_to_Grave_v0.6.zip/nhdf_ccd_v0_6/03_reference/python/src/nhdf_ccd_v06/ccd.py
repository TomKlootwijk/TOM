"""Conservative advancement for support-mapped rigid convex bodies."""
from __future__ import annotations

import hashlib
import json
import math

import numpy as np

from .gjk import GJKResult, distance as gjk_distance
from .motion import MovingConvex
from .types import CAConfig, CCDStatus, ContactCertificate, TraceStep


def pair_speed_bound(a: MovingConvex, b: MovingConvex, t0: float, t1: float) -> float:
    """Conservative bound on relative speed of any point pair over [t0,t1].

    The translational term bounds the affine relative origin velocity directly;
    the angular terms bound point motion by ``|omega| * bounding_radius``.
    """
    if t1 < t0:
        raise ValueError("t1 must be >= t0")
    relative_velocity_t0 = a.motion.origin_velocity_at(t0) - b.motion.origin_velocity_at(t0)
    relative_acceleration = a.motion.linear_acceleration - b.motion.linear_acceleration
    linear = float(np.linalg.norm(relative_velocity_t0)) + float(np.linalg.norm(relative_acceleration)) * (t1 - t0)
    angular = (
        a.motion.angular_speed_bound() * a.shape.bounding_radius()
        + b.motion.angular_speed_bound() * b.shape.bounding_radius()
    )
    return linear + angular


def distance_at(a: MovingConvex, b: MovingConvex, t: float, config: CAConfig) -> GJKResult:
    return gjk_distance(
        a.shape,
        a.pose_at(t),
        b.shape,
        b.pose_at(t),
        max_iterations=config.gjk_max_iterations,
        absolute_tolerance=config.gjk_absolute_tolerance,
        relative_tolerance=config.gjk_relative_tolerance,
    )


def _gjk_usable(result: GJKResult, config: CAConfig) -> bool:
    """Accept a bounded sample when its residual interval fits the CA error budget."""
    return result.intersect or result.converged or result.bound_gap <= config.distance_error_budget


def _trace_hash(trace: list[TraceStep]) -> str:
    payload = [
        {
            "i": s.iteration,
            "t": round(s.time, 17),
            "d": round(s.distance, 17),
            "v": round(s.speed_bound, 17),
            "dt": round(s.safe_step, 17),
            "g": s.gjk_iterations,
            "term": s.gjk_termination,
        }
        for s in trace
    ]
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _certificate(
    a: MovingConvex,
    b: MovingConvex,
    status: CCDStatus,
    config: CAConfig,
    *,
    lower: float | None,
    upper: float | None,
    result: GJKResult | None,
    speed_bound: float | None,
    iterations: int,
    gjk_total: int,
    termination: str,
    trace: list[TraceStep],
    warnings: list[str] | None = None,
) -> ContactCertificate:
    return ContactCertificate(
        schema_version="nhdf-ccd-certificate-0.6.0",
        profile="rigid-convex-conservative-advancement",
        time_semantics="conservative first entry into the declared contact band; not an exact-real zero-distance root",
        contact_tolerance=float(config.contact_tolerance),
        distance_error_budget=float(config.distance_error_budget),
        status=status,
        body_a=a.body_id,
        body_b=b.body_id,
        toi_lower=lower,
        toi_upper=upper,
        distance_at_upper=None if result is None else float(result.distance),
        witness_a=None if result is None else result.closest_a,
        witness_b=None if result is None else result.closest_b,
        normal_a_to_b=None if result is None else result.normal,
        feature_a=None if result is None else result.feature_a,
        feature_b=None if result is None else result.feature_b,
        conservative_speed_bound=speed_bound,
        ca_iterations=iterations,
        gjk_iterations_total=gjk_total,
        termination=termination,
        trace_sha256=_trace_hash(trace),
        trace=tuple(trace),
        warnings=tuple(warnings or []),
    )


def _refine_upper(
    a: MovingConvex,
    b: MovingConvex,
    safe_t: float,
    contact_t: float,
    config: CAConfig,
) -> tuple[float, float, GJKResult, int]:
    threshold = config.contact_tolerance + config.distance_error_budget
    lo = safe_t
    hi = contact_t
    hi_result = distance_at(a, b, hi, config)
    gjk_total = hi_result.iterations
    for _ in range(config.refinement_iterations):
        if hi - lo <= config.time_tolerance:
            break
        mid = 0.5 * (lo + hi)
        mid_result = distance_at(a, b, mid, config)
        gjk_total += mid_result.iterations
        if not _gjk_usable(mid_result, config):
            break
        if mid_result.distance <= threshold or mid_result.intersect:
            hi = mid
            hi_result = mid_result
        else:
            lo = mid
    return lo, hi, hi_result, gjk_total


def conservative_advancement(
    a: MovingConvex,
    b: MovingConvex,
    config: CAConfig | None = None,
) -> ContactCertificate:
    """Fail-closed convex CCD over normalized t in [0,1].

    The step uses a support-distance estimate with a declared error budget and a
    global linear-plus-angular point-speed bound. No unsafe minimum step is forced.
    """
    config = config or CAConfig()
    trace: list[TraceStep] = []
    gjk_total = 0
    threshold = config.contact_tolerance + config.distance_error_budget

    try:
        t = 0.0
        result = distance_at(a, b, t, config)
    except (ValueError, FloatingPointError, np.linalg.LinAlgError) as exc:
        return _certificate(
            a,
            b,
            CCDStatus.INVALID_INPUT,
            config,
            lower=None,
            upper=None,
            result=None,
            speed_bound=None,
            iterations=0,
            gjk_total=0,
            termination=f"invalid_input:{type(exc).__name__}",
            trace=trace,
        )

    gjk_total += result.iterations
    if not _gjk_usable(result, config):
        return _certificate(
            a,
            b,
            CCDStatus.NUMERICAL_FAILURE,
            config,
            lower=None,
            upper=0.0,
            result=result,
            speed_bound=None,
            iterations=0,
            gjk_total=gjk_total,
            termination="initial_gjk_nonconvergence",
            trace=trace,
        )
    if result.distance <= threshold or result.intersect:
        return _certificate(
            a,
            b,
            CCDStatus.INITIAL_OVERLAP,
            config,
            lower=0.0,
            upper=0.0,
            result=result,
            speed_bound=pair_speed_bound(a, b, 0.0, 1.0),
            iterations=0,
            gjk_total=gjk_total,
            termination="initial_contact_or_overlap",
            trace=trace,
        )

    safe_t = 0.0
    global_bound = pair_speed_bound(a, b, 0.0, 1.0)

    for iteration in range(1, config.max_iterations + 1):
        speed = pair_speed_bound(a, b, t, 1.0)
        if not math.isfinite(speed):
            return _certificate(a, b, CCDStatus.NUMERICAL_FAILURE, config, lower=safe_t, upper=t,
                                result=result, speed_bound=speed, iterations=iteration - 1,
                                gjk_total=gjk_total, termination="nonfinite_speed_bound", trace=trace)
        if speed <= 1e-15:
            return _certificate(a, b, CCDStatus.MISS, config, lower=None, upper=None,
                                result=result, speed_bound=speed, iterations=iteration - 1,
                                gjk_total=gjk_total, termination="stationary_positive_separation", trace=trace)

        # Since separation is Lipschitz with constant speed, this proves a miss over
        # the entire remaining interval when it is positive.
        no_hit_margin = result.lower_bound - config.distance_error_budget - speed * (1.0 - t) - config.contact_tolerance
        if no_hit_margin > 0.0:
            return _certificate(a, b, CCDStatus.MISS, config, lower=None, upper=None,
                                result=result, speed_bound=global_bound, iterations=iteration - 1,
                                gjk_total=gjk_total, termination="remaining_interval_lipschitz_miss", trace=trace)

        certified_gap = result.lower_bound - config.contact_tolerance - config.distance_error_budget
        if certified_gap <= 0.0:
            # A lower bound that reaches the contact band is not, by itself, a hit
            # certificate. The simplex upper bound must also enter the band. If the
            # distance interval straddles the threshold, preserve uncertainty.
            machine_band = max(
                64.0 * config.gjk_absolute_tolerance,
                256.0 * np.finfo(np.float64).eps * max(1.0, result.distance),
            )
            if result.distance <= threshold + machine_band or result.intersect:
                return _certificate(
                    a, b, CCDStatus.HIT, config, lower=safe_t, upper=t, result=result,
                    speed_bound=global_bound, iterations=iteration - 1, gjk_total=gjk_total,
                    termination="contact_within_declared_bound_interval", trace=trace,
                )
            return _certificate(
                a, b, CCDStatus.INCONCLUSIVE, config, lower=safe_t, upper=t, result=result,
                speed_bound=global_bound, iterations=iteration - 1, gjk_total=gjk_total,
                termination="distance_bounds_straddle_contact_band", trace=trace,
                warnings=["The support-plane lower bound entered the contact band while the simplex upper bound did not."],
            )

        safe_step = config.safety_factor * certified_gap / speed
        if len(trace) < config.trace_limit:
            trace.append(TraceStep(iteration, t, float(result.distance), float(speed), float(safe_step),
                                   result.iterations, result.termination))
        if safe_step < config.min_safe_step:
            numerical_band = threshold + max(
                64.0 * config.gjk_absolute_tolerance,
                256.0 * np.finfo(np.float64).eps * max(1.0, result.distance),
            )
            if result.distance <= numerical_band:
                return _certificate(
                    a, b, CCDStatus.HIT, config, lower=safe_t, upper=t, result=result,
                    speed_bound=global_bound, iterations=iteration, gjk_total=gjk_total,
                    termination="contact_within_declared_numerical_band", trace=trace,
                )
            return _certificate(
                a, b, CCDStatus.INCONCLUSIVE, config, lower=safe_t, upper=t, result=result,
                speed_bound=global_bound, iterations=iteration, gjk_total=gjk_total,
                termination="safe_progress_below_minimum", trace=trace,
                warnings=["No unsafe minimum step was forced; the result remains unresolved."],
            )

        next_t = min(1.0, t + safe_step)
        if next_t <= t:
            return _certificate(a, b, CCDStatus.INCONCLUSIVE, config, lower=safe_t, upper=t,
                                result=result, speed_bound=global_bound, iterations=iteration,
                                gjk_total=gjk_total, termination="floating_point_time_stall", trace=trace)
        safe_t = t
        t = next_t
        result = distance_at(a, b, t, config)
        gjk_total += result.iterations
        if not _gjk_usable(result, config):
            return _certificate(a, b, CCDStatus.NUMERICAL_FAILURE, config, lower=safe_t, upper=t,
                                result=result, speed_bound=global_bound, iterations=iteration,
                                gjk_total=gjk_total, termination="gjk_nonconvergence", trace=trace)
        if result.distance <= threshold or result.intersect:
            lo, hi, hit_result, refine_gjk = _refine_upper(a, b, safe_t, t, config)
            gjk_total += refine_gjk
            return _certificate(a, b, CCDStatus.HIT, config, lower=lo, upper=hi,
                                result=hit_result, speed_bound=global_bound, iterations=iteration,
                                gjk_total=gjk_total, termination="contact_bracket_refined", trace=trace)
        if t >= 1.0:
            return _certificate(a, b, CCDStatus.MISS, config, lower=None, upper=None,
                                result=result, speed_bound=global_bound, iterations=iteration,
                                gjk_total=gjk_total, termination="reached_end_with_positive_separation", trace=trace)

    return _certificate(a, b, CCDStatus.INCONCLUSIVE, config, lower=safe_t, upper=t,
                        result=result, speed_bound=global_bound, iterations=config.max_iterations,
                        gjk_total=gjk_total, termination="conservative_advancement_iteration_limit", trace=trace)
