"""Convex support-mapped geometry for NHDF-CCD v0.6."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, Sequence

import numpy as np

from .math3d import Array, Pose, norm, normalize, vec3


@dataclass(frozen=True, slots=True)
class LocalSupport:
    point: Array
    feature: str


@dataclass(frozen=True, slots=True)
class WorldSupport:
    point: Array
    feature: str


class ConvexShape(Protocol):
    kind: str

    def support_local(self, direction: Array) -> LocalSupport: ...

    def bounding_radius(self) -> float: ...

    def local_center(self) -> Array: ...


@dataclass(frozen=True, slots=True)
class Sphere:
    radius: float
    center: Array = field(default_factory=lambda: np.zeros(3, dtype=np.float64))
    kind: str = "sphere"

    def __post_init__(self) -> None:
        r = float(self.radius)
        if not np.isfinite(r) or r < 0.0:
            raise ValueError("sphere radius must be finite and non-negative")
        object.__setattr__(self, "radius", r)
        object.__setattr__(self, "center", vec3(self.center))

    def support_local(self, direction: Array) -> LocalSupport:
        return LocalSupport(self.center + self.radius * normalize(direction), "surface")

    def bounding_radius(self) -> float:
        return norm(self.center) + self.radius

    def local_center(self) -> Array:
        return self.center.copy()


@dataclass(frozen=True, slots=True)
class Capsule:
    a: Array
    b: Array
    radius: float
    kind: str = "capsule"

    def __post_init__(self) -> None:
        object.__setattr__(self, "a", vec3(self.a))
        object.__setattr__(self, "b", vec3(self.b))
        r = float(self.radius)
        if not np.isfinite(r) or r < 0.0:
            raise ValueError("capsule radius must be finite and non-negative")
        object.__setattr__(self, "radius", r)

    def support_local(self, direction: Array) -> LocalSupport:
        d = normalize(direction)
        da = float(np.dot(self.a, direction))
        db = float(np.dot(self.b, direction))
        if da >= db:
            return LocalSupport(self.a + self.radius * d, "cap_a")
        return LocalSupport(self.b + self.radius * d, "cap_b")

    def bounding_radius(self) -> float:
        return max(norm(self.a), norm(self.b)) + self.radius

    def local_center(self) -> Array:
        return 0.5 * (self.a + self.b)


@dataclass(frozen=True, slots=True)
class Box:
    half_extents: Array
    center: Array = field(default_factory=lambda: np.zeros(3, dtype=np.float64))
    kind: str = "box"

    def __post_init__(self) -> None:
        h = vec3(self.half_extents)
        if np.any(h < 0.0):
            raise ValueError("box half extents must be non-negative")
        object.__setattr__(self, "half_extents", h)
        object.__setattr__(self, "center", vec3(self.center))

    def support_local(self, direction: Array) -> LocalSupport:
        signs = np.where(direction >= 0.0, 1.0, -1.0)
        bits = "".join("+" if s > 0 else "-" for s in signs)
        return LocalSupport(self.center + signs * self.half_extents, f"vertex_{bits}")

    def bounding_radius(self) -> float:
        return norm(self.center) + norm(self.half_extents)

    def local_center(self) -> Array:
        return self.center.copy()

    def vertices_local(self) -> Array:
        out = []
        for sx in (-1.0, 1.0):
            for sy in (-1.0, 1.0):
                for sz in (-1.0, 1.0):
                    out.append(self.center + self.half_extents * np.array([sx, sy, sz]))
        return np.asarray(out, dtype=np.float64)


@dataclass(frozen=True, slots=True)
class ConvexHull:
    vertices: Array
    kind: str = "convex_hull"

    def __post_init__(self) -> None:
        vertices = np.asarray(self.vertices, dtype=np.float64)
        if vertices.ndim != 2 or vertices.shape[1] != 3 or vertices.shape[0] < 1:
            raise ValueError("convex hull vertices must have shape (n, 3), n>=1")
        if not np.all(np.isfinite(vertices)):
            raise ValueError("convex hull contains non-finite coordinates")
        object.__setattr__(self, "vertices", vertices.copy())

    def support_local(self, direction: Array) -> LocalSupport:
        dots = self.vertices @ direction
        index = int(np.argmax(dots))
        return LocalSupport(self.vertices[index], f"vertex_{index}")

    def bounding_radius(self) -> float:
        return float(np.max(np.linalg.norm(self.vertices, axis=1)))

    def local_center(self) -> Array:
        return np.mean(self.vertices, axis=0)

    def vertices_local(self) -> Array:
        return self.vertices.copy()


@dataclass(frozen=True, slots=True)
class Triangle:
    a: Array
    b: Array
    c: Array
    kind: str = "triangle"

    def __post_init__(self) -> None:
        object.__setattr__(self, "a", vec3(self.a))
        object.__setattr__(self, "b", vec3(self.b))
        object.__setattr__(self, "c", vec3(self.c))

    @property
    def vertices(self) -> Array:
        return np.stack([self.a, self.b, self.c])

    def support_local(self, direction: Array) -> LocalSupport:
        dots = self.vertices @ direction
        index = int(np.argmax(dots))
        return LocalSupport(self.vertices[index], ("vertex_a", "vertex_b", "vertex_c")[index])

    def bounding_radius(self) -> float:
        return float(np.max(np.linalg.norm(self.vertices, axis=1)))

    def local_center(self) -> Array:
        return (self.a + self.b + self.c) / 3.0

    def vertices_local(self) -> Array:
        return self.vertices.copy()


def support_world(shape: ConvexShape, pose: Pose, direction_world: Array) -> WorldSupport:
    local_direction = pose.inverse_rotate_vector(direction_world)
    support = shape.support_local(local_direction)
    return WorldSupport(pose.transform_point(support.point), support.feature)


def world_center(shape: ConvexShape, pose: Pose) -> Array:
    return pose.transform_point(shape.local_center())


def vertices_world(shape: ConvexShape, pose: Pose) -> Array:
    if isinstance(shape, Box):
        vertices = shape.vertices_local()
    elif isinstance(shape, ConvexHull):
        vertices = shape.vertices_local()
    elif isinstance(shape, Triangle):
        vertices = shape.vertices_local()
    else:
        raise TypeError(f"{shape.kind} does not have a finite polytope vertex set")
    return np.stack([pose.transform_point(v) for v in vertices])


def validate_shape_sequence(shapes: Sequence[ConvexShape]) -> None:
    if not shapes:
        raise ValueError("at least one shape is required")
    for shape in shapes:
        radius = shape.bounding_radius()
        if not np.isfinite(radius) or radius < 0.0:
            raise ValueError(f"invalid bounding radius for {shape.kind}")
