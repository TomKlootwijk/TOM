"""Small deterministic 3-D math helpers for the NHDF-CCD v0.6 reference.

The runtime uses NumPy only. Quaternions are stored as [w, x, y, z].
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable

import numpy as np

Array = np.ndarray


def vec3(value: Iterable[float] | Array) -> Array:
    out = np.asarray(value, dtype=np.float64)
    if out.shape != (3,):
        raise ValueError(f"expected a 3-vector, got shape {out.shape}")
    if not np.all(np.isfinite(out)):
        raise ValueError("vector contains non-finite values")
    return out.copy()


def norm(v: Array) -> float:
    return float(np.linalg.norm(v))


def normalize(v: Array, fallback: Array | None = None, eps: float = 1e-15) -> Array:
    n = norm(v)
    if n > eps:
        return v / n
    if fallback is None:
        return np.array([1.0, 0.0, 0.0], dtype=np.float64)
    f = vec3(fallback)
    fn = norm(f)
    if fn <= eps:
        raise ValueError("fallback direction is also zero")
    return f / fn


def quat(value: Iterable[float] | Array) -> Array:
    out = np.asarray(value, dtype=np.float64)
    if out.shape != (4,):
        raise ValueError(f"expected a quaternion [w,x,y,z], got shape {out.shape}")
    if not np.all(np.isfinite(out)):
        raise ValueError("quaternion contains non-finite values")
    n = float(np.linalg.norm(out))
    if n <= 1e-15:
        raise ValueError("zero quaternion")
    return out / n


def quat_identity() -> Array:
    return np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float64)


def quat_mul(a: Array, b: Array) -> Array:
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return np.array(
        [
            aw * bw - ax * bx - ay * by - az * bz,
            aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw,
        ],
        dtype=np.float64,
    )


def quat_conj(q: Array) -> Array:
    return np.array([q[0], -q[1], -q[2], -q[3]], dtype=np.float64)


def quat_from_rotation_vector(rotation_vector: Iterable[float] | Array) -> Array:
    rv = vec3(rotation_vector)
    angle = norm(rv)
    if angle <= 1e-15:
        return quat_identity()
    half = 0.5 * angle
    axis = rv / angle
    return np.array([math.cos(half), *(math.sin(half) * axis)], dtype=np.float64)


def quat_rotate(q: Array, v: Array) -> Array:
    qv = q[1:]
    t = 2.0 * np.cross(qv, v)
    return v + q[0] * t + np.cross(qv, t)


def quat_to_matrix(q: Array) -> Array:
    w, x, y, z = q
    return np.array(
        [
            [1.0 - 2.0 * (y * y + z * z), 2.0 * (x * y - z * w), 2.0 * (x * z + y * w)],
            [2.0 * (x * y + z * w), 1.0 - 2.0 * (x * x + z * z), 2.0 * (y * z - x * w)],
            [2.0 * (x * z - y * w), 2.0 * (y * z + x * w), 1.0 - 2.0 * (x * x + y * y)],
        ],
        dtype=np.float64,
    )


@dataclass(frozen=True, slots=True)
class Pose:
    translation: Array
    rotation: Array

    def __post_init__(self) -> None:
        object.__setattr__(self, "translation", vec3(self.translation))
        object.__setattr__(self, "rotation", quat(self.rotation))

    @staticmethod
    def identity() -> "Pose":
        return Pose(np.zeros(3, dtype=np.float64), quat_identity())

    @property
    def matrix(self) -> Array:
        return quat_to_matrix(self.rotation)

    def transform_point(self, p_local: Array) -> Array:
        return quat_rotate(self.rotation, p_local) + self.translation

    def inverse_rotate_vector(self, v_world: Array) -> Array:
        return quat_rotate(quat_conj(self.rotation), v_world)
