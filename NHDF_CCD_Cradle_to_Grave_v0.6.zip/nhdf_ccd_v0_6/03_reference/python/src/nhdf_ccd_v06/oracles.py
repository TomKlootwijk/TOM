"""Specialized independent oracles used by verification and benchmarks."""
from __future__ import annotations

import math

import numpy as np

from .math3d import Array, norm


def linear_sphere_sphere_toi(
    center_a: Array,
    velocity_a: Array,
    radius_a: float,
    center_b: Array,
    velocity_b: Array,
    radius_b: float,
) -> float | None:
    p = np.asarray(center_a, dtype=np.float64) - np.asarray(center_b, dtype=np.float64)
    v = np.asarray(velocity_a, dtype=np.float64) - np.asarray(velocity_b, dtype=np.float64)
    radius = float(radius_a + radius_b)
    c = float(np.dot(p, p) - radius * radius)
    if c <= 0.0:
        return 0.0
    a = float(np.dot(v, v))
    if a <= 1e-30:
        return None
    b = 2.0 * float(np.dot(p, v))
    discriminant = b * b - 4.0 * a * c
    if discriminant < 0.0:
        return None
    root = math.sqrt(max(0.0, discriminant))
    q = -0.5 * (b + math.copysign(root, b))
    roots: list[float] = []
    roots.append(q / a)
    if abs(q) > 1e-30:
        roots.append(c / q)
    valid = [t for t in roots if 0.0 <= t <= 1.0]
    return min(valid) if valid else None


def orbiting_sphere_fixed_sphere_toi(
    local_center: Array,
    origin: Array,
    angular_velocity_z: float,
    moving_radius: float,
    fixed_center: Array,
    fixed_radius: float,
) -> float | None:
    """Analytic root for a sphere center rotating about world z with fixed origin."""
    local_center = np.asarray(local_center, dtype=np.float64)
    origin = np.asarray(origin, dtype=np.float64)
    fixed_center = np.asarray(fixed_center, dtype=np.float64)
    x, y, z = (float(v) for v in local_center)
    dx, dy, dz = (float(v) for v in (fixed_center - origin))
    rsum = float(moving_radius + fixed_radius)
    initial = origin + local_center
    if norm(initial - fixed_center) <= rsum:
        return 0.0
    amplitude = math.hypot(x * dx + y * dy, -y * dx + x * dy)
    const = 0.5 * (x * x + y * y + z * z + dx * dx + dy * dy + dz * dz - 2.0 * z * dz - rsum * rsum)
    if amplitude <= 1e-15:
        initial = origin + local_center
        return 0.0 if norm(initial - fixed_center) <= rsum else None
    ratio = const / amplitude
    if ratio < -1.0 - 1e-12 or ratio > 1.0 + 1e-12:
        return None
    ratio = min(1.0, max(-1.0, ratio))
    phase = math.atan2(-y * dx + x * dy, x * dx + y * dy)
    alpha = math.acos(ratio)
    if abs(angular_velocity_z) <= 1e-15:
        return None
    candidates: list[float] = []
    for sign in (-1.0, 1.0):
        target = phase + sign * alpha
        for k in range(-8, 9):
            t = (target + 2.0 * math.pi * k) / angular_velocity_z
            if -1e-12 <= t <= 1.0 + 1e-12:
                candidates.append(min(1.0, max(0.0, t)))
    valid: list[float] = []
    for t in candidates:
        angle = angular_velocity_z * t
        c, s = math.cos(angle), math.sin(angle)
        center = origin + np.array([c * x - s * y, s * x + c * y, z])
        if abs(norm(center - fixed_center) - rsum) <= 1e-7:
            valid.append(t)
    return min(valid) if valid else None
