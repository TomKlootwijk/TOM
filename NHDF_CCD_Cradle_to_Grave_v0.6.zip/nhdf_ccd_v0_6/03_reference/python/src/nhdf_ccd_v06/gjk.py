"""Auditable GJK distance query for support-mapped convex bodies.

The implementation keeps explicit support-plane lower and simplex upper bounds.
The public ``distance`` result is accepted as converged only when their gap lies
inside the declared absolute/relative tolerance.  This is the condition relied on
by the conservative-advancement layer's separate distance-error budget.
"""
from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
import math
from typing import Sequence

import numpy as np

from .math3d import Array, Pose, norm, normalize
from .shapes import ConvexShape, support_world, world_center


@dataclass(frozen=True, slots=True)
class SupportPoint:
    p: Array
    a: Array
    b: Array
    feature_a: str
    feature_b: str


@dataclass(frozen=True, slots=True)
class GJKResult:
    distance: float
    lower_bound: float
    upper_bound: float
    closest_a: Array
    closest_b: Array
    normal: Array
    feature_a: str
    feature_b: str
    iterations: int
    support_calls: int
    simplex_size: int
    converged: bool
    intersect: bool
    termination: str
    trace: tuple[dict[str, float | int | str], ...] = ()

    @property
    def bound_gap(self) -> float:
        return max(0.0, self.upper_bound - self.lower_bound)


def _support(
    shape_a: ConvexShape,
    pose_a: Pose,
    shape_b: ConvexShape,
    pose_b: Pose,
    direction: Array,
) -> SupportPoint:
    sa = support_world(shape_a, pose_a, direction)
    sb = support_world(shape_b, pose_b, -direction)
    return SupportPoint(sa.point - sb.point, sa.point, sb.point, sa.feature, sb.feature)


def _active_weights(points: Sequence[SupportPoint], subset: tuple[int, ...]) -> Array | None:
    k = len(subset)
    if k == 1:
        return np.ones(1, dtype=np.float64)
    columns = np.stack([points[i].p for i in subset], axis=1)  # 3 x k
    gram = columns.T @ columns
    kkt = np.block(
        [
            [gram, np.ones((k, 1), dtype=np.float64)],
            [np.ones((1, k), dtype=np.float64), np.zeros((1, 1), dtype=np.float64)],
        ]
    )
    rhs = np.concatenate([np.zeros(k, dtype=np.float64), np.ones(1, dtype=np.float64)])
    try:
        solution, _residuals, rank, _singular = np.linalg.lstsq(kkt, rhs, rcond=None)
    except np.linalg.LinAlgError:
        return None
    if rank < min(k + 1, 2):
        return None
    lambdas = solution[:k]
    if not np.all(np.isfinite(lambdas)):
        return None
    # Verify the equality because a rank-deficient least-squares solution can be
    # numerically plausible while not satisfying the affine constraint.
    if abs(float(np.sum(lambdas)) - 1.0) > 1e-9:
        return None
    return lambdas


def _closest_simplex(
    points: Sequence[SupportPoint],
    barycentric_tolerance: float = 1e-12,
) -> tuple[list[SupportPoint], Array, Array] | None:
    """Closest point to the origin in the convex hull of at most five supports.

    Caratheodory's theorem permits an active set of no more than four points in
    three dimensions, so every subset up to size four is examined.  This avoids a
    brittle hand-written simplex region tree and gives deterministic degeneracy
    handling for the reference implementation.
    """
    best: tuple[float, int, tuple[int, ...], Array, Array] | None = None
    for k in range(1, min(4, len(points)) + 1):
        for subset in combinations(range(len(points)), k):
            weights = _active_weights(points, subset)
            if weights is None or float(np.min(weights)) < -barycentric_tolerance:
                continue
            weights = np.maximum(weights, 0.0)
            total = float(np.sum(weights))
            if total <= barycentric_tolerance:
                continue
            weights = weights / total
            q = sum((weights[j] * points[index].p for j, index in enumerate(subset)), np.zeros(3))
            key = (float(np.dot(q, q)), k, subset, weights, q)
            if best is None or key[:3] < best[:3]:
                best = key
    if best is None:
        return None
    _distance_sq, _k, subset, weights, q = best
    active = [j for j, weight in enumerate(weights) if weight > barycentric_tolerance]
    if not active:
        active = [int(np.argmax(weights))]
    reduced = [points[subset[j]] for j in active]
    reduced_weights = np.asarray([weights[j] for j in active], dtype=np.float64)
    reduced_weights /= float(np.sum(reduced_weights))
    q = sum((reduced_weights[j] * reduced[j].p for j in range(len(reduced))), np.zeros(3))
    return reduced, reduced_weights, q


def _combine(simplex: Sequence[SupportPoint], weights: Array) -> tuple[Array, Array]:
    a = sum((weights[i] * simplex[i].a for i in range(len(simplex))), np.zeros(3))
    b = sum((weights[i] * simplex[i].b for i in range(len(simplex))), np.zeros(3))
    return np.asarray(a, dtype=np.float64), np.asarray(b, dtype=np.float64)


def _feature(simplex: Sequence[SupportPoint], weights: Array, side: str) -> str:
    indices = sorted(
        range(len(simplex)),
        key=lambda i: (-float(weights[i]), getattr(simplex[i], f"feature_{side}"), i),
    )
    names: list[str] = []
    for i in indices:
        name = getattr(simplex[i], f"feature_{side}")
        if name not in names:
            names.append(name)
        if len(names) == 2:
            break
    return "+".join(names)


def _duplicate(simplex: Sequence[SupportPoint], candidate: SupportPoint, tolerance: float) -> bool:
    scale = max(1.0, norm(candidate.p))
    threshold = tolerance * scale
    return any(norm(candidate.p - item.p) <= threshold for item in simplex)


def _result(
    simplex: Sequence[SupportPoint],
    weights: Array,
    lower: float,
    upper: float,
    iterations: int,
    support_calls: int,
    converged: bool,
    intersect: bool,
    termination: str,
    trace: list[dict[str, float | int | str]],
) -> GJKResult:
    closest_a, closest_b = _combine(simplex, weights)
    delta = closest_b - closest_a
    fallback = -sum((weights[i] * simplex[i].p for i in range(len(simplex))), np.zeros(3))
    if norm(fallback) <= 1e-15:
        fallback = np.array([1.0, 0.0, 0.0], dtype=np.float64)
    normal = normalize(delta, fallback=fallback)
    return GJKResult(
        distance=float(upper),
        lower_bound=float(max(0.0, lower)),
        upper_bound=float(max(0.0, upper)),
        closest_a=closest_a,
        closest_b=closest_b,
        normal=normal,
        feature_a=_feature(simplex, weights, "a"),
        feature_b=_feature(simplex, weights, "b"),
        iterations=iterations,
        support_calls=support_calls,
        simplex_size=len(simplex),
        converged=converged,
        intersect=intersect,
        termination=termination,
        trace=tuple(trace),
    )


def distance(
    shape_a: ConvexShape,
    pose_a: Pose,
    shape_b: ConvexShape,
    pose_b: Pose,
    *,
    max_iterations: int = 64,
    absolute_tolerance: float = 1e-11,
    relative_tolerance: float = 1e-11,
    overlap_tolerance: float = 1e-12,
    duplicate_tolerance: float = 1e-13,
    capture_trace: bool = False,
    trace_limit: int = 256,
) -> GJKResult:
    if max_iterations < 1:
        raise ValueError("max_iterations must be positive")
    if min(absolute_tolerance, relative_tolerance, overlap_tolerance, duplicate_tolerance) < 0.0:
        raise ValueError("GJK tolerances must be non-negative")

    direction = world_center(shape_b, pose_b) - world_center(shape_a, pose_a)
    if norm(direction) <= 1e-15:
        direction = np.array([1.0, 0.0, 0.0], dtype=np.float64)
    simplex = [_support(shape_a, pose_a, shape_b, pose_b, direction)]
    support_calls = 1
    solved = _closest_simplex(simplex)
    if solved is None:
        weights = np.ones(1)
        return _result(simplex, weights, 0.0, norm(simplex[0].p), 0, support_calls, False, False, "initial_simplex_failure", [])
    simplex, weights, q = solved
    lower = 0.0
    trace: list[dict[str, float | int | str]] = []
    previous_upper = math.inf
    stall_count = 0

    for iteration in range(1, max_iterations + 1):
        upper = norm(q)
        if upper <= overlap_tolerance:
            if capture_trace and len(trace) < trace_limit:
                trace.append({"iteration": iteration, "lower": 0.0, "upper": upper, "gap": upper, "event": "origin_reached"})
            return _result(simplex, weights, 0.0, upper, iteration, support_calls, True, True, "origin_or_overlap_tolerance", trace)

        candidate = _support(shape_a, pose_a, shape_b, pose_b, -q)
        support_calls += 1
        plane = float(np.dot(q / upper, candidate.p))
        if math.isfinite(plane):
            lower = max(lower, min(upper, plane))
        lower = max(0.0, lower)
        gap = max(0.0, upper - lower)
        tolerance = absolute_tolerance + relative_tolerance * upper
        if capture_trace and len(trace) < trace_limit:
            trace.append(
                {
                    "iteration": iteration,
                    "lower": lower,
                    "upper": upper,
                    "gap": gap,
                    "simplex_size": len(simplex),
                    "support_plane": plane,
                }
            )
        if gap <= tolerance:
            return _result(simplex, weights, lower, upper, iteration, support_calls, True, False, "support_plane_gap", trace)
        if _duplicate(simplex, candidate, duplicate_tolerance):
            # Duplicate support is a normal terminal condition at finite precision.
            # Accept only when the remaining gap fits a slightly relaxed machine
            # envelope; otherwise preserve non-convergence.
            relaxed = max(tolerance * 32.0, duplicate_tolerance * max(1.0, upper))
            return _result(
                simplex,
                weights,
                lower,
                upper,
                iteration,
                support_calls,
                gap <= relaxed,
                False,
                "duplicate_support_converged" if gap <= relaxed else "duplicate_support_unresolved",
                trace,
            )

        if previous_upper - upper <= max(1e-16, absolute_tolerance * 1e-3):
            stall_count += 1
        else:
            stall_count = 0
        previous_upper = upper
        if stall_count >= 6 and gap > 32.0 * tolerance:
            return _result(simplex, weights, lower, upper, iteration, support_calls, False, False, "upper_bound_stall", trace)

        solved = _closest_simplex([*simplex, candidate])
        if solved is None:
            return _result(simplex, weights, lower, upper, iteration, support_calls, False, False, "simplex_solve_failure", trace)
        simplex, weights, q = solved

    upper = norm(q)
    return _result(simplex, weights, lower, upper, max_iterations, support_calls, False, upper <= overlap_tolerance, "iteration_limit", trace)
