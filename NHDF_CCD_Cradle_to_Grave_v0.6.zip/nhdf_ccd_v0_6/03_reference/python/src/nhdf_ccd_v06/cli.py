from __future__ import annotations

import argparse
import json
import sys

from .ccd import conservative_advancement
from .io import load_scene
from .types import CCDStatus


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="NHDF-CCD v0.6 rigid-convex reference query")
    parser.add_argument("scene", help="path to an nhdf-ccd-scene-0.6.0 JSON file")
    parser.add_argument("--no-trace", action="store_true", help="omit full trace from JSON output")
    args = parser.parse_args(argv)
    try:
        a, b = load_scene(args.scene)
        certificate = conservative_advancement(a, b)
    except Exception as exc:
        print(json.dumps({"status": "INVALID_INPUT", "error": str(exc)}, indent=2), file=sys.stderr)
        return 2
    print(json.dumps(certificate.to_dict(include_trace=not args.no_trace), indent=2, sort_keys=True))
    return 0 if certificate.status in {CCDStatus.HIT, CCDStatus.MISS, CCDStatus.INITIAL_OVERLAP} else 3


if __name__ == "__main__":
    raise SystemExit(main())
