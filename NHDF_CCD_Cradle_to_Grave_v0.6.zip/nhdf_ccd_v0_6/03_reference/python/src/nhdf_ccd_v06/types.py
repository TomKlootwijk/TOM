"""Public result and configuration types for NHDF-CCD v0.6."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any

import numpy as np

from .math3d import Array


class CCDStatus(str, Enum):
    HIT = "HIT"
    MISS = "MISS"
    INITIAL_OVERLAP = "INITIAL_OVERLAP"
    INCONCLUSIVE = "INCONCLUSIVE"
    RESOURCE_EXHAUSTED = "RESOURCE_EXHAUSTED"
    INVALID_INPUT = "INVALID_INPUT"
    NUMERICAL_FAILURE = "NUMERICAL_FAILURE"


@dataclass(frozen=True, slots=True)
class CAConfig:
    contact_tolerance: float = 1e-6
    distance_error_budget: float = 1e-8
    time_tolerance: float = 1e-10
    safety_factor: float = 0.9
    min_safe_step: float = 1e-14
    max_iterations: int = 128
    refinement_iterations: int = 48
    gjk_max_iterations: int = 64
    gjk_absolute_tolerance: float = 1e-11
    gjk_relative_tolerance: float = 1e-11
    trace_limit: int = 256

    def __post_init__(self) -> None:
        if not (0.0 < self.safety_factor <= 1.0):
            raise ValueError("safety_factor must lie in (0,1]")
        if self.contact_tolerance < 0.0 or self.distance_error_budget < 0.0:
            raise ValueError("tolerances must be non-negative")
        if self.time_tolerance <= 0.0 or self.min_safe_step <= 0.0:
            raise ValueError("time tolerances must be positive")
        if self.max_iterations < 1 or self.refinement_iterations < 0 or self.gjk_max_iterations < 1:
            raise ValueError("iteration limits must be valid")


@dataclass(frozen=True, slots=True)
class TraceStep:
    iteration: int
    time: float
    distance: float
    speed_bound: float
    safe_step: float
    gjk_iterations: int
    gjk_termination: str


@dataclass(frozen=True, slots=True)
class ContactCertificate:
    schema_version: str
    profile: str
    time_semantics: str
    contact_tolerance: float
    distance_error_budget: float
    status: CCDStatus
    body_a: str
    body_b: str
    toi_lower: float | None
    toi_upper: float | None
    distance_at_upper: float | None
    witness_a: Array | None
    witness_b: Array | None
    normal_a_to_b: Array | None
    feature_a: str | None
    feature_b: str | None
    conservative_speed_bound: float | None
    ca_iterations: int
    gjk_iterations_total: int
    termination: str
    trace_sha256: str
    trace: tuple[TraceStep, ...] = field(default_factory=tuple)
    warnings: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self, include_trace: bool = True) -> dict[str, Any]:
        def convert(value: Any) -> Any:
            if isinstance(value, np.ndarray):
                return [float(x) for x in value]
            if isinstance(value, Enum):
                return value.value
            if isinstance(value, tuple):
                return [convert(x) for x in value]
            if hasattr(value, "__dataclass_fields__"):
                return {k: convert(v) for k, v in asdict(value).items()}
            return value

        data = {name: convert(getattr(self, name)) for name in self.__dataclass_fields__}
        if not include_trace:
            data.pop("trace", None)
        return data


@dataclass(frozen=True, slots=True)
class BroadPhaseResult:
    status: CCDStatus
    pairs: tuple[tuple[str, str], ...]
    tested_aabbs: int
    capacity: int
    termination: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status.value,
            "pairs": [list(p) for p in self.pairs],
            "tested_aabbs": self.tested_aabbs,
            "capacity": self.capacity,
            "termination": self.termination,
        }
