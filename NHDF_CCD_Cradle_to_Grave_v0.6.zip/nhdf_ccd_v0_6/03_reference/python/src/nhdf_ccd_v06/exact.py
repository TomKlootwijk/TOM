"""Specialized analytic translational CCD profiles used as reference oracles.

These functions are independent of the support-mapped conservative-advancement path.
"""
from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np

from .math3d import Array, norm, normalize, vec3


@dataclass(frozen=True, slots=True)
class ExactTOI:
    hit: bool
    time: float | None
    witness_a: Array | None
    witness_b: Array | None
    normal_a_to_b: Array | None
    feature_b: str | None


def _quadratic_roots(a: float, b: float, c: float) -> list[float]:
    scale = max(1.0, abs(a), abs(b), abs(c))
    if abs(a) <= 1e-15 * scale:
        if abs(b) <= 1e-15 * scale:
            return []
        return [-c / b]
    disc = b * b - 4.0 * a * c
    if disc < -1e-14 * scale * scale:
        return []
    disc = max(0.0, disc)
    root = math.sqrt(disc)
    q = -0.5 * (b + math.copysign(root, b))
    roots = [q / a]
    if abs(q) > 1e-30:
        roots.append(c / q)
    return sorted(set(float(x) for x in roots if math.isfinite(x)))


def _segment_closest(point: Array, a: Array, b: Array) -> tuple[Array, float]:
    d = b - a
    den = float(np.dot(d, d))
    if den <= 1e-30:
        return a.copy(), 0.0
    u = min(1.0, max(0.0, float(np.dot(point - a, d) / den)))
    return a + u * d, u


def sphere_sphere_linear(
    center_a0: Array,
    velocity_a: Array,
    radius_a: float,
    center_b0: Array,
    velocity_b: Array,
    radius_b: float,
) -> ExactTOI:
    a0 = vec3(center_a0)
    b0 = vec3(center_b0)
    v = vec3(velocity_a) - vec3(velocity_b)
    p = a0 - b0
    radius = float(radius_a + radius_b)
    if radius < 0.0:
        raise ValueError("radii must be non-negative")
    c = float(np.dot(p, p) - radius * radius)
    candidates = [0.0] if c <= 0.0 else [t for t in _quadratic_roots(float(np.dot(v, v)), 2.0 * float(np.dot(p, v)), c) if 0.0 <= t <= 1.0]
    if not candidates:
        return ExactTOI(False, None, None, None, None, None)
    t = min(candidates)
    ca = a0 + vec3(velocity_a) * t
    cb = b0 + vec3(velocity_b) * t
    normal = normalize(cb - ca)
    return ExactTOI(True, t, ca + radius_a * normal, cb - radius_b * normal, normal, "sphere")


def sphere_capsule_linear(
    sphere_center0: Array,
    sphere_velocity: Array,
    sphere_radius: float,
    capsule_a0: Array,
    capsule_b0: Array,
    capsule_velocity: Array,
    capsule_radius: float,
) -> ExactTOI:
    """Earliest contact for a translating sphere and a translating, non-rotating capsule."""
    p0 = vec3(sphere_center0)
    v = vec3(sphere_velocity) - vec3(capsule_velocity)
    a = vec3(capsule_a0)
    b = vec3(capsule_b0)
    combined = float(sphere_radius + capsule_radius)
    if combined < 0.0:
        raise ValueError("radii must be non-negative")
    closest0, u0 = _segment_closest(p0, a, b)
    candidates: list[tuple[float, str]] = []
    if norm(p0 - closest0) <= combined:
        candidates.append((0.0, "segment" if 0.0 < u0 < 1.0 else ("cap_a" if u0 <= 0.0 else "cap_b")))

    # End-cap sphere candidates.
    for endpoint, name in ((a, "cap_a"), (b, "cap_b")):
        m = p0 - endpoint
        roots = _quadratic_roots(float(np.dot(v, v)), 2.0 * float(np.dot(m, v)), float(np.dot(m, m) - combined * combined))
        candidates.extend((t, name) for t in roots if 0.0 <= t <= 1.0)

    # Finite cylinder candidate.
    axis = b - a
    length = norm(axis)
    if length > 1e-15:
        n = axis / length
        m = p0 - a
        m_perp = m - n * float(np.dot(m, n))
        v_perp = v - n * float(np.dot(v, n))
        roots = _quadratic_roots(
            float(np.dot(v_perp, v_perp)),
            2.0 * float(np.dot(m_perp, v_perp)),
            float(np.dot(m_perp, m_perp) - combined * combined),
        )
        for t in roots:
            axial = float(np.dot(m + v * t, n))
            if 0.0 <= t <= 1.0 and 0.0 <= axial <= length:
                candidates.append((t, "cylinder"))

    if not candidates:
        return ExactTOI(False, None, None, None, None, None)
    t, feature = min(candidates, key=lambda item: (item[0], item[1]))
    sphere_center = p0 + vec3(sphere_velocity) * t
    capsule_shift = vec3(capsule_velocity) * t
    ca = a + capsule_shift
    cb = b + capsule_shift
    closest, _ = _segment_closest(sphere_center, ca, cb)
    normal = normalize(closest - sphere_center)
    return ExactTOI(
        True,
        t,
        sphere_center + sphere_radius * normal,
        closest - capsule_radius * normal,
        normal,
        feature,
    )
