"""Deterministic swept-AABB BVH broad phase with explicit capacity semantics."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .math3d import Array
from .motion import MovingConvex
from .types import BroadPhaseResult, CCDStatus


@dataclass(frozen=True, slots=True)
class AABB:
    lower: Array
    upper: Array

    def __post_init__(self) -> None:
        lower = np.asarray(self.lower, dtype=np.float64)
        upper = np.asarray(self.upper, dtype=np.float64)
        if lower.shape != (3,) or upper.shape != (3,):
            raise ValueError("AABB bounds must be 3-vectors")
        if not np.all(np.isfinite(lower)) or not np.all(np.isfinite(upper)):
            raise ValueError("AABB contains non-finite values")
        if np.any(lower > upper):
            raise ValueError("AABB lower bound exceeds upper bound")
        object.__setattr__(self, "lower", lower.copy())
        object.__setattr__(self, "upper", upper.copy())

    def overlaps(self, other: "AABB") -> bool:
        return bool(np.all(self.lower <= other.upper) and np.all(other.lower <= self.upper))

    def union(self, other: "AABB") -> "AABB":
        return AABB(np.minimum(self.lower, other.lower), np.maximum(self.upper, other.upper))

    @property
    def centroid(self) -> Array:
        return 0.5 * (self.lower + self.upper)


@dataclass(slots=True)
class _Node:
    bounds: AABB
    left: "_Node | None"
    right: "_Node | None"
    indices: tuple[int, ...]

    @property
    def leaf(self) -> bool:
        return self.left is None and self.right is None


class SweptBVH:
    def __init__(self, bodies: list[MovingConvex], leaf_size: int = 4):
        if leaf_size < 1:
            raise ValueError("leaf_size must be positive")
        self.bodies = list(bodies)
        self.aabbs = [AABB(*body.swept_aabb()) for body in self.bodies]
        self.leaf_size = leaf_size
        self.root = self._build(tuple(range(len(self.bodies)))) if self.bodies else None

    def _build(self, indices: tuple[int, ...]) -> _Node:
        bounds = self.aabbs[indices[0]]
        for index in indices[1:]:
            bounds = bounds.union(self.aabbs[index])
        if len(indices) <= self.leaf_size:
            return _Node(bounds, None, None, tuple(sorted(indices)))
        centroids = np.stack([self.aabbs[i].centroid for i in indices])
        axis = int(np.argmax(np.ptp(centroids, axis=0)))
        ordered = sorted(indices, key=lambda i: (float(self.aabbs[i].centroid[axis]), self.bodies[i].body_id))
        middle = len(ordered) // 2
        return _Node(bounds, self._build(tuple(ordered[:middle])), self._build(tuple(ordered[middle:])), ())

    def query(self, bounds: AABB) -> tuple[list[int], int]:
        if self.root is None:
            return [], 0
        hits: list[int] = []
        tested = 0
        stack = [self.root]
        while stack:
            node = stack.pop()
            tested += 1
            if not node.bounds.overlaps(bounds):
                continue
            if node.leaf:
                hits.extend(i for i in node.indices if self.aabbs[i].overlaps(bounds))
            else:
                assert node.left is not None and node.right is not None
                stack.append(node.right)
                stack.append(node.left)
        return sorted(set(hits)), tested

    def candidate_pairs(self, capacity: int = 1_000_000) -> BroadPhaseResult:
        if capacity < 0:
            raise ValueError("capacity must be non-negative")
        pairs: list[tuple[str, str]] = []
        tested = 0
        for i, body in enumerate(self.bodies):
            hits, count = self.query(self.aabbs[i])
            tested += count
            for j in hits:
                if j <= i:
                    continue
                pair = tuple(sorted((body.body_id, self.bodies[j].body_id)))
                if len(pairs) >= capacity:
                    return BroadPhaseResult(
                        CCDStatus.RESOURCE_EXHAUSTED,
                        tuple(pairs),
                        tested,
                        capacity,
                        "candidate_capacity_reached_partial_list_not_authoritative",
                    )
                pairs.append(pair)
        return BroadPhaseResult(
            CCDStatus.HIT if pairs else CCDStatus.MISS,
            tuple(sorted(set(pairs))),
            tested,
            capacity,
            "complete_swept_aabb_enumeration",
        )
