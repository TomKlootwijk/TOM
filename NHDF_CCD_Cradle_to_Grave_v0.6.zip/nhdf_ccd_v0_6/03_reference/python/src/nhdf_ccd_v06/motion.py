"""Rigid motion profiles and conservative swept envelopes."""
from __future__ import annotations

from dataclasses import dataclass, field
import math

import numpy as np

from .math3d import Array, Pose, norm, quat_mul, quat_from_rotation_vector, vec3
from .shapes import ConvexShape


@dataclass(frozen=True, slots=True)
class RigidMotion:
    """Quadratic translation plus constant world angular velocity on t in [0,1]."""

    pose0: Pose = field(default_factory=Pose.identity)
    linear_velocity: Array = field(default_factory=lambda: np.zeros(3, dtype=np.float64))
    linear_acceleration: Array = field(default_factory=lambda: np.zeros(3, dtype=np.float64))
    angular_velocity: Array = field(default_factory=lambda: np.zeros(3, dtype=np.float64))

    def __post_init__(self) -> None:
        object.__setattr__(self, "linear_velocity", vec3(self.linear_velocity))
        object.__setattr__(self, "linear_acceleration", vec3(self.linear_acceleration))
        object.__setattr__(self, "angular_velocity", vec3(self.angular_velocity))

    def pose_at(self, t: float) -> Pose:
        t = float(t)
        if not math.isfinite(t):
            raise ValueError("time must be finite")
        translation = (
            self.pose0.translation
            + self.linear_velocity * t
            + 0.5 * self.linear_acceleration * (t * t)
        )
        delta = quat_from_rotation_vector(self.angular_velocity * t)
        rotation = quat_mul(delta, self.pose0.rotation)
        return Pose(translation, rotation)

    def origin_velocity_at(self, t: float) -> Array:
        return self.linear_velocity + self.linear_acceleration * float(t)

    def linear_speed_bound(self, t0: float = 0.0, t1: float = 1.0) -> float:
        if t1 < t0:
            raise ValueError("t1 must be >= t0")
        return norm(self.origin_velocity_at(t0)) + norm(self.linear_acceleration) * (t1 - t0)

    def angular_speed_bound(self) -> float:
        return norm(self.angular_velocity)

    def point_speed_bound(self, shape: ConvexShape, t0: float = 0.0, t1: float = 1.0) -> float:
        return self.linear_speed_bound(t0, t1) + self.angular_speed_bound() * shape.bounding_radius()

    def translation_axis_bounds(self, axis: int, t0: float = 0.0, t1: float = 1.0) -> tuple[float, float]:
        p0 = float(self.pose0.translation[axis])
        v0 = float(self.linear_velocity[axis])
        a = float(self.linear_acceleration[axis])
        candidates = [t0, t1]
        if abs(a) > 1e-15:
            critical = -v0 / a
            if t0 < critical < t1:
                candidates.append(critical)
        values = [p0 + v0 * t + 0.5 * a * t * t for t in candidates]
        return min(values), max(values)


@dataclass(frozen=True, slots=True)
class MovingConvex:
    shape: ConvexShape
    motion: RigidMotion
    body_id: str

    def __post_init__(self) -> None:
        if not self.body_id:
            raise ValueError("body_id must be non-empty")

    def pose_at(self, t: float) -> Pose:
        return self.motion.pose_at(t)

    def swept_aabb(self, t0: float = 0.0, t1: float = 1.0) -> tuple[Array, Array]:
        radius = self.shape.bounding_radius()
        lower = np.empty(3, dtype=np.float64)
        upper = np.empty(3, dtype=np.float64)
        for axis in range(3):
            lo, hi = self.motion.translation_axis_bounds(axis, t0, t1)
            lower[axis] = lo - radius
            upper[axis] = hi + radius
        return lower, upper
