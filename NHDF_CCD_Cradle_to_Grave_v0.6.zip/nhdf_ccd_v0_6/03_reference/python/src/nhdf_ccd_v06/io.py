"""Versioned JSON scene parsing and certificate output."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np

from .math3d import Pose
from .motion import MovingConvex, RigidMotion
from .shapes import Box, Capsule, ConvexHull, Sphere, Triangle


def parse_shape(data: dict[str, Any]):
    kind = data["kind"]
    if kind == "sphere":
        return Sphere(float(data["radius"]), np.asarray(data.get("center", [0, 0, 0]), dtype=float))
    if kind == "capsule":
        return Capsule(np.asarray(data["a"], dtype=float), np.asarray(data["b"], dtype=float), float(data["radius"]))
    if kind == "box":
        return Box(np.asarray(data["half_extents"], dtype=float), np.asarray(data.get("center", [0, 0, 0]), dtype=float))
    if kind == "triangle":
        return Triangle(np.asarray(data["a"], dtype=float), np.asarray(data["b"], dtype=float), np.asarray(data["c"], dtype=float))
    if kind == "convex_hull":
        return ConvexHull(np.asarray(data["vertices"], dtype=float))
    raise ValueError(f"unsupported shape kind {kind!r}")


def moving_body(data: dict[str, Any]) -> MovingConvex:
    pose_data = data.get("pose0", {})
    pose = Pose(
        np.asarray(pose_data.get("translation", [0, 0, 0]), dtype=float),
        np.asarray(pose_data.get("rotation_wxyz", [1, 0, 0, 0]), dtype=float),
    )
    motion = RigidMotion(
        pose,
        np.asarray(data.get("linear_velocity", [0, 0, 0]), dtype=float),
        np.asarray(data.get("linear_acceleration", [0, 0, 0]), dtype=float),
        np.asarray(data.get("angular_velocity", [0, 0, 0]), dtype=float),
    )
    return MovingConvex(parse_shape(data["shape"]), motion, str(data["id"]))


def load_scene(path: str | Path) -> tuple[MovingConvex, MovingConvex]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if data.get("schema_version") != "nhdf-ccd-scene-0.6.0":
        raise ValueError("scene schema_version must be nhdf-ccd-scene-0.6.0")
    bodies = data.get("bodies", [])
    if len(bodies) != 2:
        raise ValueError("reference pair scene must contain exactly two bodies")
    parsed = moving_body(bodies[0]), moving_body(bodies[1])
    if parsed[0].body_id == parsed[1].body_id:
        raise ValueError("body identifiers must be unique")
    return parsed
