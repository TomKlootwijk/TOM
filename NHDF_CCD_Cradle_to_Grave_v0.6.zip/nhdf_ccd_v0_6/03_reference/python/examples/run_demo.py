from pathlib import Path
import json

from nhdf_ccd_v06.ccd import conservative_advancement
from nhdf_ccd_v06.io import load_scene

scene = Path(__file__).with_name("rotating_capsule_box.json")
a, b = load_scene(scene)
result = conservative_advancement(a, b)
print(json.dumps(result.to_dict(), indent=2, sort_keys=True))
