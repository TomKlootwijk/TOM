# Independent C++17 reference slice

This directory independently implements the support maps, small-simplex distance
query and rigid-convex conservative advancement in C++17. It is not generated from
the Python source and is used as a language/implementation cross-check.

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
ctest --test-dir build --output-on-failure
```

The C++ certificate is intentionally smaller than the JSON Python certificate. It
is not a drop-in serialization implementation and does not yet expose the BVH or
full trace contract.
