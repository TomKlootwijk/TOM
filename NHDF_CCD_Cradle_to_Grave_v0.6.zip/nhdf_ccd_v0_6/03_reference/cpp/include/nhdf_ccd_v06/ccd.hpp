#pragma once

#include <array>
#include <cstddef>
#include <string>
#include <variant>
#include <vector>

namespace nhdf::ccd::v06 {

struct Vec3 {
    double x{0.0}, y{0.0}, z{0.0};
    Vec3 operator+(const Vec3& o) const;
    Vec3 operator-(const Vec3& o) const;
    Vec3 operator-() const;
    Vec3 operator*(double s) const;
    Vec3 operator/(double s) const;
    Vec3& operator+=(const Vec3& o);
};
Vec3 operator*(double s, const Vec3& v);
double dot(const Vec3& a, const Vec3& b);
double norm2(const Vec3& v);
double norm(const Vec3& v);
Vec3 normalized(const Vec3& v, const Vec3& fallback = {1.0, 0.0, 0.0});

struct Quat {
    double w{1.0}, x{0.0}, y{0.0}, z{0.0};
};
Quat normalized(const Quat& q);
Quat multiply(const Quat& a, const Quat& b);
Quat from_rotation_vector(const Vec3& rotation_vector);
Vec3 rotate(const Quat& q, const Vec3& v);
Vec3 inverse_rotate(const Quat& q, const Vec3& v);

struct Pose {
    Vec3 translation{};
    Quat rotation{};
    Vec3 transform_point(const Vec3& p) const;
};

struct Sphere { double radius{0.0}; Vec3 center{}; };
struct Capsule { Vec3 a{}, b{}; double radius{0.0}; };
struct Box { Vec3 half_extents{}; Vec3 center{}; };
struct Hull { std::vector<Vec3> vertices; };
struct Triangle { Vec3 a{}, b{}, c{}; };
using Shape = std::variant<Sphere, Capsule, Box, Hull, Triangle>;

Vec3 local_center(const Shape& shape);
double bounding_radius(const Shape& shape);
Vec3 support_world(const Shape& shape, const Pose& pose, const Vec3& direction);

struct RigidMotion {
    Pose pose0{};
    Vec3 linear_velocity{};
    Vec3 linear_acceleration{};
    Vec3 angular_velocity{};
    Pose pose_at(double t) const;
    double point_speed_bound(const Shape& shape, double t0, double t1) const;
};

struct Body {
    std::string id;
    Shape shape;
    RigidMotion motion{};
};

struct GJKResult {
    double lower_bound{0.0};
    double upper_bound{0.0};
    Vec3 witness_a{};
    Vec3 witness_b{};
    Vec3 normal{};
    int iterations{0};
    int support_calls{0};
    int simplex_size{0};
    bool converged{false};
    bool intersect{false};
    std::string termination;
};

GJKResult gjk_distance(
    const Shape& a,
    const Pose& pose_a,
    const Shape& b,
    const Pose& pose_b,
    int max_iterations = 64,
    double absolute_tolerance = 1e-11,
    double relative_tolerance = 1e-11,
    double overlap_tolerance = 1e-12,
    double duplicate_tolerance = 1e-13
);

enum class Status {
    Hit,
    Miss,
    InitialOverlap,
    Inconclusive,
    InvalidInput,
    NumericalFailure
};

struct CAConfig {
    double contact_tolerance{1e-6};
    double distance_error_budget{1e-8};
    double time_tolerance{1e-10};
    double safety_factor{0.9};
    double min_safe_step{1e-14};
    int max_iterations{128};
    int refinement_iterations{48};
    int gjk_max_iterations{64};
};

struct Certificate {
    Status status{Status::Inconclusive};
    double time_lower{-1.0};
    double time_upper{-1.0};
    double distance_upper{-1.0};
    Vec3 witness_a{};
    Vec3 witness_b{};
    Vec3 normal{};
    int ca_iterations{0};
    int gjk_iterations_total{0};
    std::string termination;
};

Certificate conservative_advancement(const Body& a, const Body& b, const CAConfig& config = {});
const char* to_string(Status status);

} // namespace nhdf::ccd::v06
