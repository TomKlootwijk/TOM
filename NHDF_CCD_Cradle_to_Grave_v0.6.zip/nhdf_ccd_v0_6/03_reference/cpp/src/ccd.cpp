#include "nhdf_ccd_v06/ccd.hpp"

#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <tuple>

namespace nhdf::ccd::v06 {

Vec3 Vec3::operator+(const Vec3& o) const { return {x + o.x, y + o.y, z + o.z}; }
Vec3 Vec3::operator-(const Vec3& o) const { return {x - o.x, y - o.y, z - o.z}; }
Vec3 Vec3::operator-() const { return {-x, -y, -z}; }
Vec3 Vec3::operator*(double s) const { return {x * s, y * s, z * s}; }
Vec3 Vec3::operator/(double s) const { return {x / s, y / s, z / s}; }
Vec3& Vec3::operator+=(const Vec3& o) { x += o.x; y += o.y; z += o.z; return *this; }
Vec3 operator*(double s, const Vec3& v) { return v * s; }
double dot(const Vec3& a, const Vec3& b) { return a.x*b.x + a.y*b.y + a.z*b.z; }
double norm2(const Vec3& v) { return dot(v, v); }
double norm(const Vec3& v) { return std::sqrt(norm2(v)); }
Vec3 normalized(const Vec3& v, const Vec3& fallback) {
    const double n = norm(v);
    if (n > 1e-15) return v / n;
    const double f = norm(fallback);
    return f > 1e-15 ? fallback / f : Vec3{1.0, 0.0, 0.0};
}

Quat normalized(const Quat& q) {
    const double n = std::sqrt(q.w*q.w + q.x*q.x + q.y*q.y + q.z*q.z);
    if (!(n > 1e-15) || !std::isfinite(n)) throw std::invalid_argument("invalid quaternion");
    return {q.w/n, q.x/n, q.y/n, q.z/n};
}
Quat multiply(const Quat& a, const Quat& b) {
    return normalized({
        a.w*b.w - a.x*b.x - a.y*b.y - a.z*b.z,
        a.w*b.x + a.x*b.w + a.y*b.z - a.z*b.y,
        a.w*b.y - a.x*b.z + a.y*b.w + a.z*b.x,
        a.w*b.z + a.x*b.y - a.y*b.x + a.z*b.w
    });
}
Quat from_rotation_vector(const Vec3& rv) {
    const double angle = norm(rv);
    if (angle <= 1e-15) return {};
    const double half = 0.5 * angle;
    const Vec3 axis = rv / angle;
    const double s = std::sin(half);
    return {std::cos(half), axis.x*s, axis.y*s, axis.z*s};
}
Vec3 rotate(const Quat& q0, const Vec3& v) {
    const Quat q = normalized(q0);
    const Vec3 qv{q.x, q.y, q.z};
    const Vec3 t{2.0*(qv.y*v.z-qv.z*v.y), 2.0*(qv.z*v.x-qv.x*v.z), 2.0*(qv.x*v.y-qv.y*v.x)};
    const Vec3 cross2{qv.y*t.z-qv.z*t.y, qv.z*t.x-qv.x*t.z, qv.x*t.y-qv.y*t.x};
    return v + q.w*t + cross2;
}
Vec3 inverse_rotate(const Quat& q, const Vec3& v) { return rotate({q.w, -q.x, -q.y, -q.z}, v); }
Vec3 Pose::transform_point(const Vec3& p) const { return rotate(rotation, p) + translation; }

static Vec3 support_local(const Shape& shape, const Vec3& d) {
    return std::visit([&](const auto& s) -> Vec3 {
        using T = std::decay_t<decltype(s)>;
        if constexpr (std::is_same_v<T, Sphere>) {
            return s.center + s.radius * normalized(d);
        } else if constexpr (std::is_same_v<T, Capsule>) {
            const Vec3 end = dot(s.a, d) >= dot(s.b, d) ? s.a : s.b;
            return end + s.radius * normalized(d);
        } else if constexpr (std::is_same_v<T, Box>) {
            return s.center + Vec3{d.x >= 0 ? s.half_extents.x : -s.half_extents.x,
                                   d.y >= 0 ? s.half_extents.y : -s.half_extents.y,
                                   d.z >= 0 ? s.half_extents.z : -s.half_extents.z};
        } else if constexpr (std::is_same_v<T, Hull>) {
            if (s.vertices.empty()) throw std::invalid_argument("empty hull");
            return *std::max_element(s.vertices.begin(), s.vertices.end(), [&](const Vec3& a, const Vec3& b){
                return dot(a, d) < dot(b, d);
            });
        } else {
            std::array<Vec3,3> vertices{s.a,s.b,s.c};
            return *std::max_element(vertices.begin(), vertices.end(), [&](const Vec3& a, const Vec3& b){
                return dot(a, d) < dot(b, d);
            });
        }
    }, shape);
}
Vec3 local_center(const Shape& shape) {
    return std::visit([](const auto& s) -> Vec3 {
        using T = std::decay_t<decltype(s)>;
        if constexpr (std::is_same_v<T, Sphere> || std::is_same_v<T, Box>) return s.center;
        else if constexpr (std::is_same_v<T, Capsule>) return 0.5*(s.a+s.b);
        else if constexpr (std::is_same_v<T, Hull>) {
            if (s.vertices.empty()) throw std::invalid_argument("empty hull");
            Vec3 c{}; for (const auto& v: s.vertices) c += v; return c / static_cast<double>(s.vertices.size());
        } else return (s.a+s.b+s.c)/3.0;
    }, shape);
}
double bounding_radius(const Shape& shape) {
    return std::visit([](const auto& s) -> double {
        using T = std::decay_t<decltype(s)>;
        if constexpr (std::is_same_v<T, Sphere>) return norm(s.center)+s.radius;
        else if constexpr (std::is_same_v<T, Capsule>) return std::max(norm(s.a),norm(s.b))+s.radius;
        else if constexpr (std::is_same_v<T, Box>) return norm(s.center)+norm(s.half_extents);
        else if constexpr (std::is_same_v<T, Hull>) {
            double r=0; for (const auto& v:s.vertices) r=std::max(r,norm(v)); return r;
        } else return std::max({norm(s.a),norm(s.b),norm(s.c)});
    }, shape);
}
Vec3 support_world(const Shape& shape, const Pose& pose, const Vec3& direction) {
    return pose.transform_point(support_local(shape, inverse_rotate(pose.rotation, direction)));
}

Pose RigidMotion::pose_at(double t) const {
    return {pose0.translation + linear_velocity*t + linear_acceleration*(0.5*t*t),
            multiply(from_rotation_vector(angular_velocity*t), pose0.rotation)};
}
double RigidMotion::point_speed_bound(const Shape& shape, double t0, double t1) const {
    const Vec3 v0 = linear_velocity + linear_acceleration*t0;
    const double linear = norm(v0) + norm(linear_acceleration)*(t1-t0);
    return linear + norm(angular_velocity)*bounding_radius(shape);
}

struct Support { Vec3 p,a,b; };
static Support support(const Shape& a, const Pose& pa, const Shape& b, const Pose& pb, const Vec3& d) {
    const Vec3 wa=support_world(a,pa,d), wb=support_world(b,pb,-d);
    return {wa-wb,wa,wb};
}

static bool solve_linear(std::vector<std::vector<double>> a, std::vector<double> b, std::vector<double>& x) {
    const int n=static_cast<int>(b.size());
    for(int col=0;col<n;++col){
        int pivot=col; for(int r=col+1;r<n;++r) if(std::abs(a[r][col])>std::abs(a[pivot][col])) pivot=r;
        if(std::abs(a[pivot][col])<1e-18) return false;
        std::swap(a[pivot],a[col]); std::swap(b[pivot],b[col]);
        const double div=a[col][col]; for(int j=col;j<n;++j)a[col][j]/=div; b[col]/=div;
        for(int r=0;r<n;++r) if(r!=col){ const double f=a[r][col]; if(f==0)continue; for(int j=col;j<n;++j)a[r][j]-=f*a[col][j]; b[r]-=f*b[col]; }
    }
    x=b; return true;
}

static bool closest_simplex(const std::vector<Support>& input, std::vector<Support>& output, std::vector<double>& weights, Vec3& q) {
    const int n=static_cast<int>(input.size());
    double best=std::numeric_limits<double>::infinity(); int best_mask=0; std::vector<double> best_w;
    for(int mask=1;mask<(1<<n);++mask){
        std::vector<int> ids; for(int i=0;i<n;++i) if(mask&(1<<i)) ids.push_back(i);
        const int k=static_cast<int>(ids.size());
        std::vector<std::vector<double>> m(k+1,std::vector<double>(k+1,0.0));
        std::vector<double> rhs(k+1,0.0); rhs[k]=1.0;
        for(int i=0;i<k;++i){ for(int j=0;j<k;++j)m[i][j]=dot(input[ids[i]].p,input[ids[j]].p); m[i][k]=1.0; m[k][i]=1.0; }
        std::vector<double> sol; if(!solve_linear(m,rhs,sol)) continue;
        bool feasible=true; for(int i=0;i<k;++i) if(sol[i]<-1e-11) feasible=false; if(!feasible) continue;
        double sum=0; for(int i=0;i<k;++i){sol[i]=std::max(0.0,sol[i]);sum+=sol[i];} if(sum<=1e-15)continue;
        Vec3 point{}; for(int i=0;i<k;++i){sol[i]/=sum;point+=sol[i]*input[ids[i]].p;}
        const double d2=norm2(point); if(d2<best-1e-24){best=d2;best_mask=mask;best_w.assign(sol.begin(),sol.begin()+k);}
    }
    if(best_mask==0)return false;
    output.clear(); weights.clear(); q={}; int wi=0;
    for(int i=0;i<n;++i)if(best_mask&(1<<i)){output.push_back(input[i]);weights.push_back(best_w[wi]);q+=best_w[wi]*input[i].p;++wi;}
    return true;
}

GJKResult gjk_distance(const Shape& a,const Pose& pa,const Shape& b,const Pose& pb,int max_iter,double abs_tol,double rel_tol,double overlap_tol,double dup_tol){
    Vec3 dir=pb.transform_point(local_center(b))-pa.transform_point(local_center(a)); if(norm(dir)<=1e-15)dir={1,0,0};
    std::vector<Support> simplex{support(a,pa,b,pb,dir)}; int calls=1; std::vector<double>w; Vec3 q{};
    if(!closest_simplex(simplex,simplex,w,q)) return {0,norm(simplex[0].p),{}, {},{},0,calls,1,false,false,"initial_simplex_failure"};
    double lower=0,previous=std::numeric_limits<double>::infinity(); int stall=0;
    for(int iteration=1;iteration<=max_iter;++iteration){
        const double upper=norm(q);
        Vec3 wa{},wb{}; for(size_t i=0;i<simplex.size();++i){wa+=w[i]*simplex[i].a;wb+=w[i]*simplex[i].b;}
        const Vec3 normal=normalized(wb-wa,-q);
        if(upper<=overlap_tol)return {0,upper,wa,wb,normal,iteration,calls,(int)simplex.size(),true,true,"origin_or_overlap_tolerance"};
        Support candidate=support(a,pa,b,pb,-q);++calls;
        const double plane=dot(q/upper,candidate.p); if(std::isfinite(plane))lower=std::max(lower,std::min(upper,plane)); lower=std::max(0.0,lower);
        const double gap=upper-lower,tol=abs_tol+rel_tol*upper;
        if(gap<=tol)return {lower,upper,wa,wb,normal,iteration,calls,(int)simplex.size(),true,false,"support_plane_gap"};
        bool duplicate=false; const double threshold=dup_tol*std::max(1.0,norm(candidate.p)); for(const auto&s:simplex)if(norm(candidate.p-s.p)<=threshold)duplicate=true;
        if(duplicate){const bool ok=gap<=std::max(32*tol,threshold);return {lower,upper,wa,wb,normal,iteration,calls,(int)simplex.size(),ok,false,ok?"duplicate_support_converged":"duplicate_support_unresolved"};}
        if(previous-upper<=std::max(1e-16,abs_tol*1e-3))++stall;else stall=0; previous=upper;
        if(stall>=6&&gap>32*tol)return {lower,upper,wa,wb,normal,iteration,calls,(int)simplex.size(),false,false,"upper_bound_stall"};
        std::vector<Support> expanded=simplex;expanded.push_back(candidate); if(!closest_simplex(expanded,simplex,w,q))return {lower,upper,wa,wb,normal,iteration,calls,(int)simplex.size(),false,false,"simplex_solve_failure"};
    }
    Vec3 wa{},wb{};for(size_t i=0;i<simplex.size();++i){wa+=w[i]*simplex[i].a;wb+=w[i]*simplex[i].b;}const double upper=norm(q);
    return {lower,upper,wa,wb,normalized(wb-wa,-q),max_iter,calls,(int)simplex.size(),false,upper<=overlap_tol,"iteration_limit"};
}

static double pair_speed(const Body&a,const Body&b,double t0,double t1){const Vec3 rv=(a.motion.linear_velocity+a.motion.linear_acceleration*t0)-(b.motion.linear_velocity+b.motion.linear_acceleration*t0);const Vec3 ra=a.motion.linear_acceleration-b.motion.linear_acceleration;const double linear=norm(rv)+norm(ra)*(t1-t0);return linear+norm(a.motion.angular_velocity)*bounding_radius(a.shape)+norm(b.motion.angular_velocity)*bounding_radius(b.shape);}
static bool usable(const GJKResult&r,const CAConfig&c){return r.intersect||r.converged||(r.upper_bound-r.lower_bound)<=c.distance_error_budget;}
Certificate conservative_advancement(const Body&a,const Body&b,const CAConfig&c){
    Certificate out{}; double t=0,safe_t=0; int total=0;
    auto sample=[&](double time){auto r=gjk_distance(a.shape,a.motion.pose_at(time),b.shape,b.motion.pose_at(time),c.gjk_max_iterations);total+=r.iterations;return r;};
    GJKResult r; try{r=sample(0);}catch(...){out.status=Status::InvalidInput;out.termination="invalid_input";return out;}
    if(!usable(r,c)){out.status=Status::NumericalFailure;out.termination="initial_gjk_nonconvergence";return out;}
    const double threshold=c.contact_tolerance+c.distance_error_budget;
    if(r.upper_bound<=threshold||r.intersect){out.status=Status::InitialOverlap;out.time_lower=out.time_upper=0;out.distance_upper=r.upper_bound;out.termination="initial_contact";return out;}
    for(int i=1;i<=c.max_iterations;++i){
        const double speed=pair_speed(a,b,t,1); if(speed<=1e-15){out.status=Status::Miss;out.termination="stationary_positive_separation";break;}
        if(r.lower_bound-c.distance_error_budget-speed*(1-t)-c.contact_tolerance>0){out.status=Status::Miss;out.termination="remaining_interval_lipschitz_miss";break;}
        const double gap=r.lower_bound-c.contact_tolerance-c.distance_error_budget;
        const double closure_slack=64.0e-11;
        if(gap<=0){
            if(r.upper_bound<=threshold+closure_slack||r.intersect){
                out.status=Status::Hit;out.time_lower=safe_t;out.time_upper=t;out.distance_upper=r.upper_bound;
                out.witness_a=r.witness_a;out.witness_b=r.witness_b;out.normal=r.normal;
                out.termination="contact_within_declared_bound_interval";
            }else{
                out.status=Status::Inconclusive;out.time_lower=safe_t;out.time_upper=t;out.distance_upper=r.upper_bound;
                out.termination="distance_bounds_straddle_contact_band";
            }
            out.ca_iterations=i-1;break;
        }
        const double dt=c.safety_factor*gap/speed; if(dt<c.min_safe_step){if(r.upper_bound<=threshold+closure_slack){out.status=Status::Hit;out.time_lower=safe_t;out.time_upper=t;out.distance_upper=r.upper_bound;out.termination="contact_numerical_band";}else{out.status=Status::Inconclusive;out.termination="safe_progress_below_minimum";}out.ca_iterations=i;break;}
        safe_t=t;t=std::min(1.0,t+dt);r=sample(t);if(!usable(r,c)){out.status=Status::NumericalFailure;out.termination="gjk_nonconvergence";out.ca_iterations=i;break;}
        if(r.upper_bound<=threshold||r.intersect){double lo=safe_t,hi=t;GJKResult hr=r;for(int k=0;k<c.refinement_iterations&&hi-lo>c.time_tolerance;++k){double mid=.5*(lo+hi);auto mr=sample(mid);if(!usable(mr,c))break;if(mr.upper_bound<=threshold||mr.intersect){hi=mid;hr=mr;}else lo=mid;}out.status=Status::Hit;out.time_lower=lo;out.time_upper=hi;out.distance_upper=hr.upper_bound;out.witness_a=hr.witness_a;out.witness_b=hr.witness_b;out.normal=hr.normal;out.termination="contact_bracket_refined";out.ca_iterations=i;break;}
        if(t>=1){out.status=Status::Miss;out.termination="reached_end_with_positive_separation";out.ca_iterations=i;break;}
        if(i==c.max_iterations){out.status=Status::Inconclusive;out.termination="iteration_limit";out.ca_iterations=i;}
    }
    out.gjk_iterations_total=total; return out;
}
const char* to_string(Status s){switch(s){case Status::Hit:return"HIT";case Status::Miss:return"MISS";case Status::InitialOverlap:return"INITIAL_OVERLAP";case Status::Inconclusive:return"INCONCLUSIVE";case Status::InvalidInput:return"INVALID_INPUT";case Status::NumericalFailure:return"NUMERICAL_FAILURE";}return"UNKNOWN";}

} // namespace nhdf::ccd::v06
