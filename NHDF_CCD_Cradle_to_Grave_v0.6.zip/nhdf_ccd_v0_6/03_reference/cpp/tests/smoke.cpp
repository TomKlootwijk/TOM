#include "nhdf_ccd_v06/ccd.hpp"
#include <cmath>
#include <iostream>
#include <stdexcept>

using namespace nhdf::ccd::v06;
static void require(bool value, const char* message){if(!value)throw std::runtime_error(message);}
int main(){
    Pose identity{};
    auto d=gjk_distance(Sphere{1.0,{}},identity,Sphere{0.5,{}},Pose{{3,0,0},{}});
    require(d.converged && std::abs(d.upper_bound-1.5)<1e-10,"sphere distance");
    Body a{"a",Sphere{1.0,{}},RigidMotion{Pose{{-3,0,0},{}},{6,0,0},{},{}}};
    Body b{"b",Sphere{1.0,{}},RigidMotion{}};
    auto hit=conservative_advancement(a,b);
    require(hit.status==Status::Hit && hit.time_upper>0.16 && hit.time_upper<0.17,"sphere CCD");
    Body miss_a{"m",Sphere{0.5,{}},RigidMotion{Pose{{-3,3,0},{}},{6,0,0},{},{}}};
    Body miss_b{"n",Sphere{0.5,{}},RigidMotion{}};
    require(conservative_advancement(miss_a,miss_b).status==Status::Miss,"sphere miss");
    Body cap{"cap",Capsule{{-1,0,0},{1,0,0},0.15},RigidMotion{Pose{}, {}, {}, {0,0,2.4}}};
    Body box{"box",Box{{0.25,0.25,0.25},{}},RigidMotion{Pose{{0,1,0},{}},{},{},{}}};
    auto rotating=conservative_advancement(cap,box);
    require(rotating.status==Status::Hit && rotating.time_upper>0.43 && rotating.time_upper<0.46,"rotating capsule box");
    std::cout << "C++17 smoke: PASS\n";
    std::cout << "sphere_toi_upper=" << hit.time_upper << " rotating_toi_upper=" << rotating.time_upper << "\n";
    return 0;
}
